---
title: "My Ex Is Using My Child Against Me: What Can I Actually Do?"
seoTitle: "Parental Alienation & Child Contact: A UK Guide for Parents"
metaDescription: "Is your ex using your child against you? Explore alienating behaviours, family court evidence and practical steps for parents in Scotland and England."
slug: "my-ex-is-using-my-child-against-me"
categories: "Parental Alienation & DARVO"
tags: "[\"['DARVO']\"]"
author: "Reiki Fish"
featured: false
draft: false
date: "2026-08-06"
excerpt: "When a relationship with your child suddenly changes after separation, it can be devastating. This in-depth guide explores alienating behaviours, false or disputed allegations, children’s wishes, evidence and the family courts in Scotland and England."
featuredImage: "assets/images/blog/parental_alienation.png"
featuredImageAlt: "Distressed parent coping with separation, child contact problems and alienating behaviours after a relationship breakdown."
---

<h2>My Ex Is Using My Child Against Me: What Can I Actually Do?</h2>
<p>Few experiences are as psychologically brutal as watching the relationship between you and your child change after separation, particularly when you believe another parent is influencing that relationship.</p>
<p>A child who once ran towards you may become distant. Phone calls may stop. Messages may go unanswered. Normal parenting disagreements can suddenly be described as evidence that you are unsafe. Your child may begin repeating phrases that sound strangely adult. You may find yourself accused of things that bear little resemblance to the relationship you remember having with them.</p>
<p>Then comes perhaps the hardest part: trying to explain what is happening without sounding angry, defensive or obsessed with proving that your former partner is lying.</p>
<p>If court proceedings begin, the experience can become even more frightening. Allegations may have immediate consequences before every disputed fact has been finally determined. A parent can therefore feel as though they have been treated as guilty before having a meaningful opportunity to answer what has been said.</p>
<p>But this is where precision matters.</p>
<p>An allegation is not automatically a proven fact. A child's expressed wishes are important, but they are not necessarily the only consideration. Equally, a child refusing contact does not automatically prove parental manipulation. There are many reasons why children resist relationships after family breakdown, including genuine fear, domestic abuse, harmful parenting, loyalty conflicts, unresolved family conflict and the behaviour of one or both parents.</p>
<p>If you believe your child is being turned against you, your strongest response is therefore rarely to shout louder that your ex is an alienator. It is to become calmer, more factual and more child-focused.</p>
<p>This article explains how.</p>
<h2>First: Stop Trying to Win the Break-up</h2>
<p>The family relationship has changed. Your job now is not to win the argument about who destroyed it.</p>
<p>Your job is to protect your relationship with your child.</p>
<p>Those two goals can require completely different behaviour.</p>
<p>When someone feels falsely accused, the natural psychological response is self-defence. You want to correct every lie, expose every contradiction and make other people understand what has happened.</p>
<p>That response is understandable. It can also become counterproductive.</p>
<p>Imagine the difference between these two statements:</p>
<p><strong>&ldquo;My narcissistic ex has brainwashed my daughter and everybody keeps believing her lies.&rdquo;</strong></p>
<p>and:</p>
<p><strong>&ldquo;Until February, my daughter stayed with me every second weekend and we had regular telephone contact. Since 12 March, six planned contacts have not taken place. I have attached the relevant messages. I am concerned about the abrupt deterioration in our relationship and would like the reasons for it independently explored.&rdquo;</strong></p>
<p>The second statement is far more powerful.</p>
<p>It does not require anyone to accept your psychological interpretation of your ex-partner. It identifies an observable change, supplies dates and invites investigation.</p>
<p>That principle runs throughout this article:</p>
<p><strong>Describe behaviour before assigning motives.</strong></p>
<h2>What Does &ldquo;Using My Child Against Me&rdquo; Actually Mean?</h2>
<p>Parents use this phrase to describe many different experiences. Some involve seriously harmful behaviour. Others involve ordinary post-separation conflict. They should not all be treated as the same thing.</p>
<p>Potentially concerning behaviours can include:</p>
<ul>
<li>Repeatedly speaking negatively about the other parent to the child.</li>
<li>Encouraging the child to see ordinary parenting mistakes as evidence that the other parent is dangerous or uncaring.</li>
<li>Making the child feel guilty for enjoying time with the other parent.</li>
<li>Interrogating the child after contact.</li>
<li>Using the child to obtain information about the other parent's private life.</li>
<li>Asking the child to carry hostile messages between adults.</li>
<li>Sharing adult court allegations with the child.</li>
<li>Encouraging the child to choose one parent over the other.</li>
<li>Repeatedly arranging competing activities during the other parent's agreed time.</li>
<li>Withholding school, medical or activity information without a legitimate reason.</li>
<li>Making communication unnecessarily difficult.</li>
<li>Giving the child the impression that loving one parent betrays the other.</li>
<li>Exaggerating relatively ordinary disagreements until the child begins to perceive the other parent as threatening.</li>
<li>Making unsupported allegations as a means of controlling contact.</li>
<li>Pressuring a child to repeat an adult's interpretation of past events.</li>
<li>Rewarding rejection of the other parent through approval, attention or relief from conflict.</li>
<li>Creating the impression that the child alone is responsible for deciding whether a parental relationship continues.</li>
</ul>
<p>However, none of these behaviours should simply be presumed because a child refuses contact.</p>
<p>Sometimes children have legitimate reasons for avoiding a parent. Sometimes a previously loving relationship contained difficulties that the rejected parent did not fully appreciate. Sometimes domestic abuse or coercive control has occurred. Sometimes children are overwhelmed by continuing parental conflict rather than deliberately manipulated by either adult.</p>
<p>The correct question is therefore not simply:</p>
<p><strong>&ldquo;Is this parental alienation?&rdquo;</strong></p>
<p>A better question is:</p>
<p><strong>&ldquo;What is causing this particular child to resist or reject this particular relationship?&rdquo;</strong></p>
<h2>Why I Prefer the Term &ldquo;Alienating Behaviours&rdquo;</h2>
<p>The expression &ldquo;parental alienation&rdquo; has become extraordinarily controversial.</p>
<p>Online, it is sometimes presented as though it were a straightforward psychiatric diagnosis. It is not.</p>
<p>In England, Cafcass currently uses the term <strong>alienating behaviours</strong> rather than treating &ldquo;parental alienation&rdquo; as a syndrome or medical condition. Its focus is on behaviour and the effect that behaviour may have on an individual child.</p>
<p>Cafcass describes alienating behaviour as an ongoing pattern of negative attitudes and communication concerning another parent or carer that may undermine, manipulate or even destroy the child's relationship with that person.</p>
<p>This distinction is extremely useful.</p>
<p>You do not need to diagnose your former partner.</p>
<p>You do not need to establish that they have narcissistic personality disorder, borderline personality disorder, psychopathy or any other psychiatric condition.</p>
<p>You need to identify behaviour.</p>
<p>Instead of:</p>
<p><strong>&ldquo;My ex is a narcissist who is alienating my son.&rdquo;</strong></p>
<p>consider:</p>
<p><strong>&ldquo;My son previously had regular and affectionate contact with me. Since our separation he has repeatedly been told details of the adult dispute, according to the messages attached. Three scheduled contacts were then cancelled. I am concerned about the effect this conflict is having on him.&rdquo;</strong></p>
<p>That is evidence-led rather than label-led.</p>
<h2>Alienation, Estrangement and Justified Rejection Are Not the Same Thing</h2>
<p>This is one of the most important distinctions in the entire subject.</p>
<p>A child may reject a parent because somebody is influencing them.</p>
<p>A child may also reject a parent because of that parent's own behaviour.</p>
<p>And sometimes both things can be happening simultaneously.</p>
<p>For example, one parent may have behaved badly during the relationship while the other subsequently exaggerates or weaponises that history. Reality does not always divide neatly into an innocent parent and a guilty parent.</p>
<p>Possible explanations for resistance include:</p>
<ul>
<li>Actual domestic abuse.</li>
<li>Physical or emotional harm.</li>
<li>Fear arising from a parent's previous behaviour.</li>
<li>A child's reaction to witnessing intense conflict.</li>
<li>Developmentally normal anger after family separation.</li>
<li>A difficult relationship that existed before separation.</li>
<li>Pressure or influence from another adult.</li>
<li>Loyalty towards the parent with whom the child primarily lives.</li>
<li>Anxiety about upsetting one parent by enjoying the other.</li>
<li>Misunderstanding adult events.</li>
<li>Exposure to inappropriate information.</li>
<li>Sibling influence.</li>
<li>Extended family influence.</li>
<li>Repeated negative descriptions of the other parent.</li>
<li>A combination of several of these factors.</li>
</ul>
<p>This is why responsible professionals should explore competing explanations rather than beginning with a predetermined label.</p>
<h2>Your Child's Feelings Are Real Even If Their Explanation Is Wrong</h2>
<p>This can be incredibly difficult for a rejected parent to understand.</p>
<p>Imagine your child says:</p>
<p><strong>&ldquo;I don't want to see Dad. Dad doesn't care about me.&rdquo;</strong></p>
<p>You may possess photographs, messages and memories demonstrating years of love and involvement. Your immediate response may be:</p>
<p><strong>&ldquo;That's rubbish. Who told you that?&rdquo;</strong></p>
<p>Don't.</p>
<p>The child's conclusion may be inaccurate while the emotion beneath it remains completely genuine.</p>
<p>A much safer response is:</p>
<p><strong>&ldquo;I'm sorry you're feeling that way. You don't have to choose between anybody. I love you, and if you ever want to talk to me about how you feel, I'll listen.&rdquo;</strong></p>
<p>This does something crucial.</p>
<p>It separates <strong>validation of emotion</strong> from <strong>agreement with an allegation</strong>.</p>
<p>You can acknowledge fear without admitting that you caused it.</p>
<p>You can acknowledge anger without accepting every explanation for that anger.</p>
<p>You can acknowledge the child's voice without asking them to decide the adult dispute.</p>
<h2>Children's Memories Are Not Video Recordings</h2>
<p>Another mistake is assuming that memory works like a camera.</p>
<p>It doesn't.</p>
<p>Human memory is reconstructive. Adults and children retrieve fragments of experience and rebuild them in the present. Later information, repeated discussion, emotional state, expectations and the way questions are asked can all influence recollection.</p>
<p>This does <strong>not</strong> mean children are inherently unreliable.</p>
<p>It certainly does not mean that a child's allegation should automatically be regarded as fabricated.</p>
<p>It means that investigating serious allegations requires care.</p>
<p>Repeated questioning can be particularly problematic. If several adults continually ask variations of:</p>
<p><strong>&ldquo;What did Dad do to you?&rdquo;</strong></p>
<p>the question itself contains an assumption.</p>
<p>A more neutral approach is:</p>
<p><strong>&ldquo;Tell me what happened.&rdquo;</strong></p>
<p>This is precisely why a parent should resist conducting their own amateur investigation.</p>
<h2>Do Not Interview Your Child</h2>
<p>If your child makes a serious allegation, one of the most important things you can do is avoid repeatedly questioning them yourself.</p>
<p>You may desperately want to establish where the story came from. You may believe that if you can speak to them directly, everything will become clear.</p>
<p>That instinct is understandable, but repeated or leading questioning can contaminate the very evidence you want taken seriously.</p>
<p>Avoid questions such as:</p>
<ul>
<li>&ldquo;Did Mum tell you to say that?&rdquo;</li>
<li>&ldquo;You know Daddy never did that, don't you?&rdquo;</li>
<li>&ldquo;Why are you lying about me?&rdquo;</li>
<li>&ldquo;Who put this into your head?&rdquo;</li>
<li>&ldquo;Tell the social worker what really happened.&rdquo;</li>
<li>&ldquo;Remember when you told me you loved staying here?&rdquo;</li>
<li>&ldquo;If you loved me, why would you say this?&rdquo;</li>
</ul>
<p>Those questions place the child directly inside the adult conflict.</p>
<p>If a child spontaneously tells you something important, listen calmly. Do not interrogate. Make an accurate contemporaneous note afterwards if necessary and obtain professional legal advice where the matter is serious.</p>
<h2>The Loyalty Conflict</h2>
<p>One of the most psychologically damaging positions for a child is feeling that loving one parent constitutes betrayal of the other.</p>
<p>The child effectively receives an impossible equation:</p>
<p><strong>If I love Mum, I hurt Dad. If I love Dad, I hurt Mum.</strong></p>
<p>A child may resolve this by emotionally removing one side of the equation.</p>
<p>This can sometimes appear remarkably absolute:</p>
<ul>
<li>&ldquo;I hate him.&rdquo;</li>
<li>&ldquo;I never want to see her again.&rdquo;</li>
<li>&ldquo;Everything about Dad was terrible.&rdquo;</li>
<li>&ldquo;Mum never did anything for me.&rdquo;</li>
</ul>
<p>Again, such statements do not themselves prove manipulation. But a dramatic change from a previously affectionate relationship deserves careful exploration rather than simplistic interpretation.</p>
<p>Children are adaptive. They learn which subjects increase tension and which reduce it. They may discover that criticising one parent produces reassurance from another. They may learn that saying they enjoyed contact makes somebody unhappy. Over time, avoiding that internal conflict can become easier than maintaining emotional connection with both parents.</p>
<h2>Do Not Make Your Child Responsible for Fixing the Situation</h2>
<p>One sentence can quietly protect a child from enormous pressure:</p>
<p><strong>&ldquo;You don't have to choose.&rdquo;</strong></p>
<p>Children should not be required to prove their loyalty to you.</p>
<p>They should not become your witness, therapist, messenger, investigator or emotional support system.</p>
<p>Whatever is happening between adults, keep telling your child through your behaviour:</p>
<ul>
<li>You are allowed to love both parents.</li>
<li>You do not have to defend me.</li>
<li>You are not responsible for my feelings.</li>
<li>You do not have to report what happens in the other home.</li>
<li>You can tell me difficult things without being punished.</li>
<li>I will listen without forcing you to take sides.</li>
</ul>
<h2>The Court Problem: &ldquo;Nobody Has Proved It, So Why Is Contact Being Restricted?&rdquo;</h2>
<p>This is where many parents become understandably furious.</p>
<p>A parent may say:</p>
<p><strong>&ldquo;There is no significant evidence. Why is the court acting as though the allegation is true?&rdquo;</strong></p>
<p>There is an important legal distinction between <strong>managing possible risk while facts remain unresolved</strong> and <strong>finally finding an allegation proved</strong>.</p>
<p>Family courts have responsibilities towards children's welfare and safety. Consequently, an allegation capable of affecting a child's safety cannot always simply be ignored until a final hearing months later. Courts may have to make interim decisions while information is still being collected.</p>
<p>To the affected parent, this can feel indistinguishable from being presumed guilty.</p>
<p>But legally, the two things are not necessarily the same.</p>
<p>An interim protective arrangement does not, simply by existing, establish that every allegation is true.</p>
<p>Likewise, the absence of a criminal conviction does not automatically determine a private family case. Family proceedings and criminal proceedings serve different functions and operate under different legal frameworks.</p>
<p>That can feel deeply unsatisfactory when your relationship with a child is being affected in real time. Nevertheless, understanding the distinction is essential because it changes how you should respond.</p>
<h2>An Allegation Is Not a Finding of Fact</h2>
<p>This deserves to be stated plainly:</p>
<p><strong>An allegation and a judicial finding are not the same thing.</strong></p>
<p>In England and Wales, family courts apply the civil standard when determining disputed facts: the balance of probabilities.</p>
<p>That broadly asks whether the court is satisfied that the event was more likely than not to have happened.</p>
<p>That is different from the criminal standard of proof.</p>
<p>Importantly, published family judgments have repeatedly emphasised that findings should be based upon evidence rather than suspicion or speculation.</p>
<p>This means that you should keep different categories separate when discussing your case:</p>
<ul>
<li><strong>Alleged:</strong> somebody has said something happened.</li>
<li><strong>Disputed:</strong> the allegation is denied and has not yet been determined.</li>
<li><strong>Corroborated:</strong> other material supports part or all of the account.</li>
<li><strong>Established:</strong> the relevant court has made a finding.</li>
<li><strong>Not established:</strong> the evidence did not satisfy the applicable standard.</li>
</ul>
<p>That vocabulary can transform how clearly you present complicated proceedings.</p>
<h2>Why &ldquo;There Is No Evidence&rdquo; May Be the Wrong Phrase</h2>
<p>This is another crucial distinction.</p>
<p>A parent's statement is evidence.</p>
<p>A child's account can be evidence.</p>
<p>A witness statement is evidence.</p>
<p>The fact that there is no photograph, CCTV recording or medical record does not necessarily mean that there is literally &ldquo;no evidence&rdquo;.</p>
<p>The real issue may instead be:</p>
<ul>
<li>Whether the evidence is reliable.</li>
<li>Whether it is consistent.</li>
<li>Whether it is independently supported.</li>
<li>Whether contemporaneous records support or contradict it.</li>
<li>Whether competing explanations have been considered.</li>
<li>Whether the burden and standard of proof have been satisfied.</li>
</ul>
<p>So rather than saying:</p>
<p><strong>&ldquo;There is absolutely no evidence.&rdquo;</strong></p>
<p>when another person has given an account, it may be more accurate to say:</p>
<p><strong>&ldquo;The allegation is disputed and I say the available independent evidence does not substantiate it for the following reasons...&rdquo;</strong></p>
<p>Then provide those reasons.</p>
<p>That is a considerably stronger position.</p>
<h2>Family Court Is Not Criminal Court</h2>
<p>Parents sometimes expect family proceedings to operate like criminal trials.</p>
<p>They do not.</p>
<p>Family courts are primarily making decisions about welfare, risk and children's future arrangements. Criminal courts determine criminal liability.</p>
<p>This creates a difficult reality.</p>
<p>A family court may need to consider alleged behaviour relevant to future risk even where there has been no criminal prosecution or conviction. Conversely, an allegation being made does not itself prove that the alleged conduct occurred.</p>
<p>Understanding this distinction is particularly important for parents who repeatedly argue:</p>
<p><strong>&ldquo;I wasn't convicted, therefore the family court cannot consider it.&rdquo;</strong></p>
<p>That is generally too simplistic.</p>
<p>Equally simplistic is the opposite assertion:</p>
<p><strong>&ldquo;Somebody accused them, therefore they are dangerous.&rdquo;</strong></p>
<p>Neither position represents proper evidence analysis.</p>
<h2>What Happens in Scotland?</h2>
<p>Scottish family law has its own legal framework and should not simply be treated as interchangeable with England and Wales.</p>
<p>For disputes concerning parental responsibilities, parental rights, residence and contact, section 11 of the Children (Scotland) Act 1995 is central.</p>
<p>When deciding whether to make a relevant section 11 order, the welfare of the child is the court's paramount consideration. The legislation also incorporates the principle that the court should not make an order unless making the order would be better for the child than making no order.</p>
<p>The child's views are also an important part of the process.</p>
<p>Current Scottish court rules provide mechanisms for obtaining children's views, and a child welfare reporter may be appointed to seek a child's views or undertake enquiries and report to the court.</p>
<p>Where a child has expressed views, the court must give those views due weight having regard to the child's age and maturity.</p>
<p>But notice the distinction:</p>
<p><strong>Due weight does not mean automatic control of the decision.</strong></p>
<p>A child's views matter enormously, but the court remains responsible for determining welfare.</p>
<p>That becomes particularly important where a parent believes the child's wishes have been affected by adult conflict or influence.</p>
<h2>What If My Child Tells the Scottish Court They Do Not Want Contact?</h2>
<p>Do not respond by attacking the child.</p>
<p>Do not argue:</p>
<p><strong>&ldquo;My child is lying.&rdquo;</strong></p>
<p>Instead ask whether the court has enough information to understand <strong>why</strong> the child's position has changed.</p>
<p>Depending on the circumstances and your solicitor's advice, relevant questions may include:</p>
<ul>
<li>What was the child's relationship with each parent before separation?</li>
<li>When did resistance begin?</li>
<li>Was the change sudden or gradual?</li>
<li>Did a particular event precede it?</li>
<li>Has the child been exposed to adult allegations or court information?</li>
<li>What reasons has the child actually given?</li>
<li>Are those reasons consistent over time?</li>
<li>Is there independent material relevant to those reasons?</li>
<li>Has the child's account been obtained in a neutral way?</li>
<li>Does the child appear to be experiencing a loyalty conflict?</li>
<li>Are there genuine safeguarding concerns?</li>
<li>Would further independent enquiry assist the court?</li>
</ul>
<p>Your argument is not:</p>
<p><strong>&ldquo;Ignore my child.&rdquo;</strong></p>
<p>It is:</p>
<p><strong>&ldquo;Please understand my child's wishes in their full context.&rdquo;</strong></p>
<h2>What Happens in England and Wales?</h2>
<p>In England and Wales, the Children Act 1989 provides the principal framework for private-law child arrangements proceedings.</p>
<p>When a court determines a question concerning a child's upbringing, the child's welfare is its paramount consideration.</p>
<p>The statutory welfare framework includes consideration of matters such as the child's wishes and feelings, considered in light of age and understanding, alongside physical, emotional and educational needs, the likely effect of changes in circumstances, relevant characteristics, harm suffered or risk of harm, and the capability of relevant adults to meet the child's needs.</p>
<p>Cafcass may become involved in private-law proceedings and can assess the child's circumstances and advise the court.</p>
<p>Where domestic abuse is alleged, Practice Direction 12J is particularly important. It sets out requirements governing child-arrangements cases in which domestic abuse is alleged, admitted or otherwise considered relevant.</p>
<p>This means allegations capable of creating a safeguarding concern are taken seriously.</p>
<p>But &ldquo;taken seriously&rdquo; and &ldquo;automatically accepted as fact&rdquo; are not synonyms.</p>
<h2>Fact-Finding Hearings</h2>
<p>Where disputed allegations are relevant to the decisions the court needs to make, the court may determine that fact-finding is necessary.</p>
<p>The purpose is not to retry every argument that occurred during the relationship.</p>
<p>It is to determine factual issues that materially affect welfare and risk decisions.</p>
<p>For a parent facing allegations, this is another reason not to drown the case in hundreds of peripheral complaints.</p>
<p>Identify what matters.</p>
<p>A useful structure is:</p>
<ul>
<li>What exactly is alleged?</li>
<li>When is it said to have happened?</li>
<li>What do I accept?</li>
<li>What do I deny?</li>
<li>What evidence supports my position?</li>
<li>What contemporaneous evidence exists?</li>
<li>Are there material inconsistencies?</li>
<li>Why does this particular fact matter to the child's welfare?</li>
</ul>
<h2>Do Courts Sometimes Get Things Wrong?</h2>
<p>Of course.</p>
<p>Judges, solicitors, reporters, social workers, experts and parents are human beings. Human decision-making is not infallible.</p>
<p>Courts can misunderstand evidence. Evidence can be incomplete. Witnesses can be mistaken. Parents can lie. Parents can also honestly remember events differently. Professionals can form incorrect impressions. Genuine abuse can be missed. Innocent behaviour can sometimes be interpreted too negatively.</p>
<p>The existence of an appeal system itself recognises that judicial decisions can be challenged in appropriate circumstances.</p>
<p>But there is a huge difference between saying:</p>
<p><strong>&ldquo;Family justice is capable of error.&rdquo;</strong></p>
<p>and:</p>
<p><strong>&ldquo;Family courts simply believe women,&rdquo;</strong></p>
<p>or:</p>
<p><strong>&ldquo;Family courts always believe allegations without evidence.&rdquo;</strong></p>
<p>Those sweeping statements are unsupported and weaken serious criticism.</p>
<p>If your own experience has felt profoundly unfair, describe precisely what was unfair about it.</p>
<p>Specific criticism is harder to dismiss than conspiracy.</p>
<h2>The Evidence Folder: Start Here</h2>
<p>If you believe your relationship with your child is being undermined, create an organised evidence record.</p>
<p>Do not create a 900-page emotional diary detailing everything your former partner has ever done wrong.</p>
<p>Create a chronology.</p>
<p>A simple format is:</p>
<ul>
<li><strong>Date.</strong></li>
<li><strong>What was supposed to happen.</strong></li>
<li><strong>What actually happened.</strong></li>
<li><strong>Exact communication.</strong></li>
<li><strong>Evidence available.</strong></li>
<li><strong>Effect on the child/contact.</strong></li>
</ul>
<p>For example:</p>
<p><strong>14 May 2026 &ndash; Contact due at 10:00. At 09:17 I received a message stating that our daughter no longer wished to attend. I replied at 09:31 asking whether she was unwell and offering a shorter visit or telephone contact. No response received. Screenshot saved as Exhibit 14/05-A.</strong></p>
<p>Compare that with:</p>
<p><strong>&ldquo;She stopped me seeing my daughter again because she is obsessed with controlling me.&rdquo;</strong></p>
<p>The first is evidence.</p>
<p>The second is an interpretation.</p>
<h2>What Evidence Should You Preserve?</h2>
<p>Depending upon the circumstances, useful material may include:</p>
<ul>
<li>Emails between parents.</li>
<li>Text messages.</li>
<li>Messages sent through parenting applications.</li>
<li>Records of planned and missed contact.</li>
<li>School correspondence legitimately available to you.</li>
<li>Relevant medical information you are lawfully entitled to receive.</li>
<li>Letters from professionals.</li>
<li>Existing court orders.</li>
<li>Previous child welfare reports.</li>
<li>Police or social-work documentation where lawfully available.</li>
<li>Contemporaneous photographs where genuinely relevant.</li>
<li>Travel receipts demonstrating attendance at agreed handovers.</li>
<li>Evidence of attempts to maintain appropriate communication.</li>
<li>Records demonstrating the historical pattern of the relationship with your child.</li>
</ul>
<p>Do not edit screenshots in a way that removes relevant context.</p>
<p>Keep originals wherever possible.</p>
<p>Do not manufacture evidence.</p>
<p>Do not ask friends to exaggerate.</p>
<p>Do not create confrontations simply so that you can record them.</p>
<p>Your credibility is one of your most valuable assets.</p>
<h2>Create a Before-and-After Timeline</h2>
<p>Where there has been an abrupt deterioration in the parent-child relationship, comparison can be valuable.</p>
<p>Document the history objectively.</p>
<h3>Before the deterioration</h3>
<ul>
<li>How frequently did you see your child?</li>
<li>Were there overnight stays?</li>
<li>Were holidays taken together?</li>
<li>What school activities did you attend?</li>
<li>How often did you speak?</li>
<li>Were there affectionate messages?</li>
<li>Were any safeguarding complaints being made at that time?</li>
</ul>
<h3>After the deterioration</h3>
<ul>
<li>When did contact start changing?</li>
<li>What happened immediately beforehand?</li>
<li>What reason was given?</li>
<li>Did the child's language change?</li>
<li>Did allegations appear?</li>
<li>Were professional agencies contacted?</li>
<li>Was indirect contact also stopped?</li>
<li>What attempts did you make to resolve matters?</li>
</ul>
<p>The purpose is not to argue that photographs of happy holidays prove abuse could never have happened.</p>
<p>They don't.</p>
<p>The purpose is to give the court an accurate historical picture from which changes can be understood.</p>
<h2>Patterns Matter More Than Social Media Diagnoses</h2>
<p>One hostile message proves somebody sent one hostile message.</p>
<p>It does not prove narcissistic personality disorder.</p>
<p>Ten months of documented obstruction may demonstrate a pattern without requiring any psychiatric label whatsoever.</p>
<p>This is why diagnostic language can actually weaken your evidence.</p>
<p>Avoid turning pleadings or statements into TikTok psychology:</p>
<ul>
<li>&ldquo;She's a covert narcissist.&rdquo;</li>
<li>&ldquo;He's a dark empath.&rdquo;</li>
<li>&ldquo;She's a psychopath.&rdquo;</li>
<li>&ldquo;He's trauma bonded the child.&rdquo;</li>
<li>&ldquo;She's using DARVO, therefore everything she says is false.&rdquo;</li>
</ul>
<p>Even where a psychological concept has legitimate academic foundations, it does not diagnose the individual involved in your proceedings.</p>
<p>Describe what happened.</p>
<h2>What If You Believe Allegations Are False?</h2>
<p>False allegations do occur. So do genuine allegations that are wrongly dismissed as false.</p>
<p>Your task is not to decide which category all allegations belong to.</p>
<p>Your task is to answer the particular allegation against you.</p>
<p>For each disputed allegation, create four headings:</p>
<ul>
<li><strong>Allegation.</strong></li>
<li><strong>My response.</strong></li>
<li><strong>Independent evidence.</strong></li>
<li><strong>Material contradiction or context.</strong></li>
</ul>
<p>Keep emotion out of this document.</p>
<p>Suppose you are accused of preventing your child attending a medical appointment on 3 April.</p>
<p>A weak response is:</p>
<p><strong>&ldquo;She is lying again. She constantly fabricates things to destroy me.&rdquo;</strong></p>
<p>A stronger response is:</p>
<p><strong>&ldquo;I deny preventing the appointment. On 2 April at 18:43 I confirmed by text that I would take X to the appointment. The appointment was cancelled by the clinic at 08:15 the following morning. The clinic's cancellation message is attached.&rdquo;</strong></p>
<p>No personality analysis is required.</p>
<h2>Do Not Fight Every Allegation Equally</h2>
<p>This is a strategic mistake many distressed parents make.</p>
<p>If somebody produces 30 criticisms, you may feel compelled to answer all 30 with equal intensity.</p>
<p>But saying you arrived twelve minutes late once is not equivalent to alleging physical abuse.</p>
<p>Separate:</p>
<ul>
<li>Trivial disagreements.</li>
<li>Parenting differences.</li>
<li>Relevant welfare concerns.</li>
<li>Serious disputed allegations.</li>
<li>Matters capable of affecting contact or residence.</li>
</ul>
<p>Concede what is true.</p>
<p>If you lost your temper once and sent an unpleasant text, denying the obvious may damage your credibility far more than acknowledging it.</p>
<p>You can say:</p>
<p><strong>&ldquo;That message was inappropriate. I was angry and I should not have sent it. I have not communicated in that manner since.&rdquo;</strong></p>
<p>That is very different from conceding an allegation that you genuinely deny.</p>
<h2>Calm Communication Is Evidence Too</h2>
<p>From the moment serious conflict begins, write every message as though a sheriff, judge or family professional may read it six months later.</p>
<p>Because they might.</p>
<p>Good communication is:</p>
<ul>
<li>Brief.</li>
<li>Factual.</li>
<li>Polite.</li>
<li>Child-focused.</li>
<li>Free from diagnosis.</li>
<li>Free from threats.</li>
<li>Free from sarcasm.</li>
<li>Free from attempts to restart the relationship argument.</li>
</ul>
<p>Instead of:</p>
<p><strong>&ldquo;You've done it again. You're deliberately keeping him from me and one day everyone will find out what you're really like.&rdquo;</strong></p>
<p>write:</p>
<p><strong>&ldquo;I understand that today's contact will not take place. I remain available at the agreed time. If there is a specific concern preventing contact, please let me know so that we can try to resolve it appropriately.&rdquo;</strong></p>
<p>Boring communication is often excellent communication.</p>
<h2>Do Not Use Your Child as a Messenger</h2>
<p>Never say:</p>
<ul>
<li>&ldquo;Tell Mum she needs to answer my solicitor.&rdquo;</li>
<li>&ldquo;Ask Dad why he didn't pay.&rdquo;</li>
<li>&ldquo;Tell your mum I'm taking her back to court.&rdquo;</li>
<li>&ldquo;Tell Dad he can't keep getting away with this.&rdquo;</li>
</ul>
<p>Adults communicate with adults.</p>
<p>Children remain children.</p>
<h2>Do Not Run a Smear Campaign</h2>
<p>When you feel that somebody has destroyed your reputation, publicly exposing them can feel irresistible.</p>
<p>Resist it.</p>
<p>Do not turn TikTok, Facebook, Instagram, Discord or WhatsApp into an unofficial courtroom.</p>
<p>Do not publish allegations about your former partner.</p>
<p>Do not post identifiable details of family proceedings without understanding the legal restrictions that may apply.</p>
<p>Do not encourage followers to contact the other parent.</p>
<p>Do not recruit your child into an online campaign.</p>
<p>It does not demonstrate stability. It can create further evidence of parental conflict and may expose the child to material they should never have had to see.</p>
<h2>Never Tell Your Child: &ldquo;One Day You'll Know the Truth&rdquo;</h2>
<p>It sounds reassuring.</p>
<p>But underneath it sits another message:</p>
<p><strong>&ldquo;Someone you love is lying to you, and one day you will have to choose who.&rdquo;</strong></p>
<p>That still places the child in the middle.</p>
<p>Try:</p>
<p><strong>&ldquo;There are adult things happening that you do not need to solve. I love you and I'm here.&rdquo;</strong></p>
<h2>What If Contact Suddenly Stops?</h2>
<p>Do not respond with twenty messages.</p>
<p>Do not arrive unexpectedly at the child's home.</p>
<p>Do not attempt to collect the child from school unless you are clearly entitled and it is appropriate to do so.</p>
<p>Do not breach an existing court order or legal restriction.</p>
<p>Instead:</p>
<ul>
<li>Check the precise terms of any existing order.</li>
<li>Keep the communication explaining the cancellation.</li>
<li>Respond calmly.</li>
<li>Ask for the reason if none has been provided.</li>
<li>Suggest a reasonable alternative if appropriate.</li>
<li>Record the missed contact.</li>
<li>Seek family-law advice if obstruction becomes persistent.</li>
<li>Act urgently through appropriate professional channels if there is a genuine immediate safeguarding issue.</li>
</ul>
<p>One cancelled weekend is not necessarily a campaign of alienation.</p>
<p>A sustained unexplained pattern is something different.</p>
<h2>What If There Is Already a Court Order?</h2>
<p>Read the actual order rather than relying on what you remember it saying.</p>
<p>The wording matters.</p>
<p>If you believe the order is being breached, record each alleged failure accurately and speak to an appropriately qualified solicitor about the procedural options available in your jurisdiction.</p>
<p>Do not retaliate by breaching another part of the order yourself.</p>
<p>Two breaches do not cancel one another out.</p>
<h2>What If Your Ex Says: &ldquo;It's the Child's Choice&rdquo;?</h2>
<p>This is one of the hardest situations.</p>
<p>Children's wishes deserve respect, increasingly so as their age and maturity develop. But children's views do not exist in a vacuum.</p>
<p>Adults remain responsible for parenting.</p>
<p>If a ten-year-old says they never want to attend school again, a parent would normally explore why rather than simply replying that it is the child's decision.</p>
<p>A damaged parental relationship also deserves careful exploration.</p>
<p>The useful question becomes:</p>
<p><strong>&ldquo;What has led the child to this position, and what response now best promotes their welfare?&rdquo;</strong></p>
<p>That question respects the child without handing them responsibility for the entire adult dispute.</p>
<h2>When Your Child Uses Language That Does Not Sound Like Them</h2>
<p>Parents often become alarmed when a child begins using unusually adult terminology.</p>
<p>For example:</p>
<ul>
<li>&ldquo;Dad is emotionally abusive.&rdquo;</li>
<li>&ldquo;Mum is a narcissist.&rdquo;</li>
<li>&ldquo;I need boundaries because you're toxic.&rdquo;</li>
<li>&ldquo;You manipulated the legal process.&rdquo;</li>
</ul>
<p>Adult-sounding language can justify careful curiosity, but it does not establish coaching.</p>
<p>Children hear language from:</p>
<ul>
<li>Parents.</li>
<li>Teachers.</li>
<li>Therapists.</li>
<li>Social media.</li>
<li>Friends.</li>
<li>Older siblings.</li>
<li>Professionals.</li>
<li>Television and online content.</li>
</ul>
<p>Record the words accurately if they are important. Do not leap from vocabulary to proof of manipulation.</p>
<h2>What Should You Ask a Family Solicitor?</h2>
<p>If the relationship is seriously deteriorating, obtain advice early where possible.</p>
<p>Useful questions include:</p>
<ul>
<li>What orders are currently in force?</li>
<li>What parental responsibilities and rights do I currently have?</li>
<li>What remedy is actually available in this jurisdiction?</li>
<li>Is an urgent application necessary?</li>
<li>Would mediation be appropriate or inappropriate?</li>
<li>How should allegations be formally answered?</li>
<li>What evidence is legally relevant?</li>
<li>Should a child welfare report or other independent assessment be considered?</li>
<li>How can my child's views be obtained appropriately?</li>
<li>What should I avoid doing while proceedings are active?</li>
<li>What are the consequences of any existing criminal or protective order?</li>
<li>Are there restrictions on communication or publication that I need to understand?</li>
</ul>
<p>Bring a concise chronology to the appointment.</p>
<p>Your solicitor will thank you.</p>
<h2>The One-Page Chronology</h2>
<p>Try reducing the central history to one page before expanding it.</p>
<p>For example:</p>
<ul>
<li><strong>January 2025:</strong> Parents separate.</li>
<li><strong>February&ndash;June:</strong> Alternate-weekend contact continues.</li>
<li><strong>14 July:</strong> First contact cancelled.</li>
<li><strong>22 July:</strong> Child begins refusing telephone calls.</li>
<li><strong>4 August:</strong> First safeguarding allegation communicated.</li>
<li><strong>7 August:</strong> Allegation denied in writing.</li>
<li><strong>August&ndash;September:</strong> Five scheduled contacts do not occur.</li>
<li><strong>18 September:</strong> Solicitor writes proposing supported contact.</li>
<li><strong>25 September:</strong> Proposal refused.</li>
<li><strong>October:</strong> Court application initiated.</li>
</ul>
<p>Now the reader can see the structure of the problem in seconds.</p>
<h2>Evidence Is Not About Creating the Biggest Bundle</h2>
<p>More material is not necessarily better evidence.</p>
<p>Five hundred screenshots can bury the three messages that actually matter.</p>
<p>Think in terms of relevance:</p>
<ul>
<li>What proposition am I trying to demonstrate?</li>
<li>What document supports it?</li>
<li>Does the document actually say what I claim?</li>
<li>Is there context that changes its meaning?</li>
<li>Can somebody understand it without hearing a ten-minute explanation?</li>
</ul>
<h2>If You Made Mistakes, Own Them</h2>
<p>You do not have to present yourself as a perfect parent.</p>
<p>No such parent exists.</p>
<p>A court is unlikely to be shocked that two people going through an ugly separation occasionally behaved badly.</p>
<p>What matters is the nature of the behaviour, its effect on the child, the existence of risk and whether the adults can now put the child's needs ahead of their conflict.</p>
<p>Accountability can strengthen credibility.</p>
<p>For example:</p>
<p><strong>&ldquo;I accept that I sent several angry messages immediately after separation. They were inappropriate. I stopped doing so, sought support and have since kept communication limited to arrangements concerning our child.&rdquo;</strong></p>
<p>This demonstrates insight.</p>
<h2>Do Not Turn &ldquo;Grey Rock&rdquo; Into Hostility</h2>
<p>People sometimes misunderstand grey-rock communication as permission to become cold or deliberately obstructive.</p>
<p>That is not useful co-parenting.</p>
<p>A better principle in high-conflict situations is emotionally neutral, practical communication.</p>
<p>Think:</p>
<p><strong>Brief. Informative. Civil. Child-focused.</strong></p>
<p>You are reducing opportunities for conflict without refusing necessary parental communication.</p>
<h2>Protect Your Own Nervous System</h2>
<p>Long-running family conflict can make your body behave as though you are under permanent threat.</p>
<p>You may:</p>
<ul>
<li>Constantly check your phone.</li>
<li>Replay hearings in your head.</li>
<li>Read the same allegation repeatedly.</li>
<li>Lose sleep preparing imaginary arguments.</li>
<li>Experience anger whenever an email arrives.</li>
<li>Become hypervigilant.</li>
<li>Withdraw socially.</li>
<li>Start treating every interaction as evidence.</li>
</ul>
<p>This does not mean the situation is imaginary.</p>
<p>It means chronic stress is affecting your nervous system.</p>
<p>Create boundaries around the case.</p>
<ul>
<li>Check legal correspondence at planned times where practical.</li>
<li>Do not reread hostile messages at midnight.</li>
<li>Keep exercising.</li>
<li>Eat properly.</li>
<li>Sleep whenever you can.</li>
<li>Talk to trusted people who do not inflame the conflict.</li>
<li>Consider professional psychological support.</li>
<li>Keep parts of your identity that have nothing to do with being in litigation.</li>
</ul>
<p>Your child needs a parent, not a permanently activated litigant.</p>
<h2>Do Not Let the Case Become Your Identity</h2>
<p>This may be the hardest advice in this article.</p>
<p>When somebody interferes with one of the most important relationships in your life, the injustice can consume everything.</p>
<p>You become:</p>
<p><strong>The falsely accused father.</strong></p>
<p><strong>The alienated mother.</strong></p>
<p><strong>The parent fighting the system.</strong></p>
<p>But you are still a human being outside the dispute.</p>
<p>You still have friendships.</p>
<p>You still have values.</p>
<p>You still have work.</p>
<p>You still have creativity.</p>
<p>You still have a future.</p>
<p>Maintaining your life is not giving up on your child.</p>
<p>It is protecting the person you hope they will someday reconnect with.</p>
<h2>A Practical 30-Day Response Plan</h2>
<h3>Days 1&ndash;3: Stop the Emotional Bleeding</h3>
<ul>
<li>Do not send angry messages.</li>
<li>Do not publish anything online.</li>
<li>Read every existing court order carefully.</li>
<li>Identify any immediate safeguarding or legal restrictions.</li>
<li>Back up relevant communications.</li>
</ul>
<h3>Days 4&ndash;7: Build the Chronology</h3>
<ul>
<li>Record the previous contact pattern.</li>
<li>Identify when circumstances changed.</li>
<li>List cancelled or refused contacts.</li>
<li>Attach the relevant evidence to each important event.</li>
<li>Separate fact from interpretation.</li>
</ul>
<h3>Days 8&ndash;14: Obtain Appropriate Advice</h3>
<ul>
<li>Speak to a family-law solicitor if necessary.</li>
<li>Take your one-page chronology.</li>
<li>Take existing orders.</li>
<li>Identify the specific outcome you want.</li>
<li>Ask what evidence is relevant rather than dumping everything on the solicitor.</li>
</ul>
<h3>Days 15&ndash;21: Stabilise Communication</h3>
<ul>
<li>Keep messages brief and polite.</li>
<li>Stop arguing about the relationship.</li>
<li>Do not diagnose the other parent.</li>
<li>Make reasonable child-focused proposals.</li>
<li>Preserve responses accurately.</li>
</ul>
<h3>Days 22&ndash;30: Think Long Term</h3>
<ul>
<li>Ask what your child needs emotionally.</li>
<li>Consider whether supported or indirect contact could maintain a bridge where direct contact is temporarily difficult.</li>
<li>Address any legitimate criticism of your own parenting.</li>
<li>Continue documenting significant events without obsessively recording ordinary life.</li>
<li>Build emotional support for yourself.</li>
</ul>
<h2>The Question You Should Keep Asking Yourself</h2>
<p>Before sending a message, filing a document or responding to an accusation, ask:</p>
<p><strong>&ldquo;Will this help my child have a safer, healthier relationship with me?&rdquo;</strong></p>
<p>If the answer is no, reconsider it.</p>
<p>That does not mean becoming passive.</p>
<p>It does not mean accepting false allegations.</p>
<p>It does not mean allowing court orders to be ignored.</p>
<p>It means choosing purposeful action instead of reactive action.</p>
<h2>If You Are Being Falsely Accused, Calmness Is Not Surrender</h2>
<p>There is a temptation to believe that unless you demonstrate how furious you are, nobody will understand the seriousness of what has happened.</p>
<p>But anger does not increase the evidential value of your argument.</p>
<p>Sometimes it hides it.</p>
<p>You can challenge an allegation firmly:</p>
<p><strong>&ldquo;I deny this allegation. The contemporaneous material contradicts it, and I ask that it is properly determined.&rdquo;</strong></p>
<p>That is not weak.</p>
<p>It is controlled.</p>
<h2>The Goal Is Not to Make Your Child Admit You Were Right</h2>
<p>Imagine that after years of separation your child eventually contacts you.</p>
<p>What do you want the first conversation to become?</p>
<p>A cross-examination?</p>
<p>&ldquo;Do you finally realise what your mother did?&rdquo;</p>
<p>&ldquo;Are you ready to admit they lied?&rdquo;</p>
<p>&ldquo;Why didn't you defend me?&rdquo;</p>
<p>Or do you want your child to discover that there is still somewhere emotionally safe to land?</p>
<p>The healthier doorway sounds more like:</p>
<p><strong>&ldquo;I'm glad you're here. We don't have to solve everything today.&rdquo;</strong></p>
<p>That does not erase the past.</p>
<p>It stops the past consuming the possibility of a future.</p>
<h2>The Grey Position</h2>
<p>This is where the Grey Method becomes especially relevant.</p>
<p>The Grey is not pretending that both sides are equally responsible.</p>
<p>It is not tolerating abuse.</p>
<p>It is not refusing to call out harmful behaviour.</p>
<p>It is the ability to remain psychologically centred enough to distinguish what you <strong>know</strong> from what you <strong>believe</strong>.</p>
<p>You may know that six contacts were cancelled.</p>
<p>You may believe the motive was to destroy your relationship with your child.</p>
<p>Those are different propositions.</p>
<p>You may know that an allegation was made.</p>
<p>You may believe the allegation was deliberately fabricated.</p>
<p>Again, those are different propositions.</p>
<p>Remaining in the Grey means refusing to inflate certainty simply because you are in pain.</p>
<p>Paradoxically, that often makes your argument considerably stronger.</p>
<h2>What You Can Control</h2>
<p>You cannot directly control:</p>
<ul>
<li>What your ex says.</li>
<li>What your ex believes.</li>
<li>How quickly proceedings move.</li>
<li>What another person tells a professional.</li>
<li>What your child currently feels.</li>
<li>Every conclusion reached by a court.</li>
</ul>
<p>You can control:</p>
<ul>
<li>Whether you communicate calmly.</li>
<li>Whether your evidence is organised.</li>
<li>Whether you follow court orders.</li>
<li>Whether you obtain appropriate advice.</li>
<li>Whether you expose your child to adult conflict.</li>
<li>Whether you acknowledge your own mistakes.</li>
<li>Whether you remain emotionally available to your child.</li>
<li>Whether you behave today like the parent you say you are.</li>
</ul>
<h2>Final Thoughts: Become the Stable Point</h2>
<p>If your former partner really is attempting to undermine your relationship with your child, becoming equally hostile will not rescue that relationship.</p>
<p>It gives the child two unstable adults instead of one.</p>
<p>If allegations are false, answer them with evidence.</p>
<p>If evidence is incomplete, identify what is missing.</p>
<p>If your own behaviour contributed to the breakdown, own it and change it.</p>
<p>If your child is angry, listen.</p>
<p>If your child rejects you, do not punish them for it.</p>
<p>If the law gives you a remedy, use it properly.</p>
<p>If an order restricts what you may do, obey it unless and until it is lawfully changed.</p>
<p>And if you believe a court has reached the wrong decision, challenge it through appropriate legal processes rather than through your child.</p>
<p>The central objective is not vindication.</p>
<p>It is protecting the child's opportunity to have safe, healthy relationships and protecting your own ability to remain a safe parent.</p>
<p>Your child may be surrounded by competing narratives.</p>
<p>You do not need to create another one.</p>
<p>Create consistency.</p>
<p>Create evidence.</p>
<p>Create calm.</p>
<p>Create a doorway that remains emotionally safe for your child to walk through.</p>
<p><strong>You do not win this by making your child choose you.</strong></p>
<p><strong>You win by making sure they never needed to choose in the first place.</strong></p>
<h2>Important Legal Note</h2>
<p>This article provides general educational information about family conflict, child relationships and the broad family-law framework in Scotland and England and Wales. It is not individual legal advice. Family cases are highly fact-specific, and existing court orders, domestic-abuse allegations, criminal proceedings, non-harassment orders and other protective measures can substantially change what a parent may lawfully do. Obtain advice from a solicitor qualified in the relevant jurisdiction before taking action in an individual case. If a child or adult is in immediate danger, contact the appropriate emergency or safeguarding service.</p>
<h2>Further Reading and Official Sources</h2>
<ul>
<li><a href="https://www.legislation.gov.uk/ukpga/1995/36/section/11" target="_blank" rel="noopener">Children (Scotland) Act 1995 &ndash; Section 11</a></li>
<li><a href="https://www.legislation.gov.uk/asp/2020/16" target="_blank" rel="noopener">Children (Scotland) Act 2020</a></li>
<li><a href="https://www.scotcourts.gov.uk/rules-and-practice/" target="_blank" rel="noopener">Scottish Courts and Tribunals Service &ndash; Rules and Practice</a></li>
<li><a href="https://www.legislation.gov.uk/ukpga/1989/41/section/1" target="_blank" rel="noopener">Children Act 1989 &ndash; Section 1</a></li>
<li><a href="https://www.justice.gov.uk/courts/procedure-rules/family/practice_directions/pd_part_12j" target="_blank" rel="noopener">Practice Direction 12J &ndash; Child Arrangements and Domestic Abuse</a></li>
<li><a href="https://www.cafcass.gov.uk/parent-carer-or-family-member/applications-child-arrangements-order/how-your-family-court-adviser-makes-their-assessment-your-childs-welfare-and-best-interests/alienating-behaviours" target="_blank" rel="noopener">Cafcass &ndash; Alienating Behaviours</a></li>
</ul>

---
title: "The Book of DARVO: When Blame Becomes a Weapon"
seoTitle: "The Book of DARVO: Blame, Smearing & Psychological Abuse"
metaDescription: "Andy Fish announces The Book of DARVO, exploring blame reversal, smear campaigns, coercive control, economic abuse, family conflict and how to fight back with e"
slug: "the-book-of-darvo"
categories: "Updates"
tags: "['DARVO', 'Book']"
author: "Reiki Fish"
featured: true
draft: false
date: "2026-08-06"
excerpt: "The Book of DARVO is a new work from Andy Fish exploring what happens when accountability becomes blame reversal. Discover the psychology of DARVO, smear campaigns, coercive control, economic abuse, children caught in adult conflict and why evidence can be more powerful than retaliation."
featuredImage: "assets/images/blog/book_of_darvo.png"
featuredImageAlt: "The Book of DARVO by Andy Fish explores blame reversal, smear campaigns, coercive control and psychological abuse."
---

<p>I have started work on a new book. Its working title is&nbsp;<strong>The Book of DARVO</strong>, and it will examine one of the most fascinating, destructive and frequently misunderstood patterns in interpersonal psychology: what happens when accountability is turned upside down.</p>
<p>DARVO stands for <strong>Deny, Attack, and Reverse Victim and Offender</strong>. The term was introduced by psychologist Jennifer J. Freyd to describe a response that may occur when someone is confronted about alleged wrongdoing. At its simplest, the pattern involves denying the behaviour, attacking the person raising the concern and then reversing the roles so that the person originally confronted presents themselves as the victim.</p>
<p>That description sounds relatively straightforward. In real relationships, however, the psychological dynamics can become far more complicated. The original allegation can disappear beneath counter-allegations, attacks on credibility, competing accounts of events and attempts to recruit other people into a particular version of the story.</p>
<p><em>The Book of DARVO</em> will explore that wider landscape, including blame reversal, smear campaigns, coercive control, post-separation behaviour, economic abuse, children becoming caught in adult conflict and, importantly, how someone can respond without allowing the conflict to consume their life.</p>
<p>This will not be another book teaching people how to diagnose everyone around them as a narcissist. The focus will be on something much more useful: <strong>behaviour, patterns, context and evidence.</strong></p>
<h2>What Does DARVO Actually Look Like?</h2>
<p>Imagine confronting someone about a specific behaviour. You explain what happened and ask them to address it. Instead of engaging with the original issue, the conversation begins moving somewhere else.</p>
<p>The first response may be denial: &ldquo;That never happened&rdquo;, &ldquo;You're remembering it incorrectly&rdquo; or &ldquo;You've completely made this up&rdquo;. Denial alone proves nothing. An innocent person can obviously deny something they did not do. DARVO becomes relevant when that denial forms part of a wider pattern.</p>
<p>The next stage is the attack. Instead of examining the original allegation, attention moves towards the person who raised it. Their honesty, motives, personality, mental health, relationships or previous behaviour may suddenly become the subject of discussion.</p>
<p>Finally, there may be a reversal of victim and offender. The person originally confronted begins presenting themselves as the person who has been harmed, while the person who raised the concern is repositioned as the aggressor.</p>
<p>The extraordinary part is that the original issue can become almost irrelevant. The person who initially sought accountability may now spend most of their time trying to prove that they are not unstable, dishonest, vindictive or abusive.</p>
<p>Research into DARVO has found evidence that exposure to these responses can influence perceptions of victims and perpetrators. This is one reason understanding the pattern matters. It is not a psychological lie detector, but it can help us recognise when a discussion about behaviour has transformed into a battle over credibility.</p>
<h2>The Credibility Battlefield</h2>
<p>One of the central ideas I want to explore in <em>The Book of DARVO</em> is what I describe as the <strong>credibility battlefield</strong>.</p>
<p>When an allegation cannot easily be made to disappear, attention may instead turn towards the credibility of the person making it. The practical effect becomes: do not simply challenge the allegation; challenge the storyteller.</p>
<p>This is where smear campaigns can become particularly destructive.</p>
<p>Once someone's character has been successfully questioned, almost everything they subsequently do can be interpreted through that damaged reputation. Their distress can be portrayed as instability. Their anger can be described as aggression. Their evidence gathering can be presented as obsession. Their attempts to explain themselves may be characterised as harassment.</p>
<p>Even silence can be interpreted negatively.</p>
<p>This creates a psychological trap. The person feels compelled to defend themselves continuously, but the more energy they devote to defending their character, the further everyone moves from the original question.</p>
<h2>Is There Really a &ldquo;Gameplay&rdquo; to DARVO?</h2>
<p>I use the term <strong>gameplay</strong> cautiously because psychology cannot assume that every person displaying these behaviours is consciously following a calculated strategy.</p>
<p>Defensive behaviour can be reactive, learned, habitual, strategic or a mixture of several processes. What matters is that repeated patterns can still produce recognisable outcomes.</p>
<p>A DARVO-like sequence can involve:</p>
<ul>
<li>
<p>An allegation or attempt to establish accountability.</p>
</li>
<li>
<p>Denial or minimisation of the original behaviour.</p>
</li>
<li>
<p>Attacks upon the credibility or motives of the person raising it.</p>
</li>
<li>
<p>Counter-allegations that redirect attention.</p>
</li>
<li>
<p>Friends, relatives, professionals or wider social networks becoming involved.</p>
</li>
<li>
<p>Increasing confusion about who originally alleged what.</p>
</li>
<li>
<p>The person who raised the original concern spending more time defending themselves than discussing the behaviour that started the conflict.</p>
</li>
</ul>
<p>This last stage can be particularly powerful. When someone is permanently defending themselves, they have less emotional capacity to keep attention focused upon the original issue.</p>
<h2>Smearing Can Become More Powerful Than the Original Denial</h2>
<p>A smear campaign does not simply mean somebody saying something unpleasant about you. Genuine criticism, disagreement and conflicting recollections are normal parts of human relationships.</p>
<p>The concern arises when there is a repeated attempt to undermine someone's standing or credibility rather than address evidence.</p>
<p>Attacks may focus upon a person's honesty, parenting, mental health, employment, relationships, finances, sexual history, emotional reactions or previous mistakes. Allegations can then spread through friendship groups, families, workplaces, professional organisations or social media.</p>
<p>The instinctive response is often to fight back immediately.</p>
<p>That can become another trap.</p>
<p>Someone starts writing enormous explanations, responding to every accusation, checking social media constantly and trying to convince increasingly distant people of their innocence. The dispute gradually occupies every waking hour.</p>
<p>At some point, defending your reputation can become indistinguishable from living entirely inside the conflict.</p>
<h2>How Do You Work Against DARVO?</h2>
<p>This will form one of the practical foundations of the book.</p>
<p>The answer is not learning how to manipulate more effectively than somebody else. Nor is it retaliating with a larger smear campaign or diagnosing the other person with increasingly severe psychological conditions.</p>
<p>The first principle is remarkably simple:</p>
<p><strong>Return to the evidence.</strong></p>
<p>Ask what actually happened, when it happened, what was said, what evidence exists and what happened immediately afterwards. Establish when counter-allegations appeared and distinguish observable facts from interpretations.</p>
<p>If a dispute matters enough to document, useful practices can include:</p>
<ul>
<li>
<p>Keeping original messages and emails.</p>
</li>
<li>
<p>Preserving complete conversations rather than favourable fragments.</p>
</li>
<li>
<p>Maintaining an accurate dated chronology.</p>
</li>
<li>
<p>Separating what you personally witnessed from information supplied by somebody else.</p>
</li>
<li>
<p>Keeping important communications factual and proportionate.</p>
</li>
<li>
<p>Preserving original documents wherever possible.</p>
</li>
<li>
<p>Avoiding exaggeration.</p>
</li>
<li>
<p>Correcting genuine mistakes in your own account.</p>
</li>
<li>
<p>Never manufacturing evidence or coaching other people about what to say.</p>
</li>
</ul>
<p>In simple terms: <strong>document behaviour rather than diagnosing people.</strong></p>
<p>Saying, &ldquo;My ex is a narcissist who constantly uses DARVO&rdquo; is an interpretation. Saying, &ldquo;On 12 May I raised this issue; the response did not address it and instead contained three new allegations; I retained the complete conversation&rdquo; provides information that somebody else can examine.</p>
<h2>When Children Become Caught in Adult Conflict</h2>
<p>This is one of the most serious areas the book will examine.</p>
<p>Children should never become tools through which adults continue a relationship conflict. They should not have to decide which parent they are permitted to love, nor should they become messengers, investigators, emotional confidants or witnesses in an adult campaign.</p>
<p>Cafcass currently uses the term <strong>alienating behaviours</strong> to describe an ongoing pattern of negative attitudes or communication by a parent or carer that has the potential or intention to undermine, manipulate or destroy a child's relationship with another parent or carer.</p>
<p>Potentially harmful behaviours can include repeatedly criticising another parent to the child, asking the child to carry hostile messages, interrogating them about another household, involving them in adult allegations, encouraging them to monitor another parent or making affection and approval feel dependent upon loyalty.</p>
<p>However, there is an essential safeguard here.</p>
<p>A child refusing or resisting contact does <strong>not</strong> automatically prove manipulation or alienating behaviour. Children can have legitimate reasons for fearing or rejecting a parent, including their own experiences of abuse, neglect, frightening behaviour or damaged relationships.</p>
<p>The correct psychological question is therefore not simply, &ldquo;Has this child been alienated?&rdquo;</p>
<p>It is: <strong>&ldquo;Why has this child's relationship changed, and what evidence best explains it?&rdquo;</strong></p>
<p>DARVO does not prove parental alienation, and an allegation of parental alienation does not prove DARVO. Every case needs to be examined on its own evidence.</p>
<h2>Never Turn the Child Into Your Evidence Collector</h2>
<p>When a parent believes their child is being influenced, desperation can create an overwhelming need to ask questions.</p>
<p>&ldquo;What did Mum say?&rdquo;</p>
<p>&ldquo;What did Dad tell you?&rdquo;</p>
<p>&ldquo;Who told you that?&rdquo;</p>
<p>&ldquo;You know that's not true, don't you?&rdquo;</p>
<p>Repeated questioning can create additional psychological pressure and may contaminate the child's account.</p>
<p>A child should not become responsible for establishing a parent's innocence. They should not have to protect an adult's reputation or learn which answers make a parent happy.</p>
<p>Sometimes one of the most protective things an adult can communicate is simply:</p>
<p><strong>&ldquo;You do not have to choose between us.&rdquo;</strong></p>
<p>Where serious allegations or court proceedings exist, appropriate professionals should be allowed to investigate the child's experiences without the child being rehearsed by either side.</p>
<h2>Economic Abuse: When Control Continues Through Money</h2>
<p>Another major area I intend to examine is economic abuse.</p>
<p>Abuse does not have to involve physical violence. In England and Wales, the Domestic Abuse Act 2021 expressly recognises economic abuse, and statutory guidance acknowledges that forms of economic abuse may continue after separation.</p>
<p>Economic abuse can interfere with somebody's ability to acquire, use or maintain money, property, goods or services. Its consequences can be profound because money affects housing, independence, transport, legal representation and the ability to rebuild a life after a relationship ends.</p>
<p>Post-separation economic control may therefore create continuing dependency or instability long after the emotional relationship has finished.</p>
<p>DARVO and economic abuse are not the same phenomenon. However, blame reversal, coercive behaviour and economic control can occur within the same broader relationship dynamic.</p>
<p>The book will look carefully at these overlaps without pretending that one automatically proves another.</p>
<h2>Don't Try to Win the Smear War</h2>
<p>This may be one of the hardest lessons.</p>
<p>When somebody damages your reputation, every instinct tells you to expose them.</p>
<p>You want everyone to see the evidence. You want to correct every allegation. You want the world to understand what really happened.</p>
<p>But retaliation can escalate the conflict.</p>
<p>Before responding publicly, ask a simple question:</p>
<p><strong>Who genuinely needs this information?</strong></p>
<p>A solicitor may need relevant evidence. A court may need it. A safeguarding professional may need it. The police may require information concerning an alleged offence. An employer may legitimately need to know about harassment affecting the workplace.</p>
<p>Thousands of strangers on social media probably do not need your complete evidence file.</p>
<p>Sometimes protecting yourself means refusing to participate in the public version of the fight.</p>
<h2>Emotional Regulation Is Part of the Response</h2>
<p>DARVO can provoke exactly the psychological state that makes clear decision making difficult.</p>
<p>Someone who believes they are being falsely portrayed may experience anger, panic, rumination, hypervigilance and an overwhelming urge to correct everything immediately.</p>
<p>That reaction is understandable.</p>
<p>It is also why emotional regulation matters.</p>
<p>Pause before responding. Preserve the information. Check the facts. Decide who actually needs to know. Respond proportionately. Seek appropriate professional advice where necessary.</p>
<p>You cannot always control what another person says about you, but you can work on controlling what you do with the next ten minutes.</p>
<p>This is much easier to write than to accomplish when someone's children, reputation, finances or home are involved. That is precisely why this subject deserves something deeper than another ten-point social media checklist.</p>
<h2>DARVO Does Not Mean Narcissism</h2>
<p>This will be repeated throughout the book because internet psychology has blurred the distinction between behaviour and diagnosis.</p>
<p>DARVO does not equal Narcissistic Personality Disorder.</p>
<p>Lying does not automatically make somebody a narcissist.</p>
<p>Smearing somebody does not automatically establish psychopathy.</p>
<p>Manipulative behaviour does not allow us to diagnose a Cluster B personality disorder from a distance.</p>
<p>Psychiatric labels can sometimes distract from the strongest information available: <strong>observable behaviour</strong>.</p>
<p>If somebody repeatedly intimidates, controls, financially abuses, threatens or manipulates another person, those behaviours deserve attention regardless of whether a personality disorder is ever diagnosed.</p>
<h2>Why I Am Writing The Book of DARVO</h2>
<p>I believe DARVO is bigger than an acronym.</p>
<p>It raises difficult questions about credibility, power, reputation, memory, institutions, relationships and the way human beings decide whom to believe.</p>
<p>It also requires us to accept uncomfortable complexity.</p>
<p>Real victims can be disbelieved. False allegations can occur. People who engage in harmful behaviour can portray themselves as victims. Children can be influenced by adults. Children can also reject parents for genuine reasons. Economic abuse can continue after separation. Someone can display DARVO-like behaviour without having a personality disorder.</p>
<p>These realities do not cancel one another out.</p>
<p>Evidence-led psychology needs to be capable of examining all of them.</p>
<p><em>The Book of DARVO</em> will not be a guide to diagnosing your ex. It will explore how these patterns operate, what psychology tells us about them, why reputation and credibility become so important, how children and finances can become drawn into post-separation conflict and how somebody can protect themselves without losing their identity to the battle.</p>
<p>Most importantly, the book will return repeatedly to one principle:</p>
<p><strong>When the story becomes confusing, return to what can actually be established.</strong></p>
<h2>The Book of DARVO Is Now in Development</h2>
<p>This is only the beginning.</p>
<p>Over the coming months, I will share more from <em>The Book of DARVO</em>, including research, psychological concepts, practical frameworks and some of the difficult questions surrounding blame reversal, post-separation abuse, family conflict, economic abuse and recovery.</p>
<p>The goal is not another internet manual for labelling people.</p>
<p>I want to create something deeper: evidence led, psychologically responsible and genuinely practical for people trying to understand what happens when an attempt at accountability becomes a battle over their own character.</p>
<p>Sometimes the strongest response to a reversed narrative is not shouting louder.</p>
<p>It is becoming calmer, clearer and increasingly difficult to move away from the evidence.</p>
<p><strong>The Book of DARVO &mdash; a new work in development from Andy Fish, author of <em>Walking the Grey</em> and creator of Reiki Fish.</strong></p>
<h2>Further Reading</h2>
<p>While <em>The Book of DARVO</em> is being developed, you can read my comprehensive evidence-led introduction to the subject:</p>
<p><strong><a href="https://reikifish.com/articles/what-is-darvo-denial-attack-reverse-victim-offender">What Is DARVO? Deny, Attack and Reverse Victim and Offender</a></strong></p>
<p>Research and guidance informing this article include <a href="https://www.jjfreyd.com/darvo">Jennifer Freyd's DARVO resource</a>, <a href="https://pubmed.ncbi.nlm.nih.gov/37154429/">peer-reviewed DARVO research indexed by PubMed</a>, <a href="https://www.cafcass.gov.uk/parent-carer-or-family-member/applications-child-arrangements-order/how-your-family-court-adviser-makes-their-assessment-your-childs-welfare-and-best-interests/alienating-behaviours">Cafcass guidance on alienating behaviours</a> and <a href="https://www.gov.uk/government/publications/controlling-or-coercive-behaviour-statutory-guidance-framework/controlling-or-coercive-behaviour-statutory-guidance-framework-accessible">UK Government statutory guidance on controlling or coercive behaviour</a>.</p>
<p><em>This article is educational and discusses general psychological and behavioural concepts. DARVO is not a psychiatric diagnosis and should not be used as proof that an allegation is true or false. Domestic abuse, safeguarding, economic abuse and family court matters require assessment according to the individual circumstances and appropriate professional advice.</em></p>

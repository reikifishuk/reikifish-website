---
title: "My Ex Won’t Let Me See My Children: What Can I Do as a Dad?"
seoTitle: "Ex Won’t Let Me See My Child? Advice for Dads UK"
metaDescription: "Ex won’t let you see your child? Practical UK guidance for dads on contact, evidence, domestic abuse, DARVO and what to do after separation."
slug: "ex-wont-let-me-see-my-child-what-dads-can-do"
categories: "Parental Alienation & DARVO"
tags: "['Separated Fathers', 'Child Contact', 'Fathers Rights', 'DARVO', 'Domestic Abuse', 'Parental Alienation', 'Family Separation', 'Coercive Control']"
author: "Reiki Fish"
featured: false
draft: false
date: "2026-08-07"
excerpt: "Has your ex stopped you seeing your children after separation? A practical guide for dads on acting early, documenting evidence, domestic abuse, DARVO, child contact and protecting your relationship with your children."
featuredImage: "assets/images/blog/parental_alienation_i_cant_se_my_kids.png"
featuredImageAlt: "Separated father seeking help after his ex stops contact with his children following a relationship breakdown"
---

<p>Separation is difficult enough. Suddenly losing contact with your children can make it unbearable.</p>
<p>For some fathers, a relationship ends and almost overnight their relationship with their children changes too.</p>
<p>Phone calls stop. Messages go unanswered. Weekends are cancelled. Information about school, health and important events may disappear. A father who was involved in breakfast, school runs, homework, bedtime and ordinary family life can suddenly find himself standing outside his children's lives.</p>
<p>There can, of course, be genuine safeguarding reasons why contact needs to be restricted or reconsidered. Those concerns must always be taken seriously.</p>
<p>But there is another issue that should not be minimised.</p>
<p>Within separated-parent communities, charities and support groups, a recurring concern is raised by fathers who say that following separation their relationship with their children became another arena for conflict or control.</p>
<p>Contact may become restricted. Communication may deteriorate. Allegations may emerge. Children may become caught between conflicting adult accounts.</p>
<p>In more serious situations, behaviour may develop that appears to undermine the child's relationship with the other parent.</p>
<p>That deserves to be examined properly.</p>
<p>This isn't about assuming the mother is wrong or the father is right.</p>
<p>It is about asking a much more important question:</p>
<blockquote>
<p><strong>What is actually happening to the child and what evidence exists to establish it?</strong></p>
</blockquote>
<h2>When Contact Becomes a Means of Control</h2>
<p>We should not minimise the potential harm caused when a child's relationship with a safe and loving parent is unnecessarily disrupted.</p>
<p>In some high-conflict or abusive separations, fathers describe a disturbing reversal.</p>
<p>A father may raise concerns about behaviour he says he experienced during the relationship, only to subsequently find himself facing allegations of being controlling, abusive or dangerous.</p>
<p>In some circumstances, the pattern described may resemble <strong>DARVO</strong>.</p>
<p>DARVO stands for:</p>
<ul>
<li><strong>Deny</strong></li>
<li><strong>Attack</strong></li>
<li><strong>Reverse Victim and Offender</strong></li>
</ul>
<p>The term was introduced by psychologist Jennifer Freyd to describe a particular response to allegations of wrongdoing: alleged behaviour is denied, the person raising the concern is attacked, and the roles of victim and offender may appear to become reversed.</p>
<p>It is important, however, to use DARVO responsibly.</p>
<p>A disagreement between former partners is not automatically DARVO. A counter-allegation is not automatically false. Describing behaviour as resembling DARVO does not prove that somebody is an abuser or establish whose account of events is correct.</p>
<p>Instead, look at the evidence.</p>
<ul>
<li>What happened?</li>
<li>When did it happen?</li>
<li>What was actually said?</li>
<li>What evidence exists?</li>
<li>Were concerns raised before or after separation?</li>
<li>Did behaviour change following separation?</li>
<li>What effect is the conflict having on the children?</li>
</ul>
<p>Those questions are much more useful than simply attaching a label to another person.</p>
<h2>If You Left an Abusive Relationship, Do Not Automatically Stay Silent</h2>
<p>One mistake male victims can make is thinking:</p>
<blockquote>
<p>"I'll leave quietly. I don't want any trouble. Once I'm gone, it'll all be over."</p>
</blockquote>
<p>Unfortunately, leaving a relationship does not necessarily end abusive behaviour.</p>
<p>Where abuse has genuinely occurred, controlling behaviour can continue following separation.</p>
<p>Children, communication, finances, property and parenting arrangements can all become new areas of conflict.</p>
<p>And men can be victims of domestic abuse.</p>
<p>Domestic abuse isn't restricted to physical violence.</p>
<p>Depending upon the facts and relevant law, it can include threatening behaviour, coercive or controlling behaviour, psychological or emotional abuse, physical or sexual violence and economic abuse.</p>
<p>If you've genuinely experienced abuse, don't dismiss it simply because you're male.</p>
<h2>Should a Father Report His Ex to the Police?</h2>
<p>This needs to be very clear.</p>
<p>If you genuinely believe a crime has occurred, you have been threatened, there is potentially criminal coercive or controlling behaviour, or somebody is at genuine risk of harm, contacting the police may be appropriate.</p>
<p>If somebody is in immediate danger, call <strong>999</strong>.</p>
<p>But reporting someone simply to <strong>"get in first"</strong> is different.</p>
<p>There is no sensible basis for treating family separation as a race to see which parent can make the first allegation.</p>
<p>A police report is not automatically proof that an allegation is true. Neither does being accused establish guilt.</p>
<p>Never exaggerate, manufacture or retaliate with an allegation simply because you are frightened your former partner may make allegations against you.</p>
<blockquote>
<p><strong>Don't concentrate on getting in first. Concentrate on acting early, telling the truth and preserving evidence.</strong></p>
</blockquote>
<p>If something genuinely serious happens today, document it today. Don't deliberately wait six months.</p>
<h2>Why Acting Early Can Matter</h2>
<p>Consider a hypothetical example.</p>
<p>A father says he experienced controlling behaviour for a prolonged period but told nobody.</p>
<p>He eventually leaves the relationship.</p>
<p>Contact with his children subsequently becomes difficult.</p>
<p>Several months later allegations are made about him and professionals become involved.</p>
<p>Only then does he disclose the behaviour he says he previously experienced.</p>
<p>That doesn't mean he shouldn't be believed.</p>
<p>There are many reasons someone may delay disclosing abuse.</p>
<p>Male victims may experience embarrassment, fear, confusion or worry that they won't be taken seriously. Others may be reluctant to involve police because the person concerned remains the mother of their children.</p>
<p>Nevertheless, contemporary evidence can make subsequent events easier to understand.</p>
<p>Where something genuinely significant occurs, consider preserving it properly.</p>
<p>That could include:</p>
<ul>
<li>Relevant messages or emails.</li>
<li>Voicemails.</li>
<li>Photographs.</li>
<li>Police correspondence.</li>
<li>Medical records.</li>
<li>School correspondence.</li>
<li>Records of previous parenting arrangements.</li>
<li>Dates of significant incidents.</li>
<li>Relevant professional correspondence.</li>
<li>Evidence of attempts to resolve matters reasonably.</li>
</ul>
<p>You're documenting what happened.</p>
<p>You're not manufacturing a case against your former partner.</p>
<h2>What to Do When Contact Is Suddenly Stopped</h2>
<p>Imagine receiving a message saying:</p>
<blockquote>
<p>"You're not seeing the children again."</p>
</blockquote>
<p>Fear and anger would be understandable.</p>
<p>But this is exactly when emotional regulation becomes important.</p>
<p>Don't respond with twenty angry messages. Don't make threats. Don't threaten a new partner. Don't immediately publish accusations on social media. Don't have friends contact your ex. Don't repeatedly appear at the family home. Don't involve the children in the dispute.</p>
<p>Instead, where it is safe and lawful to communicate, send a calm, child-focused response.</p>
<p>For example:</p>
<blockquote>
<p>"I understand things are difficult between us at the moment. I don't want the children caught in the disagreement between us. I would like to continue my relationship with them and remain involved in their lives. Please let me know when I can next see or speak to them. I'm willing to discuss reasonable arrangements that keep the children's wellbeing at the centre."</p>
</blockquote>
<p>Then preserve the response.</p>
<p>If there is no response, record that too.</p>
<h2>Start a Chronology</h2>
<p>Create a factual timeline.</p>
<p>Include relevant information such as:</p>
<ul>
<li>When you separated.</li>
<li>Previous childcare arrangements.</li>
<li>Overnight stays.</li>
<li>School runs.</li>
<li>Medical appointments.</li>
<li>Activities you attended.</li>
<li>Holidays and important events.</li>
<li>Dates contact was cancelled.</li>
<li>Dates contact was refused.</li>
<li>Requests to speak to the children.</li>
<li>Responses to those requests.</li>
<li>Significant incidents.</li>
<li>Relevant police involvement.</li>
<li>Safeguarding concerns.</li>
<li>Attempts to reach reasonable arrangements.</li>
</ul>
<p>Avoid turning your chronology into a psychological analysis of your former partner.</p>
<p>For example, avoid:</p>
<blockquote>
<p>"She is a narcissist who is brainwashing the children."</p>
</blockquote>
<p>Record the observable event instead:</p>
<blockquote>
<p>"12 July, 6:13pm: I asked whether I could collect Child A at the previously agreed time of 10am Saturday. At 6:42pm I received the response, 'You're not seeing them again.' Original conversation retained."</p>
</blockquote>
<p>The second provides evidence somebody can actually assess.</p>
<h2>Preserve Evidence &mdash; Don't Create It</h2>
<p>There is an enormous difference between collecting evidence and creating conflict to obtain evidence.</p>
<p>Don't provoke your former partner hoping for an angry response.</p>
<p>Don't edit screenshots so they give a misleading impression.</p>
<p>Don't encourage somebody else to provoke them.</p>
<p>Don't impersonate someone online.</p>
<p>Don't ask your children to spy on their other parent.</p>
<p>Keep original, complete records wherever reasonably possible.</p>
<p><strong>Context matters.</strong></p>
<h2>Never Make the Children Your Investigators</h2>
<p>Children should never become evidence-gatherers for either parent.</p>
<p>Don't ask your child, "What has Mum been saying about me?"</p>
<p>Don't repeatedly question them after they have spoken with social workers or other professionals.</p>
<p>Don't ask them to record conversations.</p>
<p>Don't tell them what to say.</p>
<p>Don't show young children court documents.</p>
<p>And don't make a child responsible for proving that you are a good father.</p>
<p>Your child is already dealing with the loss of their previous family structure. They don't need to become a witness in the adult conflict.</p>
<h2>What If My Child Suddenly Says They Don't Want to See Me?</h2>
<p>Few things could hurt a loving parent more.</p>
<p>But proceed carefully.</p>
<p>A child refusing contact does not automatically establish why the child feels that way.</p>
<p>There can be many possible explanations.</p>
<p>A child might be:</p>
<ul>
<li>Genuinely frightened.</li>
<li>Angry with a parent.</li>
<li>Confused by the separation.</li>
<li>Experiencing loyalty conflict.</li>
<li>Trying to protect one parent.</li>
<li>Responding to something they personally experienced.</li>
<li>Exposed to repeated negative information.</li>
<li>Influenced by adult conflict.</li>
<li>Attempting to stop their parents arguing.</li>
<li>Expressing a genuinely independent opinion.</li>
</ul>
<p>That is why proper assessment is important.</p>
<p>Cafcass currently recognises the concept of <strong>alienating behaviours</strong>, but also recognises that claims of alienation can be raised in response to allegations of domestic abuse. These situations therefore require careful assessment rather than simply accepting either parent's label.</p>
<p><a href="https://www.cafcass.gov.uk/parent-carer-or-family-member/applications-child-arrangements-order/how-your-family-court-adviser-makes-their-assessment-your-childs-welfare-and-best-interests/alienating-behaviours" target="_blank" rel="noopener noreferrer">Read Cafcass guidance on alienating behaviours</a>.</p>
<p>Cafcass separately recognises <strong>harmful conflict</strong> between parents and its potential effect upon children.</p>
<p><a href="https://www.cafcass.gov.uk/parent-carer-or-family-member/applications-child-arrangements-order/how-your-family-court-adviser-makes-their-assessment-your-childs-welfare-and-best-interests/harmful-conflict" target="_blank" rel="noopener noreferrer">Read Cafcass guidance on harmful conflict</a>.</p>
<p>So avoid jumping immediately to:</p>
<blockquote>
<p>"My child has been alienated."</p>
</blockquote>
<p>Instead ask:</p>
<blockquote>
<p><strong>"Why has my child's relationship with me changed so dramatically, and can the circumstances surrounding that change be properly assessed?"</strong></p>
</blockquote>
<h2>Don't Diagnose Your Former Partner</h2>
<p>This is particularly important when discussing narcissism, personality disorders or DARVO.</p>
<p>You may recognise behaviours that concern you.</p>
<p>Describe those behaviours.</p>
<p>Don't diagnose someone yourself.</p>
<p>Rather than saying:</p>
<blockquote>
<p>"My ex has narcissistic personality disorder."</p>
</blockquote>
<p>say:</p>
<blockquote>
<p>"When I raised this particular concern, I received the following response..."</p>
</blockquote>
<p>Instead of:</p>
<blockquote>
<p>"She's using DARVO."</p>
</blockquote>
<p>a more responsible formulation is:</p>
<blockquote>
<p>"The sequence of events appears to contain features that may resemble the DARVO framework, but the underlying allegations remain disputed."</p>
</blockquote>
<p>The purpose is to understand behaviour, not to turn psychological terminology into another weapon.</p>
<h2>What If Allegations Are Made Against You?</h2>
<p>Don't panic.</p>
<p>And don't immediately counterattack.</p>
<p>Take every serious allegation seriously.</p>
<p>Work out exactly what is being alleged. Separate factual allegations from interpretation and opinion.</p>
<p>Then identify any relevant evidence.</p>
<p><strong>Allegation:</strong> Dad repeatedly failed to collect the children.</p>
<p><strong>Possible evidence:</strong> Parenting calendars, contemporaneous messages and other records concerning the arrangements.</p>
<p><strong>Allegation:</strong> Dad was threatening.</p>
<p><strong>Possible evidence:</strong> Complete communications rather than selectively chosen messages.</p>
<p><strong>Allegation:</strong> The child is frightened of Dad.</p>
<p><strong>Approach:</strong> Don't attack the child or immediately claim they are lying. Seek appropriate consideration of what the child is saying, what has happened and how their current views developed.</p>
<p>Your position should be straightforward:</p>
<blockquote>
<p><strong>Investigate properly. Consider all relevant evidence. Protect my children. Then allow conclusions to follow the facts.</strong></p>
</blockquote>
<h2>What About Bias Against Fathers?</h2>
<p>Some fathers genuinely feel unheard by professionals or support services.</p>
<p>Those concerns should be capable of being raised.</p>
<p>But avoid sweeping statements such as "Women's Aid is against fathers" or "social services always believe women".</p>
<p>Those claims are too broad and aren't necessary to make your point.</p>
<p>Challenge identifiable problems with evidence.</p>
<p>For example:</p>
<blockquote>
<p>"The assessment states that I had no involvement with the children's school. However, the attached correspondence records my attendance on 4 February, 19 March and 7 May."</p>
</blockquote>
<p>If you believe somebody has made a factual mistake, identify:</p>
<ul>
<li>What was said.</li>
<li>Why you believe it is inaccurate.</li>
<li>What evidence contradicts it.</li>
<li>What correction you are requesting.</li>
</ul>
<p>That is far stronger than attacking an organisation.</p>
<h2>Male Victims of Domestic Abuse Matter</h2>
<p>Domestic abuse is serious regardless of the sex of the victim.</p>
<p>A man should not feel embarrassed about seeking help because the alleged perpetrator is a woman.</p>
<p>In England and Wales, the domestic abuse framework is not restricted to female victims. Children can also be recognised as victims where they see, hear or experience the effects of domestic abuse.</p>
<p>Cafcass's domestic abuse policy requires practitioners to consider domestic abuse, harm and future risk in relevant family proceedings.</p>
<p><a href="https://www.cafcass.gov.uk/domestic-abuse-practice-policy" target="_blank" rel="noopener noreferrer">Read the Cafcass Domestic Abuse Practice Policy</a>.</p>
<p>The <strong>Men's Advice Line</strong> provides specialist support for male victims of domestic abuse on <strong>0808 801 0327</strong>.</p>
<h2>England and Wales: If You Cannot Agree About the Children</h2>
<p>Where it is safe and appropriate, separated parents may be able to reach arrangements themselves or use mediation.</p>
<p>If agreement cannot be reached, an application may be made to the Family Court for a <strong>Child Arrangements Order</strong>.</p>
<p>There is ordinarily a mediation-related requirement before an application, although exemptions may apply, including in certain circumstances involving domestic abuse or urgency.</p>
<p><a href="https://www.gov.uk/looking-after-children-divorce" target="_blank" rel="noopener noreferrer">Read the GOV.UK guidance on making child arrangements after separation</a>.</p>
<p>Where domestic abuse is alleged or there is reason to believe it may have occurred, <strong>Practice Direction 12J</strong> provides important requirements for relevant child-arrangements proceedings.</p>
<p><a href="https://www.justice.gov.uk/courts/procedure-rules/family/practice_directions/pd_part_12j" target="_blank" rel="noopener noreferrer">Read Practice Direction 12J</a>.</p>
<h2>Scotland: The Law and Procedure Are Different</h2>
<p>This distinction is important.</p>
<p>An online article discussing England and Wales should not be treated as a guide to Scottish court procedure.</p>
<p>In Scotland, orders relating to matters including residence and contact are dealt with under <strong>section 11 of the Children (Scotland) Act 1995</strong>.</p>
<p>Child Welfare Hearings can form part of Scottish private family proceedings.</p>
<p>The Scottish Courts and Tribunals Service describes family actions, including applications involving residence and contact, within the Ordinary Cause procedure and advises obtaining legal advice because the procedure can be complex.</p>
<p><a href="https://www.scotcourts.gov.uk/taking-action/ordinary-cause/" target="_blank" rel="noopener noreferrer">Read guidance from the Scottish Courts and Tribunals Service</a>.</p>
<p>If proceedings concern Scotland, obtain advice from a solicitor practising Scottish family law.</p>
<h2>What If There Is Already a Court Order?</h2>
<p>Don't take matters into your own hands.</p>
<p>If an existing order concerning the children isn't being followed, document what happened and obtain appropriate legal advice.</p>
<p>Don't assume an existing order gives you permission to force contact yourself.</p>
<p>Don't create a confrontation at the other parent's home.</p>
<p>Don't encourage children to disobey a parent because "the judge said so".</p>
<p>And never breach another order or restriction yourself in an attempt to enforce contact.</p>
<h2>The First Seven Days: A Practical Checklist for Dads</h2>
<h3>1. Get Yourself Regulated</h3>
<p>You can be angry, frightened and devastated without allowing those feelings to control your behaviour.</p>
<h3>2. Protect the Children</h3>
<p>If anyone faces immediate danger, contact the emergency services.</p>
<h3>3. Report Genuine Abuse Promptly</h3>
<p>If you genuinely believe a crime has occurred, consider reporting it. Be accurate. Don't exaggerate.</p>
<h3>4. Save Relevant Evidence</h3>
<p>Preserve original communications and documents.</p>
<h3>5. Start a Chronology</h3>
<p>Record dates, events and evidence rather than psychological labels.</p>
<h3>6. Request Contact Calmly</h3>
<p>Where communication is safe and lawful, demonstrate that your focus remains on the children.</p>
<h3>7. Get Advice Early</h3>
<p>Don't simply let weeks turn into months because you're frightened of making the situation worse.</p>
<h2>What Fathers Should Not Do</h2>
<p>However unfair the situation feels, don't:</p>
<ul>
<li>Bombard your former partner with messages.</li>
<li>Make threats.</li>
<li>Threaten a new partner.</li>
<li>Repeatedly appear at the family home.</li>
<li>Start a social-media campaign.</li>
<li>Publish private allegations about identifiable people.</li>
<li>Encourage friends to confront your ex.</li>
<li>Use fake accounts to monitor someone.</li>
<li>Coach your children.</li>
<li>Ask children to gather evidence.</li>
<li>Threaten to stop child maintenance in exchange for contact.</li>
<li>Manufacture allegations.</li>
<li>Exaggerate genuine incidents.</li>
<li>Make retaliatory police reports.</li>
<li>Breach court orders.</li>
<li>Breach bail conditions.</li>
<li>Breach protective or non-harassment orders.</li>
</ul>
<p>If somebody else's behaviour is chaotic, don't allow it to make your behaviour chaotic too.</p>
<h2>But What If She Gets Her Story in First?</h2>
<p>This fear is important to address.</p>
<p>Yes, genuine abuse and safeguarding concerns should be raised promptly.</p>
<p>No, that doesn't mean separation should become a race to accuse the other parent.</p>
<p>There is no legitimate <strong>"first allegation wins"</strong> principle.</p>
<p>Making a report does not automatically prove an allegation. Being accused doesn't automatically establish guilt either.</p>
<p>So replace the idea of <strong>"getting there first"</strong> with something much stronger:</p>
<blockquote>
<p><strong>Act early. Tell the truth. Preserve the evidence. Stay consistent.</strong></p>
</blockquote>
<p>If something serious happens on Monday, document it on Monday.</p>
<p>If you receive a genuine threat, preserve it.</p>
<p>If you believe a crime occurred, seek appropriate advice or report it.</p>
<p>If you're experiencing domestic abuse, seek help.</p>
<p>If contact with your children suddenly ends, don't automatically wait months before obtaining family-law advice.</p>
<p><strong>Early action and retaliatory action are two entirely different things.</strong></p>
<h2>Your Child Is Not a Weapon</h2>
<p>This may be the most important point in this article.</p>
<p>A child isn't a possession.</p>
<p>A child isn't evidence.</p>
<p>A child isn't a messenger.</p>
<p>A child isn't a therapist.</p>
<p>And a child should never become revenge for a failed adult relationship.</p>
<p>If domestic abuse occurred, it needs to be taken seriously.</p>
<p>If allegations are disputed, they need to be examined fairly.</p>
<p>If behaviour is unnecessarily damaging a child's relationship with a safe parent, it deserves proper consideration.</p>
<p>And if a child has a genuine reason to fear a parent, that concern needs to be heard too.</p>
<p>Those positions aren't contradictory.</p>
<p><strong>They represent a child-centred approach.</strong></p>
<h2>Fathers Need Support Too</h2>
<p>Losing everyday contact with your children can be psychologically devastating.</p>
<p>A father may simultaneously lose his relationship, home, financial security and normal parenting role.</p>
<p>He may then face police enquiries, solicitors, assessments and court proceedings while being expected to remain completely composed.</p>
<p>Don't be ashamed to ask for help.</p>
<p>Speak to your GP if your mental health is deteriorating.</p>
<p>Speak to a specialist domestic abuse service if appropriate.</p>
<p>Talk to trusted people.</p>
<p>Seek professional psychological support when needed.</p>
<p>Taking care of your mental health isn't weakness. It's part of remaining a functioning parent.</p>
<h2>Final Thoughts: Act Early, But Act With Integrity</h2>
<p>If I could give a newly separated father ten rules, they would be these:</p>
<ol>
<li><strong>Protect your children.</strong></li>
<li><strong>Report genuine abuse, threats or danger promptly.</strong></li>
<li><strong>Never invent or exaggerate an allegation.</strong></li>
<li><strong>Preserve relevant evidence.</strong></li>
<li><strong>Keep an accurate chronology.</strong></li>
<li><strong>Communicate calmly.</strong></li>
<li><strong>Never recruit children into adult conflict.</strong></li>
<li><strong>Seek appropriate legal advice early.</strong></li>
<li><strong>Challenge inaccurate information with evidence, not aggression.</strong></li>
<li><strong>Don't simply disappear because the process frightens you.</strong></li>
</ol>
<p>There is an enormous difference between <strong>getting in first</strong> and <strong>acting early</strong>.</p>
<p>If you've genuinely experienced abuse, don't wait months to acknowledge it merely because you're embarrassed about being a male victim.</p>
<p>If your relationship with your children suddenly disappears, don't assume doing nothing indefinitely is your only option.</p>
<p>If a professional records something you believe is inaccurate, challenge the specific information with evidence.</p>
<p>If serious allegations are made about you, don't automatically retaliate with allegations of your own.</p>
<p>And don't turn terms such as <em>narcissism</em>, <em>alienation</em> or <em>DARVO</em> into weapons.</p>
<p><strong>Look at the behaviour.</strong></p>
<p><strong>Look at the evidence.</strong></p>
<p><strong>Look at what is happening to the child.</strong></p>
<p>Because ultimately the strongest record a separated father can create isn't:</p>
<blockquote>
<p><strong>"I attacked her story before she attacked mine."</strong></p>
</blockquote>
<p>It is:</p>
<blockquote>
<p><strong>"From the moment our relationship ended, I acted honestly, consistently and proportionately. I documented genuine concerns. I asked for appropriate help. I didn't retaliate. I didn't use my children against their mother. And throughout everything that happened, I kept my children's safety, wellbeing and relationships at the centre."</strong></p>
</blockquote>
<p>That is a much stronger place from which to move forward.</p>
<p><strong>Andy Fish</strong></p>
<hr>
<p><small><strong>Important information:</strong> This article provides general educational and informational content only. It does not constitute legal, psychological or medical advice and does not determine whether abuse, DARVO, alienating behaviour or any criminal offence has occurred in an individual case. Allegations and counter-allegations require proper assessment based upon the available evidence. Family law and court procedure differ between England and Wales, Scotland and Northern Ireland. Anyone experiencing domestic abuse, safeguarding concerns, restrictions on contact or existing court proceedings should obtain advice appropriate to their individual circumstances and jurisdiction.</small></p>

---
title: "Is It Really Narcissism? The Traits, Warning Signs and Red Flags People Get Wrong"
seoTitle: "Narcissistic Traits & Warning Signs: What to Look For"
metaDescription: "Learn the genuine traits and warning signs of narcissism, what NPD actually means and which behaviours are commonly mistaken for narcissistic personality disord"
slug: "narcissistic-traits-warning-signs"
categories: "Psychology"
tags: "['Narcissism', 'NPD', 'Narcissistic Personality Disorder', 'Narcissistic Traits', 'Personality Disorders', 'Grandiose Narcissism', 'Vulnerable Narcissism', 'Relationship Red Flags', 'Gaslighting', 'DARVO', 'Psychology']"
author: "Reiki Fish"
featured: false
draft: false
date: "2026-08-06"
excerpt: "What are the real signs of narcissism? This evidence-led guide explores grandiosity, entitlement, empathy, vulnerability and relationship warning signs while separating genuine narcissistic traits from internet myths."
featuredImage: "assets/images/blog/narcissist.png"
featuredImageAlt: "Woman facing an idealised mirror reflection, representing narcissistic grandiosity, vulnerability, self-image and personality traits."
---

<p>The word&nbsp;<strong>narcissist</strong> has become one of the most overused psychological labels on the internet.</p>
<p>A selfish partner becomes a narcissist. A cheating ex becomes a narcissist. Somebody who refuses to apologise becomes a narcissist. A manipulative colleague, an attention-seeking friend or a controlling parent can all find themselves given the same label.</p>
<p>Sometimes narcissistic traits genuinely may be present.</p>
<p>Sometimes Narcissistic Personality Disorder, or NPD, may eventually be diagnosed by a qualified professional.</p>
<p>But sometimes a person is simply selfish, emotionally immature, defensive, controlling, dishonest or abusive.</p>
<p><strong>Those things matter, but they are not diagnoses.</strong></p>
<p>This distinction is essential because Narcissistic Personality Disorder is considerably more complex than simply being unpleasant or obsessed with yourself.</p>
<p>So what are the genuine traits of narcissism? What warning signs should you pay attention to? What does the research actually tell us? And, perhaps most importantly, what does <strong>not</strong> prove somebody is a narcissist?</p>
<h2>First: Narcissistic Traits and NPD Are Not the Same Thing</h2>
<p>Nearly everybody can display narcissistic characteristics occasionally.</p>
<p>Human beings naturally care about status, reputation, achievement and how other people perceive them.</p>
<ul style="list-style-type: disc;">
<li>You might enjoy praise.</li>
<li>You might become defensive after criticism.</li>
<li>You might occasionally dominate a conversation.</li>
<li>You may feel jealous of somebody more successful than you.</li>
<li>You may even behave selfishly during an argument.</li>
<li>None of that automatically means you have Narcissistic Personality Disorder.</li>
</ul>
<p>The American Psychiatric Association describes NPD as a <strong>pervasive</strong> pattern involving grandiosity, need for admiration and impaired empathy. The pattern is persistent, problematic and present across contexts rather than appearing during one isolated relationship or stressful period.</p>
<p>This gives us our first rule:</p>
<p><strong>Look for enduring patterns, not isolated incidents.</strong></p>
<h2>The Nine Traditional Clinical Features of NPD</h2>
<p>The DSM-5-TR diagnostic framework describes a number of features associated with Narcissistic Personality Disorder.</p>
<p>In plain English, these concern the following areas.</p>
<h3>1. An Inflated Sense of Self-Importance</h3>
<p>The person may exaggerate achievements, abilities or importance.</p>
<p>This goes beyond healthy confidence.</p>
<p>They may expect recognition as exceptional even when their actual accomplishments do not justify that recognition.</p>
<p>Examples might include:</p>
<ul>
<li>Consistently exaggerating professional achievements.</li>
<li>Presenting ordinary accomplishments as extraordinary.</li>
<li>Expecting other people to acknowledge their superiority.</li>
<li>Becoming preoccupied with maintaining an image of exceptional competence.</li>
</ul>
<p>However, boasting occasionally does not establish NPD.</p>
<h3>2. Fantasies of Exceptional Success, Power or Ideal Love</h3>
<p>Someone with pronounced narcissistic pathology may become heavily preoccupied with fantasies of:</p>
<ul>
<li>Unlimited success.</li>
<li>Power.</li>
<li>Exceptional intelligence.</li>
<li>Beauty.</li>
<li>Status.</li>
<li>Idealised relationships.</li>
</ul>
<p>A dream or ambition is not pathological simply because it is big.</p>
<p>The concern is the wider pattern and the role these fantasies play in self-esteem and functioning.</p>
<h3>3. Believing They Are Uniquely Special</h3>
<p>The person may believe that only particularly important, intelligent, wealthy, attractive or high-status people can truly understand them.</p>
<p>There may be a strong psychological distinction between:</p>
<p><strong>&ldquo;ordinary people&rdquo;</strong></p>
<p>and:</p>
<p><strong>&ldquo;people like me&rdquo;.</strong></p>
<p>This can create elitism and condescension.</p>
<h3>4. An Excessive Need for Admiration</h3>
<p>Admiration can become an important means of regulating self-esteem.</p>
<p>Signs might include:</p>
<ul>
<li>Repeatedly fishing for compliments.</li>
<li>Needing recognition for achievements.</li>
<li>Becoming uncomfortable when somebody else receives attention.</li>
<li>Constantly returning conversations to personal accomplishments.</li>
<li>Seeking environments in which status can be displayed.</li>
</ul>
<p>But attention seeking alone is not specific to narcissism.</p>
<h3>5. Entitlement</h3>
<p>Entitlement is one of the more important characteristics.</p>
<p>It involves unreasonable expectations of special treatment or automatic compliance from other people.</p>
<p>It may sound like:</p>
<p><strong>&ldquo;Rules shouldn't apply to me.&rdquo;</strong></p>
<p><strong>&ldquo;I shouldn't have to wait.&rdquo;</strong></p>
<p><strong>&ldquo;After everything I've done, you owe me.&rdquo;</strong></p>
<p><strong>&ldquo;My needs should come first.&rdquo;</strong></p>
<p>Entitlement becomes particularly problematic when other people's boundaries are treated as obstacles rather than legitimate limits.</p>
<h3>6. Interpersonal Exploitation</h3>
<p>A person may use relationships primarily to achieve personal goals.</p>
<p>Examples could include:</p>
<ul>
<li>Maintaining relationships principally for status or access.</li>
<li>Using another person's generosity without meaningful reciprocity.</li>
<li>Manipulating somebody into providing resources.</li>
<li>Discarding relationships once they cease providing a desired benefit.</li>
</ul>
<p>Again, exploitation is not uniquely narcissistic. It can occur in other personality pathology and in people without a diagnosable personality disorder.</p>
<h3>7. Impairment in Empathy</h3>
<p>Empathy is one of the most misunderstood parts of narcissism.</p>
<p>People often say:</p>
<p><strong>&ldquo;Narcissists have no empathy.&rdquo;</strong></p>
<p>That is too simplistic.</p>
<p>Research suggests that empathic functioning in narcissistic pathology can be <strong>compromised and variable</strong> rather than representing a universal inability to understand another person's emotions.</p>
<p>Someone may recognise that another person is upset while remaining unwilling or insufficiently motivated to respond to those feelings.</p>
<p>Empathy can also fluctuate according to self-esteem threat, emotional regulation and whether another person's experience is perceived as relevant to the self.</p>
<p>This is important because someone understanding your emotions does not necessarily mean that they will prioritise them.</p>
<h3>8. Envy</h3>
<p>Envy may involve:</p>
<ul>
<li>Resentment towards somebody else's success.</li>
<li>Difficulty celebrating another person's achievement.</li>
<li>Devaluing somebody who receives recognition.</li>
<li>Believing that others are jealous of them.</li>
</ul>
<p>Ordinary envy remains part of normal human psychology. As always, the clinical significance comes from the wider pattern.</p>
<h3>9. Arrogant or Haughty Behaviour</h3>
<p>The individual may routinely appear:</p>
<ul>
<li>Condescending.</li>
<li>Dismissive.</li>
<li>Patronising.</li>
<li>Superior.</li>
<li>Contemptuous.</li>
</ul>
<p>They may treat people perceived as lower-status very differently from people whose approval or influence they value.</p>
<h2>The Pattern Matters More Than the Checklist</h2>
<p>This is where most internet tests fail.</p>
<p>People read nine characteristics and start counting.</p>
<p>But clinical assessment is not simply:</p>
<p><strong>&ldquo;My ex does five of these, therefore NPD.&rdquo;</strong></p>
<p>A professional assessment considers:</p>
<ul>
<li>How long the pattern has existed.</li>
<li>Whether it occurs across different relationships and settings.</li>
<li>How inflexible it is.</li>
<li>The effect upon the person's functioning.</li>
<li>The person's developmental and psychiatric history.</li>
<li>Whether another condition better explains the presentation.</li>
<li>Whether substance use or another acute state is influencing behaviour.</li>
<li>The difference between personality traits and personality disorder.</li>
</ul>
<p>You cannot reproduce that assessment using a social-media checklist.</p>
<h2>Grandiose Narcissism: The Version Most People Recognise</h2>
<p>The stereotypical narcissist resembles the grandiose presentation.</p>
<p>Possible characteristics can include:</p>
<ul>
<li>Overt superiority.</li>
<li>Dominance.</li>
<li>Entitlement.</li>
<li>Admiration seeking.</li>
<li>High self-presentation.</li>
<li>Arrogance.</li>
<li>Interpersonal exploitation.</li>
<li>Devaluation of people perceived as inferior.</li>
</ul>
<p>This person may appear extremely confident.</p>
<p>But outward confidence does not tell us everything about underlying personality functioning.</p>
<h2>Vulnerable Narcissistic Features: The Less Obvious Side</h2>
<p>Research into pathological narcissism has increasingly examined both <strong>grandiosity and vulnerability</strong>.</p>
<p>Vulnerable narcissistic features may include:</p>
<ul>
<li>Hypersensitivity to criticism.</li>
<li>Shame.</li>
<li>Unstable self-esteem.</li>
<li>Withdrawal following perceived failure.</li>
<li>Strong sensitivity to rejection or humiliation.</li>
<li>Defensiveness.</li>
<li>Social comparison.</li>
<li>Preoccupation with how others evaluate them.</li>
</ul>
<p>Someone can fluctuate between grandiose and vulnerable states.</p>
<p>A person who seems supremely confident while everything is going well may become surprisingly fragile when their self-image is threatened.</p>
<p>But an important warning is needed here.</p>
<p><strong>&ldquo;Vulnerable narcissism&rdquo; must not become a way of diagnosing every insecure, shy or sensitive person as a covert narcissist.</strong></p>
<h2>Is &ldquo;Covert Narcissist&rdquo; an Official Diagnosis?</h2>
<p>No.</p>
<p>You will hear the phrase constantly online.</p>
<p>It is often used to describe a quieter or more vulnerable presentation of narcissistic characteristics.</p>
<p>However, &ldquo;covert narcissistic personality disorder&rdquo; is not a separate formal DSM diagnosis.</p>
<p>Research into narcissistic vulnerability is legitimate.</p>
<p>The problem comes when almost any combination of:</p>
<ul>
<li>Introversion.</li>
<li>Insecurity.</li>
<li>Passive aggression.</li>
<li>Social withdrawal.</li>
<li>Victimhood.</li>
<li>Low self-esteem.</li>
</ul>
<p>is declared proof of covert narcissism.</p>
<p>Those features have many possible explanations.</p>
<h2>The Warning Sign That Often Matters Most: How They Handle Your Separate Existence</h2>
<p>One useful relationship question is:</p>
<p><strong>Can this person recognise that you are a separate human being with needs, opinions and boundaries of your own?</strong></p>
<p>Problems may become visible when:</p>
<ul>
<li>You disagree.</li>
<li>You receive attention.</li>
<li>You succeed independently.</li>
<li>You set a boundary.</li>
<li>You say no.</li>
<li>You criticise something they have done.</li>
<li>You stop providing admiration.</li>
<li>You prioritise a legitimate need of your own.</li>
</ul>
<p>Healthy relationships require mutuality.</p>
<p>Where narcissistic pathology is pronounced, another person's independence can sometimes clash with the person's need for self-esteem regulation, control, validation or entitlement.</p>
<h2>Warning Sign: Rules for You, Exceptions for Them</h2>
<p>Persistent double standards deserve attention.</p>
<p>Examples include:</p>
<ul>
<li>They demand immediate replies but disappear when convenient.</li>
<li>They expect loyalty but repeatedly violate yours.</li>
<li>They become angry at criticism while freely criticising everyone else.</li>
<li>Your boundaries are called selfish while theirs are treated as unquestionable.</li>
<li>They expect forgiveness but hold grudges over perceived slights.</li>
</ul>
<p>Double standards are not diagnostic of NPD.</p>
<p>They can nevertheless signal entitlement and unhealthy relationship dynamics.</p>
<h2>Warning Sign: Everything Eventually Returns to Them</h2>
<ul>
<li>You explain that you're struggling.</li>
<li>Within five minutes, the conversation is about their struggle.</li>
<li>You achieve something.</li>
<li>They explain why their achievement was greater.</li>
<li>You describe being hurt by something they did.</li>
<li>The discussion becomes about how badly your accusation made <strong>them</strong> feel.</li>
<li>Persistent self-referential communication can be relevant to narcissistic functioning.</li>
<li>But do not diagnose someone from one badly handled conversation.</li>
</ul>
<h2>Warning Sign: Admiration Seems More Important Than Connection</h2>
<p>Healthy intimacy requires more than being admired.</p>
<p>It involves curiosity about another person's internal world.</p>
<p>Ask:</p>
<ul>
<li>Do they know what matters to you?</li>
<li>Can they celebrate your success?</li>
<li>Can they listen without immediately turning the conversation towards themselves?</li>
<li>Are they interested in your feelings when those feelings provide no benefit to them?</li>
<li>Can they tolerate your disagreement?</li>
</ul>
<p>A relationship based primarily around affirmation can feel wonderful while the admiration continues and surprisingly empty once genuine mutuality is required.</p>
<h2>Warning Sign: Extreme Reactions to Criticism</h2>
<p>Everybody dislikes criticism sometimes.</p>
<p>The relevant question is what happens next.</p>
<p>Someone with significant narcissistic vulnerability may experience criticism as a much larger threat to self-esteem than an observer expects.</p>
<p>Responses might include:</p>
<ul>
<li>Anger.</li>
<li>Contempt.</li>
<li>Counterattack.</li>
<li>Blame.</li>
<li>Withdrawal.</li>
<li>Devaluation of the critic.</li>
<li>Shame.</li>
<li>Attempts to restore superiority.</li>
</ul>
<p>The internet often calls any angry response to criticism <strong>&ldquo;narcissistic rage&rdquo;</strong>.</p>
<p>That is too broad.</p>
<p>Anger can have countless psychological causes.</p>
<p>Look for the whole pattern.</p>
<h2>Warning Sign: Repeated Devaluation of Other People</h2>
<p>Listen to how somebody describes people when they are no longer useful or admiring.</p>
<p>Do former friends suddenly become:</p>
<ul>
<li>Stupid?</li>
<li>Jealous?</li>
<li>Crazy?</li>
<li>Pathetic?</li>
<li>Obsessed with them?</li>
</ul>
<p>Does every former partner become the problem?</p>
<p>Does somebody alternate between extraordinary praise and sweeping contempt?</p>
<p>Persistent devaluation can be worth noticing, but once again it is not unique to narcissism.</p>
<h2>Warning Sign: Status Changes Their Behaviour</h2>
<p>Watch how somebody behaves towards people from whom they want nothing.</p>
<p>Not just the boss.</p>
<p>Not just somebody attractive.</p>
<p>Not just somebody influential.</p>
<p>How do they treat:</p>
<ul>
<li>Service staff?</li>
<li>Junior colleagues?</li>
<li>People they disagree with?</li>
<li>People with less money?</li>
<li>People who cannot improve their social position?</li>
</ul>
<p>A sharp difference between charming upward and contemptuous downward behaviour can reveal something important about entitlement and interpersonal values.</p>
<h2>Warning Sign: Accountability Is Consistently Missing</h2>
<p>Healthy people can behave terribly.</p>
<p>One of the things that distinguishes a repairable mistake from a destructive pattern is what happens afterwards.</p>
<p>Can the person say:</p>
<p><strong>&ldquo;I was wrong.&rdquo;</strong></p>
<p><strong>&ldquo;I hurt you.&rdquo;</strong></p>
<p><strong>&ldquo;That wasn't acceptable.&rdquo;</strong></p>
<p><strong>&ldquo;What can I do differently?&rdquo;</strong></p>
<p>Or does every conflict become:</p>
<ul>
<li>Your fault.</li>
<li>Your misunderstanding.</li>
<li>Your sensitivity.</li>
<li>Your provocation.</li>
<li>Your failure to appreciate them.</li>
</ul>
<p>Chronic externalisation of blame is an important relationship warning even when no psychiatric diagnosis is established.</p>
<h2>What About Love Bombing?</h2>
<p>&ldquo;Love bombing&rdquo; is one of the most popular expressions in narcissism content.</p>
<p>It usually describes overwhelming affection, attention, gifts, promises or commitment very early in a relationship, particularly when the intensity is later used to gain influence or control.</p>
<p>That pattern can be concerning.</p>
<p>But intense early affection does not prove narcissism.</p>
<p>Rapid intensity can also result from:</p>
<ul>
<li>Infatuation.</li>
<li>Inexperience.</li>
<li>Anxious attachment.</li>
<li>Impulsivity.</li>
<li>Poor boundaries.</li>
<li>Idealisation.</li>
<li>Deliberate manipulation unrelated to NPD.</li>
</ul>
<p>The warning sign is not simply:</p>
<p><strong>&ldquo;They really liked me at the beginning.&rdquo;</strong></p>
<p>Look instead at whether excessive early intensity is followed by control, exploitation, devaluation or punishment for independence.</p>
<h2>What About Gaslighting?</h2>
<p>Gaslighting can be psychologically harmful.</p>
<p>It generally refers to attempts to destabilise somebody's confidence in their own perception, memory or understanding of events.</p>
<p>Examples can include persistently denying events that occurred, rewriting conversations or portraying reasonable perceptions as evidence that the other person is unstable.</p>
<p>But gaslighting is not a diagnostic criterion that proves NPD.</p>
<p>People without NPD can gaslight.</p>
<p>People can also remember events differently without deliberately gaslighting one another.</p>
<p>Intent, pattern and context matter.</p>
<h2>What About DARVO?</h2>
<p>DARVO stands for <strong>Deny, Attack, and Reverse Victim and Offender</strong>.</p>
<p>It describes a recognised defensive pattern in which someone accused of wrongdoing denies the behaviour, attacks the person raising it and reverses the roles of victim and offender.</p>
<p>DARVO is useful when describing behaviour.</p>
<p>It is not a diagnostic test for NPD.</p>
<p>If somebody uses a DARVO-like response, describe what they actually did rather than concluding:</p>
<p><strong>&ldquo;DARVO proves they're a narcissist.&rdquo;</strong></p>
<h2>What About the &ldquo;Smear Campaign&rdquo;?</h2>
<p>A hostile ex may attempt to damage another person's reputation.</p>
<p>That can be extremely harmful.</p>
<p>But spreading damaging stories about somebody is not exclusive to NPD.</p>
<p>It can occur because of:</p>
<ul>
<li>Revenge.</li>
<li>Anger.</li>
<li>Fear.</li>
<li>Reputation management.</li>
<li>Control.</li>
<li>Genuine belief in a disputed account.</li>
<li>Other personality pathology.</li>
<li>Ordinary destructive behaviour.</li>
</ul>
<p>Evidence matters more than the label.</p>
<h2>What About &ldquo;Hoovering&rdquo;?</h2>
<p>Hoovering is another popular non-clinical term used for attempts to draw a former partner back into contact.</p>
<p>Returning after a separation can involve manipulation.</p>
<p>But people reconnect with former partners for countless reasons.</p>
<p>More established psychological concepts, including reinforcement patterns, attachment dynamics and relationship cycling, may often be more useful than treating &ldquo;hoovering&rdquo; as a symptom of a disorder.</p>
<h2>What About Cheating?</h2>
<p>Cheating is not a diagnostic test for narcissism.</p>
<p>Infidelity may involve:</p>
<ul>
<li>Entitlement.</li>
<li>Impulsivity.</li>
<li>Validation seeking.</li>
<li>Opportunity.</li>
<li>Novelty seeking.</li>
<li>Relationship problems.</li>
<li>Substance use.</li>
<li>Poor boundaries.</li>
<li>Ordinary selfishness.</li>
</ul>
<p>Narcissistic characteristics can be relevant for some people.</p>
<p>They are not required for infidelity to occur.</p>
<h2>The Difference Between a Narcissistic Trait and a Relationship Red Flag</h2>
<p>This distinction will save you enormous confusion.</p>
<p>A <strong>narcissistic trait</strong> tells us something about personality functioning.</p>
<p>A <strong>relationship red flag</strong> tells us something may be unhealthy or unsafe.</p>
<p>They can overlap, but they are not the same.</p>
<p>Examples of serious relationship red flags can include:</p>
<ul>
<li>Coercive control.</li>
<li>Threats.</li>
<li>Physical violence.</li>
<li>Sexual coercion.</li>
<li>Stalking.</li>
<li>Financial control.</li>
<li>Isolation.</li>
<li>Repeated humiliation.</li>
<li>Monitoring.</li>
<li>Intimidation.</li>
<li>Persistent boundary violations.</li>
</ul>
<p>You do not need to diagnose NPD before taking any of those behaviours seriously.</p>
<h2>Warning: Narcissism Does Not Equal Abuse</h2>
<p>This works in both directions.</p>
<p>Not every abusive person has NPD.</p>
<p>And a person having NPD does not automatically prove that they have committed abuse.</p>
<p>Psychiatric diagnosis and abusive behaviour are related questions, not interchangeable ones.</p>
<p>If abuse occurred, identify the behaviour.</p>
<p>If a personality disorder is suspected, leave diagnosis to appropriate assessment.</p>
<h2>Warning: NPD Does Not Mean Psychopath</h2>
<p>Psychopathy, Antisocial Personality Disorder and Narcissistic Personality Disorder overlap in certain characteristics but are not synonyms.</p>
<p>A lack of remorse or exploitative behaviour should not lead to the automatic equation:</p>
<p><strong>Narcissist = sociopath = psychopath.</strong></p>
<p>Psychopathy has its own research and forensic-assessment tradition.</p>
<p>ASPD is a separate formal diagnosis.</p>
<p>NPD is another.</p>
<h2>Warning: Do Not Diagnose Your Ex From TikTok</h2>
<p>Once you adopt the label, confirmation bias can make almost everything appear to confirm it.</p>
<p>Consider:</p>
<ul>
<li>If they contact you, it is called hoovering.</li>
<li>If they don't contact you, it is called narcissistic discard.</li>
<li>If they apologise, it is called manipulation.</li>
<li>If they don't apologise, it proves they lack empathy.</li>
<li>If they are confident, it proves grandiosity.</li>
<li>If they are insecure, it proves covert narcissism.</li>
<li>If they date again, the new partner becomes narcissistic supply.</li>
<li>If they remain single, they are supposedly wounded by losing supply.</li>
</ul>
<p>Notice the problem.</p>
<p>If every possible outcome confirms your theory, your theory can no longer be tested.</p>
<p>That is not good psychological reasoning.</p>
<h2>Why Trauma Does Not Automatically Create Narcissism</h2>
<p>Research has found associations between childhood adversity and later pathological narcissistic traits.</p>
<p>However, these relationships are not deterministic.</p>
<p>A 2024 meta-analysis examining childhood maltreatment and narcissism found associations with both vulnerable and grandiose narcissistic features, with the relationship stronger for vulnerable narcissism. However, the overall associations were relatively modest.</p>
<p>This means trauma can be relevant to developmental pathways without creating a simple formula:</p>
<p><strong>Childhood trauma = narcissist.</strong></p>
<p>Millions of trauma survivors do not develop NPD.</p>
<p>Trauma can explain vulnerability.</p>
<p>It does not excuse abusive behaviour.</p>
<h2>Why Empathy Is More Complicated Than &ldquo;They Have None&rdquo;</h2>
<p>Modern research has challenged the simplistic picture of somebody with pathological narcissism possessing absolutely no empathic ability.</p>
<p>Empathy involves different processes.</p>
<p>A person may intellectually recognise what somebody feels while showing reduced emotional responsiveness.</p>
<p>Empathic engagement can also be influenced by:</p>
<ul>
<li>Motivation.</li>
<li>Self-esteem threat.</li>
<li>Emotional regulation.</li>
<li>Shame.</li>
<li>Attention.</li>
<li>Relationship context.</li>
</ul>
<p>This creates an uncomfortable possibility.</p>
<p>Somebody may understand that you are hurt and still prioritise themselves.</p>
<p>That behaviour matters.</p>
<p>But understanding the mechanism is more accurate than repeating:</p>
<p><strong>&ldquo;Narcissists cannot feel empathy.&rdquo;</strong></p>
<h2>Can Someone With Narcissistic Traits Love?</h2>
<p>This question is usually asked by somebody in pain.</p>
<p>Unfortunately, &ldquo;Can narcissists love?&rdquo; is too simplistic to have a useful yes-or-no answer.</p>
<p>Human attachment, affection, intimacy, sexuality, dependency, empathy and self-interest are not a single psychological switch called love.</p>
<p>People with narcissistic personality pathology can form attachments and relationships.</p>
<p>The more useful question is:</p>
<p><strong>&ldquo;Can this particular person sustain the mutuality, accountability, empathy and respect required for a healthy relationship with me?&rdquo;</strong></p>
<p>That question actually helps you make a decision.</p>
<h2>Can a Narcissistic Person Change?</h2>
<p>Another internet myth is:</p>
<p><strong>&ldquo;A narcissist can never change.&rdquo;</strong></p>
<p>That statement is too absolute.</p>
<p>The American Psychiatric Association notes that people with NPD can improve, although improvement may be gradual.</p>
<p>Personality patterns are deeply established, which can make change difficult.</p>
<p>Factors such as:</p>
<ul>
<li>Insight.</li>
<li>Motivation.</li>
<li>Therapeutic engagement.</li>
<li>Severity.</li>
<li>Comorbid conditions.</li>
<li>Willingness to accept responsibility.</li>
</ul>
<p>can matter.</p>
<p>But there is another important warning.</p>
<p><strong>You are not required to remain in a harmful relationship while waiting for somebody to change.</strong></p>
<h2>What Should You Look for Instead of a Diagnosis?</h2>
<p>If you're trying to decide whether a relationship is healthy, these questions are often more useful than:</p>
<p><strong>&ldquo;Is my partner a narcissist?&rdquo;</strong></p>
<p>Ask:</p>
<ul>
<li>Can I disagree without being punished?</li>
<li>Can I say no?</li>
<li>Are my boundaries respected?</li>
<li>Can they apologise meaningfully?</li>
<li>Does behaviour actually change after an apology?</li>
<li>Is affection conditional upon compliance?</li>
<li>Do I constantly have to protect their ego?</li>
<li>Can they celebrate my success?</li>
<li>Can they listen when the conversation is not about them?</li>
<li>Do they take responsibility?</li>
<li>Do I feel safe?</li>
<li>Am I becoming isolated?</li>
<li>Am I frightened of their reactions?</li>
<li>Do I have to continually question my own judgement?</li>
<li>Does the relationship contain genuine reciprocity?</li>
</ul>
<p>Those answers tell you a great deal even if you never discover whether NPD is present.</p>
<h2>Twenty Things That Do Not Prove Someone Is a Narcissist</h2>
<ul>
<li>They cheated.</li>
<li>They lied.</li>
<li>They blocked you.</li>
<li>They unblocked you.</li>
<li>They returned to an ex.</li>
<li>They post a lot of selfies.</li>
<li>They like attention.</li>
<li>They are attractive and know it.</li>
<li>They are ambitious.</li>
<li>They became angry.</li>
<li>They are insecure.</li>
<li>They had childhood trauma.</li>
<li>They are emotionally avoidant.</li>
<li>They don't like criticism.</li>
<li>They ended your relationship.</li>
<li>They quickly started another relationship.</li>
<li>They behaved selfishly.</li>
<li>They refuse to speak to you.</li>
<li>They manipulate sometimes.</li>
<li>They hurt you.</li>
</ul>
<p>Some of those behaviours may be deeply harmful.</p>
<p>None, alone, is sufficient to diagnose NPD.</p>
<h2>When the Warning Signs Become a Safety Issue</h2>
<p>There is a point at which asking whether somebody is narcissistic becomes much less important than asking whether you are safe.</p>
<p>Take threats, violence, sexual coercion, stalking, controlling behaviour and serious intimidation seriously regardless of the suspected diagnosis.</p>
<p>If you believe you or a child is in immediate danger, contact emergency services or an appropriate safeguarding service.</p>
<p>If leaving a controlling relationship may increase your risk, consider obtaining specialist domestic-abuse support and making a safety plan rather than announcing your plans during confrontation.</p>
<p><strong>Your safety does not depend upon proving that the other person has NPD.</strong></p>
<h2>If You Recognise These Traits in Yourself</h2>
<p>Don't panic.</p>
<p>Recognising narcissistic traits in yourself does not mean you secretly have Narcissistic Personality Disorder.</p>
<p>In fact, self-reflection can be useful.</p>
<p>Ask yourself:</p>
<ul>
<li>How do I respond when criticised?</li>
<li>Can I apologise without immediately defending myself?</li>
<li>Do I genuinely listen to other people's feelings?</li>
<li>Do I need external praise to feel valuable?</li>
<li>Can somebody disagree with me without becoming my enemy?</li>
<li>Do I treat relationships as reciprocal?</li>
<li>Do I exaggerate my achievements?</li>
<li>Do I regularly expect special treatment?</li>
<li>Can I tolerate somebody else receiving attention?</li>
<li>Do I recognise when my behaviour hurts people?</li>
</ul>
<p>You don't need to attach a diagnosis to begin working on a trait.</p>
<h2>The Behaviour-First Rule</h2>
<p>This is perhaps the healthiest way to use psychology in everyday life.</p>
<p>Instead of:</p>
<p><strong>&ldquo;You're a narcissist.&rdquo;</strong></p>
<p>say:</p>
<p><strong>&ldquo;You repeatedly insult me when I disagree with you.&rdquo;</strong></p>
<p>Instead of:</p>
<p><strong>&ldquo;You're gaslighting me because you're an NPD.&rdquo;</strong></p>
<p>say:</p>
<p><strong>&ldquo;You are repeatedly denying conversations that I have documented, and this interaction is no longer productive.&rdquo;</strong></p>
<p>Instead of:</p>
<p><strong>&ldquo;You're giving me narcissistic silent treatment.&rdquo;</strong></p>
<p>say:</p>
<p><strong>&ldquo;Refusing all communication for several days after an argument is not something I am willing to continue in this relationship.&rdquo;</strong></p>
<p>Specific behaviour produces clearer boundaries.</p>
<p>Diagnosis is not required.</p>
<h2>The Grey Method: Step Out of the Label War</h2>
<p>The Grey asks us to resist one of the most seductive forms of black-and-white thinking:</p>
<p><strong>&ldquo;I was hurt, therefore you are disordered.&rdquo;</strong></p>
<p>Sometimes the person who hurt you does have significant personality pathology.</p>
<p>Sometimes they do not.</p>
<p>Sometimes you will never know.</p>
<p>The Grey asks different questions:</p>
<ul>
<li>What actually happened?</li>
<li>What evidence do I have?</li>
<li>What pattern exists?</li>
<li>What am I assuming?</li>
<li>What behaviour is unacceptable?</li>
<li>What is within my control?</li>
<li>What boundary protects my wellbeing?</li>
</ul>
<p>You can remove yourself from abuse without diagnosing the abuser.</p>
<p>You can end an unhealthy friendship without proving a psychiatric condition.</p>
<p>You can protect your child without turning psychology into a weapon.</p>
<h2>A Final Warning About Online Narcissism Content</h2>
<p>Narcissism content can be incredibly validating when somebody has spent years confused by a destructive relationship.</p>
<p>But validation can become misinformation when every behaviour is forced into the same theory.</p>
<p>Be cautious of anybody claiming:</p>
<ul>
<li>All narcissists behave exactly the same way.</li>
<li>A single behaviour proves NPD.</li>
<li>You can diagnose NPD from someone's eyes or facial expression.</li>
<li>Every narcissistic person is a psychopath.</li>
<li>All people with NPD abuse their partners.</li>
<li>Anybody returning after a break-up is &ldquo;hoovering&rdquo;.</li>
<li>All intense early affection is narcissistic love bombing.</li>
<li>A narcissist is completely incapable of empathy.</li>
<li>People with NPD can never improve.</li>
<li>A simple online test can diagnose your partner.</li>
</ul>
<p>Psychology should help us tolerate complexity rather than eliminate it.</p>
<h2>The Bottom Line</h2>
<p>Narcissistic personality traits are real.</p>
<p>Pathological narcissism is real.</p>
<p>Narcissistic Personality Disorder is real.</p>
<p>And people affected by destructive relationships deserve to have their experiences taken seriously.</p>
<p>But if we call every liar, cheat, selfish partner, difficult parent or abusive ex a narcissist, the word eventually stops explaining anything.</p>
<p>The signs that genuinely matter form a larger and more persistent pattern involving grandiosity, entitlement, admiration, self-esteem regulation, empathy, exploitation and interpersonal functioning.</p>
<p>Even then, diagnosis requires considerably more than recognising similarities from an article.</p>
<p>So if you are worried about someone in your life, pay attention to the behaviour.</p>
<p>Notice the pattern.</p>
<p>Protect your boundaries.</p>
<p>Take abuse seriously.</p>
<p>Get professional support when you need it.</p>
<p>But resist turning psychological terminology into a weapon.</p>
<p><strong>You do not need to prove that somebody is a narcissist before deciding that the way they treat you is unacceptable.</strong></p>
<p>Sometimes that is the most important warning sign of all.</p>
<h2>Research and Clinical Sources</h2>
<ul>
<li><a href="https://www.psychiatry.org/news-room/apa-blogs/what-is-narcissistic-personality-disorder" target="_blank" rel="noopener">American Psychiatric Association &ndash; What Is Narcissistic Personality Disorder?</a></li>
<li><a href="https://www.psychiatry.org/patients-families/personality-disorders/what-are-personality-disorders" target="_blank" rel="noopener">American Psychiatric Association &ndash; What Are Personality Disorders?</a></li>
<li><a href="https://www.psychiatry.org/File%20Library/Psychiatrists/Meetings/Annual-Meeting/presenter-slides/Dimensional-Conceptualization-and-Diagnosis-of-Narcissistic-Personality-Disorder-Ronningstam.pdf" target="_blank" rel="noopener">Ronningstam &ndash; Dimensional Conceptualisation and Diagnosis of Narcissistic Personality Disorder</a></li>
<li><a href="https://pubmed.ncbi.nlm.nih.gov/36651026/" target="_blank" rel="noopener">Gao et al. &ndash; Child Maltreatment and Vulnerable and Grandiose Narcissism: Meta-analysis</a></li>
<li><a href="https://pubmed.ncbi.nlm.nih.gov/37702183/" target="_blank" rel="noopener">Oliver et al. &ndash; Narcissism and Intimate Partner Violence: Systematic Review</a></li>
<li><a href="https://pubmed.ncbi.nlm.nih.gov/38710596/" target="_blank" rel="noopener">Blay et al. &ndash; Pathological Narcissism and Emotion Dysregulation</a></li>
</ul>
<p><em>This article provides general psychological education and should not be used to diagnose an individual. Narcissistic Personality Disorder requires appropriate professional assessment. If you are experiencing abuse, coercion or immediate danger, seek appropriate professional, safeguarding or emergency support.</em></p>

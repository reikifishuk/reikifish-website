---
title: "The Grey Method: Staying Regulated When Someone Wants a Reaction"
seoTitle: "The Grey Method: Staying Regulated Under Provocation"
metaDescription: "Learn how the Grey Method helps you regulate emotions, resist provocation, set firm boundaries and respond with truth, calm and self control."
slug: "the-grey-method-staying-regulated-under-provocation"
categories: "Psychology"
tags: "['The Grey Method', 'Walking the Grey', 'Emotional Regulation', 'Emotional Triggers', 'Conflict', 'Boundaries', 'Trauma Recovery', 'Self Control', 'Reiki', 'Mindfulness', 'Personal Development', 'Andy Fish']"
author: "Reiki Fish"
featured: true
draft: false
date: "2026-08-12"
excerpt: "When someone wants an emotional reaction, remaining calm can feel almost impossible. The Grey Method, guided by Andy Fish’s Walking the Grey, offers a structured way to pause, regulate fear, protect your boundaries and respond without surrendering truth or identity."
featuredImage: "assets/images/blog/the-grey-method-staying-regulated-under-provocation.png"
featuredImageAlt: "The Grey Method showing a calm person remaining emotionally regulated while surrounded by conflict and provocation"
---

<article class="rf-article grey-method-article"><header class="article-header">
<p class="article-kicker">When someone provokes, misrepresents or repeatedly pushes at your emotional limits, the greatest struggle is not always proving what happened. It is remaining connected to yourself while pressure is being applied. The Grey Method is a disciplined return to that inner centre: the place where reaction becomes reflection, fear becomes understanding and strength no longer needs to announce itself.</p>
</header>
<aside class="article-note" aria-label="Important information">
<p><strong>Important:</strong> The Grey Method is a reflective coaching and emotional regulation framework developed from the philosophy of <em>Walking the Grey</em>. It is not a clinical treatment, diagnosis or substitute for medical, psychological, safeguarding or legal support. If an interaction involves violence, threats, stalking, coercive control or immediate danger, prioritise safety and obtain appropriate professional help.</p>
</aside>
<section>
<h2>When the reaction becomes the story</h2>
<p>Some interactions are not genuine attempts to reach understanding. They are designed, consciously or otherwise, to create emotional movement. A person may repeat an accusation after it has been answered, distort something you said, introduce a painful subject at the worst possible moment, mock your calmness, deny an obvious fact or continue messaging until you respond in frustration.</p>
<p>The invitation is always similar: leave your centre and enter their version of the moment.</p>
<p>Once you react, the original issue can disappear. Attention moves from what was done to how you responded. Your raised voice becomes more important than the sustained provocation. Your long message becomes evidence that you are &ldquo;obsessed&rdquo;. Your distress is presented as instability. Your attempt to correct the record is reframed as aggression or control.</p>
<p>This can be especially damaging when you have already been living under stress. You may be carrying grief, betrayal, separation, uncertainty or the exhaustion of not being believed. Your nervous system is not responding only to the sentence in front of you. It may also be responding to every previous occasion on which your reality was denied, your motives were rewritten or your vulnerability was used against you.</p>
<p>The Grey Method begins at precisely this point. It does not ask you to pretend that the situation is harmless. It asks you to stop handing the situation authority over your next action.</p>
<blockquote>
<p>The Grey is where fear loses authority. Not because fear disappears, but because fear is no longer permitted to make the decision.</p>
</blockquote>
</section>
<section>
<h2>What is the Grey Method?</h2>
<p>The Grey Method is a practical expression of the philosophy explored in <em>Walking the Grey</em>. The Grey is the still centre between extremes. It is not indecision, passivity, emotional numbness or moral laziness. It does not mean that every side is equally truthful or that harmful behaviour should be tolerated in the name of balance.</p>
<p>It means refusing the tyranny of extremes.</p>
<p>At one extreme, pain takes command. We react immediately, speak from panic, pursue acknowledgement and try to force truth into a person who has already decided not to receive it. At the other, we suppress everything. We detach from our humanity, call numbness peace and convince ourselves that silence means we have healed.</p>
<p>The Grey is neither explosion nor disappearance. It is conscious containment. You acknowledge the emotion without allowing it to seize control. You recognise manipulation without making manipulation your whole identity. You can hold compassion without abandoning discernment. You can set a boundary without surrendering integrity. You can tell the truth without using force.</p>
<p>In practice, the Grey Method creates enough space between stimulus and action to recover choice. Its purpose is not to &ldquo;win&rdquo; an exchange. Its purpose is to remain sovereign inside it.</p>
</section>
<section>
<h2>The Grey Method is not the grey rock method</h2>
<p>The names sound similar, but the ideas are not identical. The grey rock method usually describes making interactions deliberately uninteresting and emotionally unrewarding when dealing with persistently provocative behaviour. It may involve short replies, limited personal information and minimal emotional display.</p>
<p>The Grey Method is broader. It is not merely a communication tactic and it does not require you to become flat, colourless or absent. It is an internal method of regulation, truth and self possession. Sometimes a short, neutral response will be appropriate. Sometimes a clear boundary is needed. Sometimes the wisest response is no response. At other times, the Grey requires calm, direct action.</p>
<p>The question is not, &ldquo;How do I make myself uninteresting?&rdquo; It is, &ldquo;What response remains aligned with truth, safety and who I intend to be?&rdquo;</p>
</section>
<section>
<h2>Why provocation can feel impossible to resist</h2>
<p>People often judge a reaction as though it occurred in isolation. It rarely does. A reaction may sit at the end of hours, months or years of accumulated pressure. The final message is only the visible spark; it is not the whole fire.</p>
<p>When the brain perceives threat, attention narrows. The body prepares for action. Breathing can become faster, muscles tighten and the urge to defend, escape, explain or regain control intensifies. In that state, immediacy feels like necessity. You may believe you must answer now, correct every detail or make the other person understand before the opportunity disappears.</p>
<p>This does not mean that every strong response is caused by trauma, nor does it remove responsibility for harmful conduct. It means that regulation becomes harder when the body believes something important is under threat: safety, identity, reputation, family, belonging or reality itself.</p>
<p>Provocation can activate several psychological pressures at once:</p>
<ul>
<li><strong>The need to correct injustice:</strong> You fear that silence will allow a false account to become accepted.</li>
<li><strong>The need to be understood:</strong> You keep explaining because you assume the right combination of words must eventually work.</li>
<li><strong>The need to restore connection:</strong> Rejection or withdrawal makes you pursue the conversation more intensely.</li>
<li><strong>The fear of consequences:</strong> You imagine what the allegation, message or silence could mean tomorrow.</li>
<li><strong>The repetition of an old wound:</strong> The present exchange resembles earlier experiences of abandonment, humiliation or disbelief.</li>
</ul>
<p>The Grey does not shame these impulses. It observes them. What can be observed does not have to be obeyed.</p>
</section>
<section>
<h2>Regulation is not suppression</h2>
<p>This distinction is central to <em>Walking the Grey</em>. Suppression says, &ldquo;I must not feel this.&rdquo; Regulation says, &ldquo;I can feel this without allowing it to drive.&rdquo; Suppression pushes emotion out of awareness. Regulation makes room for emotion while preserving the ability to choose.</p>
<p>You are not regulated simply because you look calm. A person can speak quietly while using silence as punishment, planning retaliation or disconnecting completely from their feelings. Equally, visible tears do not mean someone is emotionally unregulated. Emotion and regulation can exist together.</p>
<p>The goal is coherence: your body, words, values and actions are no longer pulling in opposite directions.</p>
<p>The Grey therefore rejects false positivity. You cannot smile your way out of grief, meditate away betrayal or cover genuine pain with inspirational quotations. Pain has to be acknowledged before it can be carried differently. The work is not to paint darkness with artificial light. It is to see clearly enough that neither darkness nor light becomes a place of captivity.</p>
</section>
<section>
<h2>The four movements of the Grey Method</h2>
<h3>1. Stillness: interrupt the reflex</h3>
<p>Stillness is the first refusal. It is the moment in which you decline to act from the first surge of fear, anger or urgency. It may last ten seconds, ten minutes or an entire night. The duration matters less than the function: you are interrupting the automatic journey from trigger to reaction.</p>
<p>Begin with the body because reasoning is difficult when the body is signalling an emergency. Put both feet on the ground. Release your jaw. Lower your shoulders. Look around the room and identify where you are. If breathing exercises suit you, allow your breath to move gently without forcing it. A slower exhalation may help some people settle, while others may prefer movement, touch or sensory grounding.</p>
<p>The NHS recommends calm, regular breathing practised as part of a routine. Grounding approaches use the senses to bring attention back to the present. These are not magical switches. They are ways of reminding the body that a message, accusation or insult does not automatically require immediate action.</p>
<p>Use a sentence that separates feeling from instruction:</p>
<ul>
<li>&ldquo;I feel urgency, but urgency is not a deadline.&rdquo;</li>
<li>&ldquo;I am angry, but anger does not have to write the message.&rdquo;</li>
<li>&ldquo;I am frightened by what this could mean. I do not yet know what it means.&rdquo;</li>
<li>&ldquo;I can return to this when my body is no longer making the decision.&rdquo;</li>
</ul>
<h3>2. Truth: separate facts from fear&rsquo;s story</h3>
<p>Fear is a storyteller. It takes one event and races towards the most catastrophic conclusion. A delayed reply becomes abandonment. An accusation becomes certain ruin. Another person&rsquo;s confidence becomes proof that they are believed. The mind fills every unknown space with danger.</p>
<p>Truth is often quieter. It asks:</p>
<ul>
<li>What do I know directly?</li>
<li>What am I assuming?</li>
<li>What has actually been asked of me?</li>
<li>Does this require a response?</li>
<li>If it requires a response, what is the smallest accurate response?</li>
<li>Am I communicating to clarify, or am I trying to force recognition?</li>
</ul>
<p>Write the facts in plain language. Remove attempts to read another person&rsquo;s mind, predictions and diagnoses. &ldquo;They sent three messages after I asked for space&rdquo; is a fact. &ldquo;They will destroy everything unless I answer&rdquo; is a feared outcome. The fear may deserve attention, planning or professional advice, but it should not be disguised as certainty.</p>
<p>Truth does not become more truthful because it is delivered at greater volume. When we are desperate to be believed, we often add detail until accuracy is buried beneath intensity. The Grey favours coherence over outrage and accuracy over volume.</p>
<h3>3. Endurance: tolerate the discomfort of not reacting</h3>
<p>Pausing does not always bring instant peace. It can initially make discomfort louder. You may feel compelled to check your phone, rewrite the message, gather more proof or imagine what the other person is saying. This is where endurance begins.</p>
<p>Endurance is not passive suffering. It is the ability to remain aligned while discomfort moves through you. You are learning that an urge can rise, peak and change without becoming an action.</p>
<p>Give the energy somewhere safe to go. Walk. Stretch. Write the unfiltered response in a private note that will not be sent. Play music. Use visualisation, purposeful focus, prayer, Reiki or another grounded practice that genuinely returns you to yourself. Speak to someone trustworthy who will help you become clearer rather than more inflamed.</p>
<p>The point is not distraction for its own sake. It is to prevent temporary activation from creating permanent consequences.</p>
<h3>4. Reclamation: choose the next action deliberately</h3>
<p>Reclamation is the return of authorship. Instead of asking, &ldquo;What response will make them stop, agree or finally understand?&rdquo;, ask, &ldquo;What action can I respect tomorrow?&rdquo;</p>
<p>Your options may include responding briefly, correcting one material fact, setting a boundary, postponing the discussion, documenting the communication, using an agreed channel, obtaining advice or ending the exchange.</p>
<p>A Grey response is usually shorter than a fear response. It is not designed to answer every possible accusation. It addresses what is necessary and leaves the rest outside the door.</p>
</section>
<section>
<h2>The Grey Pause: a practical method for difficult moments</h2>
<ol>
<li><strong>Stop the outward action.</strong> Do not send, post, call or confront during the first surge unless immediate safety requires action.</li>
<li><strong>Locate the reaction in your body.</strong> Notice your breathing, jaw, chest, hands, stomach and posture without judging them.</li>
<li><strong>Name the emotion accurately.</strong> Go beneath &ldquo;angry&rdquo; where possible. You might be humiliated, frightened, powerless, rejected, cornered or overwhelmed by grief.</li>
<li><strong>Name the threatened value.</strong> Is this touching truth, family, safety, identity, fairness, dignity or belonging?</li>
<li><strong>Separate fact, interpretation and fear.</strong> Put each into a different sentence.</li>
<li><strong>Identify the actual decision.</strong> It may simply be whether to respond today, rather than how to solve the entire relationship.</li>
<li><strong>Choose the least reactive effective action.</strong> Do what protects truth, safety and integrity with the least unnecessary escalation.</li>
<li><strong>Review before sending.</strong> Remove insults, diagnoses, threats, repetition and anything written only to cause pain.</li>
</ol>
</section>
<section>
<h2>What regulated communication sounds like</h2>
<p>Regulated communication is not weak. It is clear enough that it does not need decoration. Depending on the situation, you might say:</p>
<ul>
<li>&ldquo;I have answered that point and I will not repeat the discussion.&rdquo;</li>
<li>&ldquo;I am willing to discuss the practical issue, but not while insults are being used.&rdquo;</li>
<li>&ldquo;I do not agree with that account. My position is set out below.&rdquo;</li>
<li>&ldquo;I will respond tomorrow when I have had time to consider this properly.&rdquo;</li>
<li>&ldquo;Please keep future communication to the agreed subject.&rdquo;</li>
<li>&ldquo;I am ending this conversation for now.&rdquo;</li>
<li>&ldquo;I have recorded your request. I will obtain advice before responding.&rdquo;</li>
</ul>
<p>Notice what these statements do not contain. They do not diagnose the other person, speculate about motives, relitigate the entire history or beg for validation. They preserve the speaker&rsquo;s position without making emotional surrender the price of peace.</p>
</section>
<section>
<h2>Truth without force</h2>
<p>One of the hardest lessons in the Grey is that truth cannot always be made visible on demand. You can possess evidence and still be misunderstood. You can explain yourself honestly and still encounter a person committed to a different narrative. You can behave with integrity and still lose control of how others describe you.</p>
<p>This creates a particular kind of desperation. You may believe that one more paragraph, screenshot or confrontation will finally break through. Sometimes clarification is necessary. However, there is a point at which explanation stops serving truth and begins serving fear.</p>
<p>Truth without force means presenting what is accurate, proportionate and relevant, then allowing it to stand. It means keeping records where appropriate without living permanently inside them. It means accepting that your responsibility is to communicate honestly, not to control every interpretation.</p>
<blockquote>
<p>Fear tells stories. Truth remains still.</p>
</blockquote>
</section>
<section>
<h2>Empathy without surrender</h2>
<p>Empathy is often misunderstood as unlimited access, instant forgiveness or agreement. It is none of these. You can understand that someone acts from fear, shame or their own history without consenting to be harmed by the result.</p>
<p>The Grey allows two truths to exist together: a person may be wounded, and their behaviour may still be unacceptable. Understanding context does not remove accountability. Compassion does not require you to erase yourself.</p>
<p>Empathy without surrender sounds like:</p>
<ul>
<li>&ldquo;I understand that you are upset. I will not continue while I am being threatened.&rdquo;</li>
<li>&ldquo;Your feelings matter, but they do not determine the facts.&rdquo;</li>
<li>&ldquo;I can recognise your pain without accepting responsibility for everything you feel.&rdquo;</li>
<li>&ldquo;I wish you well, and this boundary remains.&rdquo;</li>
</ul>
</section>
<section>
<h2>Boundaries are actions, not attempts to control</h2>
<p>A boundary describes what you will do to protect your wellbeing, safety or integrity. A demand tries to control what another person must think, feel or become. The distinction matters.</p>
<p>&ldquo;You are not allowed to speak negatively about me&rdquo; is difficult to enforce and attempts to control another person&rsquo;s speech. &ldquo;If the conversation becomes abusive, I will end it and communicate through the agreed written channel&rdquo; describes your own action.</p>
<p>A boundary does not become real because it is explained beautifully. It becomes real when it is followed consistently. Repeatedly announcing a consequence that never occurs teaches the other person that the boundary is negotiable.</p>
<p>The Grey does not use boundaries as punishment. It uses them as structure.</p>
</section>
<section>
<h2>When silence is wise and when it is avoidance</h2>
<p>Silence can protect peace, prevent escalation and deny provocation the reaction it seeks. It can also be used to avoid necessary responsibility or punish another person. The behaviour can look similar from the outside, but the intention and context are different.</p>
<p>Before choosing silence, ask:</p>
<ul>
<li>Am I pausing so I can respond more clearly?</li>
<li>Have I communicated that I need time, where doing so is safe and appropriate?</li>
<li>Is there a practical, safeguarding, professional or legal matter that genuinely requires an answer?</li>
<li>Am I protecting a boundary, or trying to make the other person anxious?</li>
<li>Will silence reduce harm, or merely delay a conversation I need to face?</li>
</ul>
<p>The Grey is not a rule that says &ldquo;never respond&rdquo;. It is the capacity to decide why you are responding or why you are not.</p>
</section>
<section>
<h2>Common mistakes when trying to stay regulated</h2>
<h3>Performing calmness</h3>
<p>Regulation is not a performance designed to show moral superiority. A slow, patronising voice can provoke just as effectively as shouting. Genuine regulation seeks clarity, not victory through appearance.</p>
<h3>Using psychological labels as weapons</h3>
<p>Calling someone a narcissist, psychopath, gaslighter or abuser during an argument rarely creates safety or understanding. Describe observable behaviour instead. You do not need a diagnosis to recognise that an interaction is harmful.</p>
<h3>Explaining too much</h3>
<p>Long messages can feel protective because they appear to close every gap. In reality, they may introduce new points to dispute. Say what is material. Accuracy is more powerful than volume.</p>
<h3>Confusing endurance with tolerating danger</h3>
<p>Remaining centred does not mean remaining physically present in an unsafe environment. The most regulated action may be leaving, calling for help or involving appropriate services.</p>
<h3>Expecting one technique to remove all emotion</h3>
<p>Breathing, grounding, Reiki, movement and mindfulness can support regulation, but they do not erase grief or guarantee calm. Some people find exercises focused on breathing uncomfortable, particularly during panic or trauma activation. Choose a safe grounding method that suits you and seek professional support when needed.</p>
<h3>Believing that calm guarantees a fair outcome</h3>
<p>Regulation improves your ability to act coherently. It does not control another person, guarantee that an institution will understand or ensure that justice arrives quickly. The Grey is not a bargain in which calm behaviour purchases certainty. It is how you preserve yourself when certainty is unavailable.</p>
</section>
<section>
<h2>Using the Grey Method in difficult communication</h2>
<p>Where communication is persistently difficult, structure can reduce the number of decisions made under pressure:</p>
<ul>
<li>Choose specific times to read and answer messages that are not urgent rather than remaining constantly alert.</li>
<li>Use one appropriate communication channel where possible.</li>
<li>Address one practical subject at a time.</li>
<li>Keep replies brief, factual, courteous and firm.</li>
<li>Do not answer insults simply because they appear beside a legitimate question.</li>
<li>Keep proportionate records when there is a genuine reason to do so.</li>
<li>Ask a trusted professional to review important communication when the consequences may be serious.</li>
<li>Do not post the conflict publicly while emotionally activated.</li>
</ul>
<p>If legal proceedings, child welfare, employment, harassment or personal safety are involved, obtain advice relevant to your circumstances. An emotional regulation framework can help you communicate clearly, but it cannot determine legal strategy or safeguarding decisions.</p>
</section>
<section>
<h2>After the interaction: completing the stress cycle</h2>
<p>Not sending the reactive message is only part of the work. The emotional and physical energy still needs care. Otherwise, regulation can quietly become accumulation.</p>
<p>After a difficult exchange:</p>
<ol>
<li><strong>Acknowledge what happened.</strong> Do not minimise the impact merely because you handled it well.</li>
<li><strong>Move the body.</strong> A walk, gentle stretching or another suitable activity may help release tension.</li>
<li><strong>Orient yourself to the present.</strong> Use your senses to notice what is around you now.</li>
<li><strong>Record only what is useful.</strong> Document necessary facts, then step away rather than reading the exchange repeatedly.</li>
<li><strong>Restore identity.</strong> Do something that belongs to your life beyond the conflict: music, work, creativity, family, nature, spirituality or rest.</li>
<li><strong>Reflect without attacking yourself.</strong> Ask what worked and what you would change next time.</li>
</ol>
<p>Recovery is often a slow, structured return to self. There may be no dramatic moment when everything feels resolved. Reclamation happens each time you refuse to let another person&rsquo;s behaviour become the permanent centre of your inner life.</p>
</section>
<section>
<h2>Practising before the next difficult moment</h2>
<p>Regulation is easier to access under pressure when it has been practised outside pressure. Build a small daily ritual rather than waiting for a crisis:</p>
<ul>
<li>Spend five minutes noticing your breathing or using another grounding practice.</li>
<li>Identify your early signs of activation, such as faster typing, tight shoulders, mental rehearsals or an urge to prove yourself.</li>
<li>Write three boundary sentences you can use without inventing language in the moment.</li>
<li>Choose one trusted person who understands that their role is to help you find clarity, not escalate anger.</li>
<li>Create a rule for important messages, such as drafting first and reviewing after a pause.</li>
<li>Practise naming facts separately from fears and interpretations.</li>
</ul>
<p>The aim is not perfection. You will sometimes react. You may send something you regret, explain too much or realise that fear had more authority than you thought. The Grey does not demand that you punish yourself. Accountability means acknowledging the action, repairing what can be repaired, learning and returning to the centre.</p>
</section>
<section>
<h2>The deeper purpose: becoming ungovernable by fear</h2>
<p>The work is not about becoming fearless. Fear is part of being human. It warns, protects, remembers and imagines. However, fear becomes dangerous when every warning is treated as a command and every imagined outcome as fact.</p>
<p>To become ungovernable by fear is not to become reckless. It is to stop allowing fear to write your messages, select your enemies, define your worth and determine the shape of your future.</p>
<p>This is why the Grey is more than a technique for dealing with a difficult person. It is a way of reclaiming authorship after periods in which your emotional life has been organised around threat. It asks you to remain present in uncertainty, accurate under pressure and human in the presence of behaviour that could easily harden you.</p>
<p>You do not have to reject light or immerse yourself in shadow. You can recognise both and refuse captivity to either. You can carry pain without turning pain into identity. You can recognise manipulation without losing compassion. You can protect yourself without becoming what harmed you.</p>
</section>
<section>
<h2>A final reflection</h2>
<p>There will be moments when someone appears to want your reaction more than they want resolution. They may press the same wound, challenge your reality or offer you a version of yourself that you feel compelled to defeat.</p>
<p>You do not have to enter every story told about you.</p>
<p>Pause. Return to the body. Separate truth from prediction. Let the first wave pass. Decide what safety, integrity and reality require, not what fear demands. Speak only what needs to be spoken. Leave what cannot be resolved without surrendering yourself.</p>
<p>The Grey is not uncertainty. It is the place where reaction becomes reflection, fear becomes understanding and strength no longer needs to announce itself.</p>
<p>That is not weakness. That is mastery without suppression.</p>
</section>
<section class="article-help">
<h2>When to seek further support</h2>
<p>Consider speaking with a qualified mental health professional if emotional activation is frequent, overwhelming or connected with trauma, panic, depression, self harm, substance use or difficulties functioning in daily life. Contact emergency services if anyone is in immediate danger. In the UK, NHS 111 can direct you to urgent help, and 999 should be used in an emergency.</p>
</section>
<section class="article-sources">
<h2>Further reading and evidence</h2>
<ul>
<li><a href="https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/" target="_blank" rel="noopener noreferrer">NHS: Breathing exercises for stress</a></li>
<li><a href="https://www.nhs.uk/mental-health/self-help/tips-and-support/mindfulness/" target="_blank" rel="noopener noreferrer">NHS: Mindfulness and present moment awareness</a></li>
<li><a href="https://library.sheffieldchildrens.nhs.uk/grounding-techniques/" target="_blank" rel="noopener noreferrer">Sheffield Children&rsquo;s NHS Foundation Trust: Grounding techniques</a></li>
<li><a href="https://pubmed.ncbi.nlm.nih.gov/30245619/" target="_blank" rel="noopener noreferrer">Zaccaro and colleagues: Systematic review of slow breathing and its psychological and physiological effects</a></li>
<li><a href="https://pubmed.ncbi.nlm.nih.gov/35623448/" target="_blank" rel="noopener noreferrer">Laborde and colleagues: Systematic review of voluntary slow breathing and heart rate variability</a></li>
</ul>
</section>
<footer class="article-footer">
<p><strong>About the framework:</strong> The Grey Method is informed by Andy Fish&rsquo;s <em>Walking the Grey</em>, a philosophy of regulation, truth, endurance and reclamation. It encourages thoughtful responses under pressure while recognising that healing does not require denial, forced positivity or the abandonment of appropriate boundaries.</p>
</footer></article>

---
title: "DARVO: When the Person Who Hurt You Claims to Be the Victim"
seoTitle: "What Is DARVO? Denial, Blame Shifting & Family Court"
metaDescription: "What is DARVO? Explore the psychology of denial, attack and victim-offender reversal, including coercive control, smear campaigns, children and family court."
slug: "what-is-darvo-denial-attack-reverse-victim-offender"
categories: "Parental Alienation & DARVO"
tags: "['Darvo']"
author: "Reiki Fish"
featured: false
draft: false
date: "2026-08-06"
excerpt: "DARVO can turn accountability upside down. The person confronted about harmful behaviour denies what happened, attacks the credibility of the person raising it, then presents themselves as the real victim. This evidence-led guide examines the psychology of DARVO, coercive control, smear campaigns, post-separation abuse, children being drawn into adult conflict and the particular difficulties these patterns can create in family court."
featuredImage: "assets/images/blog/darvo.png"
featuredImageAlt: "Two adults in conflict with a reversing loop, representing denial, blame shifting and role reversal in DARVO."
---

<p>You confront somebody about something they have done.</p>
<p>They deny it.</p>
<p>Then something unexpected happens.</p>
<p>Instead of discussing their behaviour, they begin attacking you.</p>
<p>Your credibility. Your personality. Your mental health. Your motives. Your past. Perhaps your parenting.</p>
<p>Within minutes, the original behaviour has almost disappeared from the conversation.</p>
<p>Now they are the injured party.</p>
<p>And somehow, you are defending yourself.</p>
<p>This psychological pattern has a name:</p>
<p><strong>DARVO.</strong></p>
<p>It stands for:</p>
<ul>
<li><strong>Deny.</strong></li>
<li><strong>Attack.</strong></li>
<li><strong>Reverse Victim and Offender.</strong></li>
</ul>
<p>DARVO was introduced by psychologist Jennifer Freyd in the context of studying responses to confrontation and accountability, particularly surrounding abuse.</p>
<p>It is now supported by an emerging empirical research literature examining how DARVO can affect victims and even the people observing a dispute.</p>
<p>But DARVO needs to be understood properly.</p>
<ul>
<li>It is not a psychiatric diagnosis.</li>
<li>It is not exclusive to narcissism.</li>
<li>It does not prove that every person who denies an allegation is guilty.</li>
<li>It is not evidence that an accusation must be true.</li>
<li>It describes a particular <strong>defensive pattern of behaviour</strong>.</li>
</ul>
<p>And when that pattern is successfully used, something psychologically extraordinary can happen:</p>
<p><strong>the conversation can move away from what the accused person allegedly did and towards what is supposedly wrong with the person who raised it.</strong></p>
<h2>What Does DARVO Actually Mean?</h2>
<p>The sequence is relatively simple.</p>
<h3>Stage One: Deny</h3>
<p>The person rejects responsibility.</p>
<p>That denial might sound like:</p>
<ul>
<li>&ldquo;That never happened.&rdquo;</li>
<li>&ldquo;I never said that.&rdquo;</li>
<li>&ldquo;You're imagining it.&rdquo;</li>
<li>&ldquo;You're exaggerating.&rdquo;</li>
<li>&ldquo;That's completely false.&rdquo;</li>
<li>&ldquo;I don't know what you're talking about.&rdquo;</li>
</ul>
<p>But an immediate warning is necessary.</p>
<p><strong>Denial by itself is not DARVO and does not establish guilt.</strong></p>
<p>An innocent person who is falsely accused will probably deny the allegation too.</p>
<p>Psychology must never turn &ldquo;they denied it&rdquo; into &ldquo;therefore they did it&rdquo;.</p>
<p>DARVO concerns the broader response pattern.</p>
<h3>Stage Two: Attack</h3>
<p>The focus moves away from the alleged behaviour and onto the person raising it.</p>
<p>Their credibility may be attacked.</p>
<p>Their motives may be questioned.</p>
<p>Their emotional response may itself become evidence supposedly demonstrating that they are irrational or malicious.</p>
<p>Examples might include:</p>
<ul>
<li>&ldquo;You're crazy.&rdquo;</li>
<li>&ldquo;You're obsessed with me.&rdquo;</li>
<li>&ldquo;Everyone knows what you're really like.&rdquo;</li>
<li>&ldquo;You're only saying this because I left you.&rdquo;</li>
<li>&ldquo;You're the abusive one.&rdquo;</li>
<li>&ldquo;You're mentally unstable.&rdquo;</li>
<li>&ldquo;You're trying to destroy me.&rdquo;</li>
<li>&ldquo;You've always been manipulative.&rdquo;</li>
</ul>
<p>Notice what has happened.</p>
<p>The subject of the conversation is changing.</p>
<h3>Stage Three: Reverse Victim and Offender</h3>
<p>This is the defining reversal.</p>
<p>The person confronted about alleged wrongdoing positions themselves as the real victim while portraying the person who raised the concern as the offender.</p>
<p>The narrative becomes:</p>
<p><strong>&ldquo;You are not the victim of my behaviour. I am the victim of your accusation.&rdquo;</strong></p>
<p>That reversal can be extremely powerful because the original complainant is suddenly required to defend themselves.</p>
<h2>A Simple Example of DARVO</h2>
<p>Imagine somebody discovers that their partner has secretly been taking money from their account.</p>
<p>They say:</p>
<p><strong>&ldquo;&pound;700 has disappeared from our account and these transactions came from your card. Why didn't you tell me?&rdquo;</strong></p>
<p>The response might develop like this:</p>
<p><strong>Deny:</strong> &ldquo;I haven't taken anything. You don't know what you're talking about.&rdquo;</p>
<p><strong>Attack:</strong> &ldquo;You're completely obsessed with controlling money. You monitor everything I do. You're paranoid.&rdquo;</p>
<p><strong>Reverse:</strong> &ldquo;I'm actually frightened of you. You're financially controlling me.&rdquo;</p>
<p>Notice that the original question has vanished:</p>
<p><strong>What happened to the &pound;700?</strong></p>
<p>That is the functional power of a DARVO-style response.</p>
<p>It can shift attention from evidence to identity.</p>
<h2>Why DARVO Can Be So Effective</h2>
<p>Human beings are highly influenced by narrative structure.</p>
<p>When somebody responds confidently, angrily or emotionally to an accusation, observers can become distracted from the original evidence.</p>
<p>The argument changes from:</p>
<p><strong>&ldquo;Did X happen?&rdquo;</strong></p>
<p>to:</p>
<p><strong>&ldquo;Which of these people seems more believable?&rdquo;</strong></p>
<p>Those are not the same question.</p>
<p>Empirical DARVO research has examined this effect.</p>
<p>Experimental work by Sarah Harsey and Jennifer Freyd has found that exposure to a DARVO response can affect third-party perceptions of victims and accused perpetrators.</p>
<p>Research has also associated experiencing DARVO with greater victim self-blame.</p>
<p>That matters because DARVO may influence two audiences simultaneously:</p>
<ul>
<li>The person being confronted.</li>
<li>The people watching the dispute.</li>
</ul>
<h2>DARVO Can Make the Victim Question Themselves</h2>
<p>Imagine repeatedly confronting somebody about harmful behaviour and repeatedly leaving the conversation apologising yourself.</p>
<p>Over time you may begin thinking:</p>
<ul>
<li>&ldquo;Maybe I am too sensitive.&rdquo;</li>
<li>&ldquo;Perhaps I caused this.&rdquo;</li>
<li>&ldquo;Maybe I am the abusive one.&rdquo;</li>
<li>&ldquo;Perhaps I remembered it incorrectly.&rdquo;</li>
<li>&ldquo;Maybe I shouldn't have confronted them.&rdquo;</li>
</ul>
<p>This is one reason victim-blaming responses can be psychologically powerful.</p>
<p>The target is no longer simply processing the original event.</p>
<p>They are also defending their identity.</p>
<h2>DARVO and Gaslighting: Similar, but Not Identical</h2>
<p>The terms are often used interchangeably online.</p>
<p>They should not be.</p>
<p>Gaslighting generally refers to manipulative behaviour that undermines another person's confidence in their perception, memory or understanding of reality.</p>
<p>DARVO specifically describes the sequence:</p>
<ul>
<li>Deny wrongdoing.</li>
<li>Attack the accuser.</li>
<li>Reverse victim and offender roles.</li>
</ul>
<p>The two patterns can occur together.</p>
<p>For example:</p>
<p><strong>&ldquo;That never happened. You're delusional. In fact, your constant accusations are emotionally abusing me.&rdquo;</strong></p>
<p>That statement could contain elements consistent with both gaslighting and DARVO.</p>
<p>But the concepts remain distinct.</p>
<h2>DARVO Is Not a Narcissism Test</h2>
<p>This needs to be made absolutely clear.</p>
<p>DARVO is frequently presented online as:</p>
<p><strong>&ldquo;What narcissists always do when confronted.&rdquo;</strong></p>
<p>That is not an accurate clinical definition.</p>
<p>Narcissistic personality pathology may include characteristics that could make defensive blame-shifting or attacking responses possible.</p>
<p>But DARVO is not a diagnostic criterion for Narcissistic Personality Disorder.</p>
<p>The existence of a DARVO-style response therefore does not establish NPD.</p>
<p>Likewise, somebody can display narcissistic personality pathology without every confrontation following DARVO.</p>
<p>Behaviour first.</p>
<p>Diagnosis second, and only when qualified assessment justifies it.</p>
<h2>Perhaps the Most Important Warning: DARVO Is Not a Lie Detector</h2>
<p>Suppose Person A accuses Person B of assault.</p>
<p>Person B says:</p>
<p><strong>&ldquo;That isn't true.&rdquo;</strong></p>
<p>You cannot conclude:</p>
<p><strong>&ldquo;They denied it. That's DARVO. Therefore the assault occurred.&rdquo;</strong></p>
<p>That would be circular reasoning.</p>
<p>An innocent person will deny an allegation they believe to be false.</p>
<p>Likewise, an accused person may become angry because they feel genuinely wronged.</p>
<p>DARVO becomes a useful analytical concept when examining the <strong>pattern and function</strong> of a response.</p>
<p>Where objective evidence is available, evidence remains more important than psychological labels.</p>
<h2>DARVO and Smear Campaigns</h2>
<p>Role reversal does not necessarily stay inside a private conversation.</p>
<p>Sometimes conflict expands into the social environment.</p>
<p>The accused person may tell:</p>
<ul>
<li>Friends.</li>
<li>Family members.</li>
<li>Colleagues.</li>
<li>Employers.</li>
<li>Online communities.</li>
<li>Professionals.</li>
<li>New partners.</li>
</ul>
<p>a version of events in which they are the victim.</p>
<p>This can create an apparent reputational advantage.</p>
<p>But again, the word <strong>smear campaign</strong> must be used carefully.</p>
<p>Someone telling people that they believe they have been mistreated is not automatically conducting a smear campaign.</p>
<p>The important questions include:</p>
<ul>
<li>What exactly was said?</li>
<li>Was it true?</li>
<li>Was material omitted?</li>
<li>Was information deliberately distorted?</li>
<li>Was the objective support, protection or retaliation?</li>
<li>Was there organised reputational harm?</li>
<li>What independent evidence exists?</li>
</ul>
<p>A label should never replace those questions.</p>
<h2>DARVO and Social Media</h2>
<p>Social media can supercharge role reversal.</p>
<p>Before the internet, reputational conflict might have remained within a family or friendship group.</p>
<p>Today one post can reach thousands of people.</p>
<p>A person can present:</p>
<ul>
<li>Selected screenshots.</li>
<li>Partial conversations.</li>
<li>Emotionally powerful videos.</li>
<li>Psychological terminology.</li>
<li>Unverified allegations.</li>
</ul>
<p>to an audience that knows neither participant.</p>
<p>Online observers then start diagnosing strangers.</p>
<p>One side is labelled narcissistic.</p>
<p>The other is labelled borderline.</p>
<p>Comments become evidence.</p>
<p>Popularity becomes credibility.</p>
<p>None of this establishes what actually happened.</p>
<p>The number of people believing a story does not determine whether it is true.</p>
<h2>DARVO, Reactive Behaviour and the &ldquo;Perfect Victim&rdquo; Problem</h2>
<p>Victims do not always respond calmly.</p>
<p>Someone who has experienced prolonged hostility, fear or provocation may:</p>
<ul>
<li>Shout.</li>
<li>Swear.</li>
<li>Send angry messages.</li>
<li>Become emotionally dysregulated.</li>
<li>Say something they later regret.</li>
</ul>
<p>Those behaviours must still be evaluated honestly.</p>
<p>But one angry response does not erase everything that preceded it.</p>
<p>This is why investigators and clinicians should be interested in patterns, chronology and context.</p>
<p>A snapshot can mislead.</p>
<p>A timeline can clarify.</p>
<h2>Why Chronology Is So Important</h2>
<p>Imagine seeing a message saying:</p>
<p><strong>&ldquo;Leave me alone. I hate you. I never want to see you again.&rdquo;</strong></p>
<p>Without context, the sender appears hostile.</p>
<p>Now imagine discovering that it followed 150 unwanted messages over three nights.</p>
<p>The meaning changes.</p>
<p>Context does not automatically justify every response.</p>
<p>But behavioural interpretation requires sequence.</p>
<p>When examining a possible DARVO pattern, ask:</p>
<ul>
<li>What happened first?</li>
<li>What allegation or concern was originally raised?</li>
<li>What evidence existed?</li>
<li>What was the first response?</li>
<li>When did the attack on credibility begin?</li>
<li>When were roles reversed?</li>
<li>Did the original allegation ever get addressed?</li>
</ul>
<h2>Post-Separation Abuse: Why Leaving Does Not Always End the Dynamic</h2>
<p>Separation can end a relationship without necessarily ending control.</p>
<p>Where coercive or controlling behaviour genuinely exists, post-separation contact, finances, property, children and legal proceedings can become new arenas of conflict.</p>
<p>This is recognised within research and policy discussions surrounding domestic abuse.</p>
<p>The UK's Ministry of Justice Harm Panel examined how domestic-abuse allegations and risks of harm are handled in private family-law children proceedings in England and Wales.</p>
<p>The panel documented serious concerns raised by parents and professionals concerning the experiences of victims and children within family proceedings.</p>
<p>More recent UK policy work has continued examining how family proceedings can interact with domestic abuse and post-separation control.</p>
<h2>When Children Become the Battlefield</h2>
<p>This is one of the most serious sections of this article.</p>
<p>Children can be placed inside adult conflict in ways that are profoundly harmful.</p>
<p>This may involve:</p>
<ul>
<li>Using the child as a messenger.</li>
<li>Asking the child to spy upon the other parent.</li>
<li>Interrogating them following contact.</li>
<li>Sharing adult allegations with them.</li>
<li>Repeatedly criticising the other parent in their presence.</li>
<li>Making a child feel guilty for loving the other parent.</li>
<li>Pressuring the child to take sides.</li>
<li>Using access to the child as leverage against the other parent.</li>
<li>Creating loyalty conflicts.</li>
<li>Encouraging a child to carry adult emotional responsibilities.</li>
<li>Using children to obtain information about an ex-partner.</li>
<li>Attempting to damage the child's relationship with the other parent.</li>
</ul>
<p>These behaviours should not be normalised as &ldquo;messy divorce&rdquo;.</p>
<p>They can be psychologically harmful.</p>
<h2>Alienating Behaviours Are Recognised</h2>
<p>In England, Cafcass now explicitly uses the term <strong>alienating behaviours</strong>.</p>
<p>It describes an ongoing pattern of negative attitudes and communication concerning another parent or carer that can undermine, manipulate or potentially destroy a child's relationship with them.</p>
<p>Cafcass specifically recognises that such behaviour can damage a child's:</p>
<ul>
<li>Sense of identity.</li>
<li>Self-worth.</li>
<li>Relationship with a parent.</li>
<li>Connection with wider family.</li>
</ul>
<p>That is important.</p>
<p>Children really can be influenced by adult behaviour.</p>
<p>It should not be whitewashed simply because the subject is controversial.</p>
<h2>But &ldquo;Parental Alienation&rdquo; Can Also Be Used as a Counter-Allegation</h2>
<p>The opposite problem is equally real.</p>
<p>A parent may raise genuine domestic-abuse concerns and then be accused of alienating the child.</p>
<p>Cafcass itself explicitly acknowledges this possibility.</p>
<p>Current Cafcass guidance states that professionals must be aware that an allegation of alienation can be used to counter what is being said about domestic abuse.</p>
<p>That creates one of the most difficult problems in family assessment.</p>
<p>Is the child rejecting a parent because:</p>
<ul>
<li>They have genuinely experienced or witnessed harmful behaviour?</li>
<li>They are frightened?</li>
<li>The relationship was poor before separation?</li>
<li>They are reacting to parental conflict?</li>
<li>Another parent has influenced their perception?</li>
<li>They are experiencing a loyalty conflict?</li>
<li>Several of these factors are occurring simultaneously?</li>
</ul>
<p>Those possibilities require investigation.</p>
<h2>The Child's Voice Matters, but So Does the Context of That Voice</h2>
<p>Children are not robots.</p>
<p>They can form authentic opinions.</p>
<p>They can also be influenced, just as adults can.</p>
<p>A mature approach therefore avoids two dangerous extremes.</p>
<p>Extreme one:</p>
<p><strong>&ldquo;The child said it, therefore no further examination is needed.&rdquo;</strong></p>
<p>Extreme two:</p>
<p><strong>&ldquo;The child disagrees with me, therefore they have been brainwashed.&rdquo;</strong></p>
<p>Both can be wrong.</p>
<p>The important question is:</p>
<p><strong>&ldquo;Why does this particular child hold this particular view?&rdquo;</strong></p>
<p>That requires curiosity rather than predetermined conclusions.</p>
<h2>Children Can Experience Coercion Without Being Told Exactly What to Say</h2>
<p>Influence can be subtle.</p>
<p>A parent does not necessarily need to give a child a script.</p>
<p>Children are extraordinarily sensitive to emotional environments.</p>
<p>Imagine a child discovers:</p>
<ul>
<li>Mum becomes distressed when Dad is mentioned.</li>
<li>Dad becomes angry when the child says they enjoyed seeing Mum.</li>
<li>One household rewards criticism of the other parent.</li>
<li>Praise of the other parent produces silence or tension.</li>
</ul>
<p>The child may learn what is emotionally safe to say.</p>
<p>This does not automatically prove deliberate coaching.</p>
<p>It illustrates how loyalty conflicts can develop without explicit instructions.</p>
<h2>Do Not Interrogate a Child to Prove Coercion</h2>
<p>If you believe your child has been influenced, one of the worst responses can be repeatedly questioning them yourself.</p>
<p>Avoid questions such as:</p>
<ul>
<li>&ldquo;Did Mum tell you to say that?&rdquo;</li>
<li>&ldquo;Dad made you say this, didn't he?&rdquo;</li>
<li>&ldquo;You know that isn't true.&rdquo;</li>
<li>&ldquo;Tell the social worker what really happened.&rdquo;</li>
<li>&ldquo;Why are you lying about me?&rdquo;</li>
</ul>
<p>Leading questions can increase pressure on the child and contaminate the very information that needs careful assessment.</p>
<p>Serious concerns should be handled through appropriate professional channels.</p>
<h2>DARVO in Family-Court Conflict</h2>
<p>Family proceedings create conditions in which competing allegations may become extremely complex.</p>
<p>Imagine Parent A alleges coercive control.</p>
<p>Parent B says the allegation is fabricated and that Parent A is actually manipulating the child.</p>
<p>Parent A then says the alienation allegation itself is DARVO.</p>
<p>Parent B replies that the abuse allegation is DARVO.</p>
<p>At this point, psychological terminology has solved nothing.</p>
<p>The court needs evidence.</p>
<p>That is the critical lesson.</p>
<p><strong>DARVO should help identify a pattern worth examining. It should never determine legal facts by itself.</strong></p>
<h2>Why Family-Court DARVO Can Be Particularly Powerful</h2>
<p>Ordinary relationship DARVO may influence friends and family.</p>
<p>Within litigation, the potential audience expands to:</p>
<ul>
<li>Solicitors.</li>
<li>Social workers.</li>
<li>Child welfare professionals.</li>
<li>Experts.</li>
<li>Judges or sheriffs.</li>
<li>Police.</li>
<li>Schools.</li>
<li>Health professionals.</li>
</ul>
<p>A successfully reversed narrative can therefore feel devastating.</p>
<p>The person originally raising concerns may believe they are now defending themselves everywhere they turn.</p>
<p>This is why careful evidence gathering matters more than escalating psychological labels.</p>
<h2>Litigation Can Itself Become Part of Post-Separation Abuse</h2>
<p>Research and policy literature have examined what is sometimes described as <strong>litigation abuse</strong> or abuse through legal and administrative processes.</p>
<p>The concept concerns circumstances in which processes intended to resolve disputes are instead repeatedly used as a mechanism of harassment, control, financial depletion or continuing contact.</p>
<p>This does not mean that somebody is abusive simply because they exercise their legal rights.</p>
<p>People are entitled to make legitimate applications, defend allegations and seek appropriate orders.</p>
<p>The distinction is between legitimate access to justice and a documented pattern of process being used abusively.</p>
<h2>DARVO and Institutional Betrayal</h2>
<p>Jennifer Freyd's wider work also examines institutional betrayal.</p>
<p>This describes circumstances in which institutions upon which people depend fail to prevent or respond appropriately to wrongdoing.</p>
<p>DARVO can become especially powerful when an institution adopts the reversed narrative without sufficient examination.</p>
<p>The victim may then experience two injuries:</p>
<ul>
<li>The original harm.</li>
<li>The failure of the institution expected to respond appropriately.</li>
</ul>
<p>This does not mean every unfavourable professional decision is institutional betrayal.</p>
<p>Institutions sometimes reject allegations because the evidence does not establish them.</p>
<p>Again, evidence and process matter.</p>
<h2>DARVO and False Allegations</h2>
<p>This is where intellectual honesty matters.</p>
<p>False allegations can occur.</p>
<p>True allegations can be falsely characterised as lies.</p>
<p>Both realities can exist simultaneously.</p>
<p>An innocent person defending themselves against a false allegation is not automatically performing DARVO merely because they deny it and say they have been wronged.</p>
<p>Similarly, an accused person's claim that an allegation is false does not make it false.</p>
<p>The correct approach is:</p>
<ul>
<li>Identify the allegation precisely.</li>
<li>Identify the response precisely.</li>
<li>Examine contemporaneous evidence.</li>
<li>Examine independent evidence.</li>
<li>Test material inconsistencies.</li>
<li>Consider alternative explanations.</li>
<li>Keep allegation separate from established fact.</li>
</ul>
<h2>A Real Lesson From Scottish Family Proceedings: Evidence Matters</h2>
<p>A 2025 published Scottish Court of Session judgment illustrates an important legal principle particularly well.</p>
<p>The court distinguished between the mere fact that an allegation had been made and evidence capable of being accepted.</p>
<p>That is exactly the discipline required when discussing DARVO.</p>
<p>Courts should not automatically assume:</p>
<p><strong>&ldquo;Allegation = fact.&rdquo;</strong></p>
<p>Nor:</p>
<p><strong>&ldquo;Denial = innocence.&rdquo;</strong></p>
<p>Evidence must be evaluated.</p>
<h2>Scotland and Coercive Control</h2>
<p>Scotland has specific legislation addressing abusive courses of behaviour between partners and former partners.</p>
<p>The Domestic Abuse (Scotland) Act 2018 recognises abusive courses of conduct and includes provisions concerning the involvement of children.</p>
<p>The legislation reflects a modern understanding that domestic abuse can extend beyond isolated physical incidents.</p>
<p>Coercive and controlling patterns can involve psychological, practical and behavioural domination.</p>
<p>That broader understanding is highly relevant when considering post-separation behaviour.</p>
<h2>Children Are Not Evidence Weapons</h2>
<p>A child should never become:</p>
<ul>
<li>A witness recruited by a parent.</li>
<li>A messenger.</li>
<li>A spy.</li>
<li>A therapist.</li>
<li>A social-media prop.</li>
<li>A weapon against an ex-partner.</li>
<li>A source of confidential information.</li>
<li>The person responsible for deciding which parent is telling the truth.</li>
</ul>
<p>This is true whether you believe yourself to be the victim or the falsely accused parent.</p>
<p>Your child does not owe you evidence.</p>
<h2>What Weaponising a Child Can Look Like</h2>
<p>Possible warning behaviours can include:</p>
<ul>
<li>Repeatedly discussing litigation with the child.</li>
<li>Showing the child court documents.</li>
<li>Calling the other parent abusive or disordered in front of them.</li>
<li>Making affection conditional upon loyalty.</li>
<li>Encouraging rejection of extended family members.</li>
<li>Creating fear without a factual safeguarding basis.</li>
<li>Pressuring children to report on another household.</li>
<li>Involving children in financial disputes.</li>
<li>Making the child responsible for adult emotional wellbeing.</li>
</ul>
<p>But each allegation must still be established rather than presumed.</p>
<h2>DARVO and the Smearing of Mental Health</h2>
<p>Mental-health labels can become extraordinarily effective weapons in high-conflict disputes.</p>
<p>Someone may be described as:</p>
<ul>
<li>Crazy.</li>
<li>Unstable.</li>
<li>Narcissistic.</li>
<li>Borderline.</li>
<li>Psychotic.</li>
<li>Obsessive.</li>
</ul>
<p>without clinical evidence supporting any diagnosis.</p>
<p>This can have a silencing effect.</p>
<p>Once somebody has been framed as irrational, every emotional response can be interpreted through that frame.</p>
<p>The obvious safeguard is simple:</p>
<p><strong>diagnostic claims require diagnostic evidence.</strong></p>
<h2>Why Smearing Someone as a Narcissist Can Itself Become a Problem</h2>
<p>This applies to victims too.</p>
<p>If your entire case becomes:</p>
<p><strong>&ldquo;My ex is a narcissist&rdquo;</strong></p>
<p>you risk obscuring the evidence that actually matters.</p>
<p>Replace diagnosis with behaviour.</p>
<p>Instead of:</p>
<p><strong>&ldquo;My narcissistic ex is using DARVO.&rdquo;</strong></p>
<p>try:</p>
<p><strong>&ldquo;After I raised X, they denied X, circulated Y allegation about me and subsequently described themselves as the victim. These are the messages and dates.&rdquo;</strong></p>
<p>That is far stronger.</p>
<h2>The Evidence-First Response to DARVO</h2>
<p>If you believe you are experiencing DARVO, stop trying to win the personality argument.</p>
<p>Build the chronology.</p>
<p>Record:</p>
<ul>
<li>The original event.</li>
<li>The date.</li>
<li>What was said.</li>
<li>What evidence exists.</li>
<li>The confrontation.</li>
<li>The denial.</li>
<li>The subsequent attack.</li>
<li>The claimed reversal.</li>
<li>Any third-party evidence.</li>
<li>Any resulting practical action.</li>
</ul>
<p>Keep originals.</p>
<p>Preserve complete conversations rather than selectively cropped screenshots.</p>
<p>Do not manufacture confrontations simply to collect evidence.</p>
<h2>Do Not Respond to Smearing With More Smearing</h2>
<p>This is particularly important.</p>
<p>If you believe somebody is falsely attacking your reputation, launching a public campaign against them may simply produce two competing smear campaigns.</p>
<p>You may also create material that later harms your own credibility.</p>
<p>Instead:</p>
<ul>
<li>Correct important factual errors calmly where necessary.</li>
<li>Keep evidence.</li>
<li>Use appropriate legal or professional channels.</li>
<li>Do not recruit strangers online into the dispute.</li>
<li>Do not publicly diagnose the other person.</li>
<li>Do not involve children.</li>
</ul>
<h2>How to Respond During a DARVO Conversation</h2>
<p>You do not have to chase every accusation.</p>
<p>Return to the original issue.</p>
<p>For example:</p>
<p><strong>&ldquo;We can discuss that separately. Right now I am asking about the payment made on Tuesday.&rdquo;</strong></p>
<p>Or:</p>
<p><strong>&ldquo;Whether you believe I am too sensitive does not answer what I asked.&rdquo;</strong></p>
<p>Or:</p>
<p><strong>&ldquo;I am not going to argue about my personality. I am discussing this specific behaviour.&rdquo;</strong></p>
<p>When the conversation becomes abusive or unsafe, disengagement may be more appropriate than continuing to argue.</p>
<h2>The Broken-Record Technique</h2>
<p>Keep returning to the factual issue.</p>
<p><strong>&ldquo;The issue is X.&rdquo;</strong></p>
<p><strong>&ldquo;We are discussing X.&rdquo;</strong></p>
<p><strong>&ldquo;Your opinion of me does not answer X.&rdquo;</strong></p>
<p>This reduces the chance of being dragged through ten unrelated accusations.</p>
<h2>When Not to Confront</h2>
<p>Not every behaviour should be confronted directly.</p>
<p>If somebody is violent, threatening, stalking you or exercising serious coercive control, direct confrontation may increase risk.</p>
<p>Safety comes before psychological technique.</p>
<p>Use appropriate domestic-abuse, safeguarding, police or legal support where necessary.</p>
<h2>What Professionals Should Ask When DARVO May Be Present</h2>
<p>A useful professional assessment does not ask simply:</p>
<p><strong>&ldquo;Who seems like the victim?&rdquo;</strong></p>
<p>It asks:</p>
<ul>
<li>What is alleged?</li>
<li>What evidence supports it?</li>
<li>What is denied?</li>
<li>What is independently corroborated?</li>
<li>What occurred first?</li>
<li>Is there a pattern?</li>
<li>What is the wider context?</li>
<li>Is either person attempting to control the narrative through intimidation?</li>
<li>What has the child actually experienced?</li>
<li>Has the child's view been obtained independently?</li>
<li>Are domestic-abuse concerns present?</li>
<li>Are alienating behaviours present?</li>
<li>Could both be present?</li>
</ul>
<p>The final question matters.</p>
<p>Human relationships do not always give us one completely innocent adult and one completely harmful adult.</p>
<h2>DARVO Can Be Used by Men or Women</h2>
<p>DARVO should not be treated as gender-specific behaviour.</p>
<p>Research into abuse often examines populations in which gender patterns matter, and domestic abuse itself has important gendered dimensions.</p>
<p>But a behavioural concept should not be turned into:</p>
<p><strong>&ldquo;Men always DARVO&rdquo;</strong></p>
<p>or:</p>
<p><strong>&ldquo;Women weaponise victimhood.&rdquo;</strong></p>
<p>Either claim replaces evidence with ideology.</p>
<p>Assess the individual behaviour.</p>
<h2>Can Both People Use DARVO-Like Behaviour?</h2>
<p>Potentially, yes.</p>
<p>Highly conflictual relationships can contain:</p>
<ul>
<li>Mutual accusations.</li>
<li>Competing victim narratives.</li>
<li>Blame shifting.</li>
<li>Retaliation.</li>
<li>Poor emotional regulation.</li>
</ul>
<p>This does not mean every abusive relationship is &ldquo;mutual abuse&rdquo;.</p>
<p>Power, control, fear, severity and patterns remain important.</p>
<p>But psychological analysis should not decide the answer before examining the evidence.</p>
<h2>The 15 Signs a Conversation May Be Following a DARVO Pattern</h2>
<ul>
<li>The original allegation is immediately denied without engagement.</li>
<li>The discussion rapidly moves onto your character.</li>
<li>Your mental health becomes the subject.</li>
<li>Your motive is attacked instead of the evidence.</li>
<li>Your emotional reaction is presented as proof against you.</li>
<li>Unrelated historical mistakes are introduced.</li>
<li>The accused person begins describing themselves as your victim.</li>
<li>Third parties are recruited into the reversed narrative.</li>
<li>The original issue repeatedly disappears.</li>
<li>You find yourself answering accusations rather than asking questions.</li>
<li>Your attempt to establish a boundary is portrayed as abuse.</li>
<li>Documentation is ignored while your personality is debated.</li>
<li>You begin apologising for confronting the behaviour.</li>
<li>The other person demands sympathy because you challenged them.</li>
<li>Afterwards, you are confused about how the entire conversation became about you.</li>
</ul>
<p>None of these individually proves DARVO.</p>
<p>Look for the sequence and pattern.</p>
<h2>The Five Questions That Cut Through Role Reversal</h2>
<p>When narratives become confusing, come back to five questions:</p>
<ul>
<li><strong>What specifically happened?</strong></li>
<li><strong>What is the evidence?</strong></li>
<li><strong>What happened immediately afterwards?</strong></li>
<li><strong>What is allegation and what is established fact?</strong></li>
<li><strong>What issue are we actually trying to resolve?</strong></li>
</ul>
<p>Those questions can cut through an extraordinary amount of psychological noise.</p>
<h2>Why Understanding DARVO Matters</h2>
<p>DARVO matters because accountability matters.</p>
<p>When a credible allegation is met with character assassination and role reversal, the original issue can become buried.</p>
<p>Research suggests that DARVO can influence perceptions.</p>
<p>It can be associated with increased self-blame in victims.</p>
<p>It can alter how observers judge credibility.</p>
<p>In high-stakes environments, that can matter enormously.</p>
<p>But understanding DARVO also requires resisting misuse of the concept itself.</p>
<p>You cannot call every denial DARVO.</p>
<p>You cannot label an accused person's defence DARVO and then use the label as proof of guilt.</p>
<p>You cannot diagnose an ex-partner from the pattern.</p>
<p>And you cannot responsibly decide a child's best interests simply by deciding which parent uses the most convincing psychological vocabulary.</p>
<h2>The Grey Method: Hold the Pattern and the Evidence Together</h2>
<p>The Grey is particularly valuable here.</p>
<p>It allows two truths to coexist:</p>
<p><strong>People really can deny wrongdoing, attack victims and reverse roles.</strong></p>
<p>And:</p>
<p><strong>People can also be falsely accused and legitimately defend themselves.</strong></p>
<p>You do not need to erase one truth to acknowledge the other.</p>
<p>The solution is evidence.</p>
<p>Not online diagnosis.</p>
<p>Not gender stereotypes.</p>
<p>Not viral terminology.</p>
<p>Evidence.</p>
<p>Chronology.</p>
<p>Context.</p>
<p>Patterns.</p>
<p>Corroboration.</p>
<p>And, above all, the willingness to change your conclusion if the evidence requires it.</p>
<h2>Final Thought: When the Story Turns Upside Down, Return to the Facts</h2>
<p>The most disorientating part of DARVO is not simply being denied.</p>
<p>It is watching the roles change.</p>
<p>You raise the harm.</p>
<p>You become the problem.</p>
<p>You ask for accountability.</p>
<p>You are accused of abuse.</p>
<p>You set a boundary.</p>
<p>The boundary becomes evidence against you.</p>
<p>When that happens repeatedly, it can leave a person confused, ashamed and desperate to prove that they are not the monster they have been portrayed as.</p>
<p>Stop fighting every label.</p>
<p>Return to what can be established.</p>
<p><strong>What happened?</strong></p>
<p><strong>When did it happen?</strong></p>
<p><strong>What evidence exists?</strong></p>
<p><strong>What happened next?</strong></p>
<p><strong>Did the response address the behaviour, or did it simply move the accusation onto somebody else?</strong></p>
<ul>
<li>Children deserve the same discipline.</li>
<li>They should never become weapons, witnesses recruited by a parent, emotional caretakers or prizes in an adult war.</li>
<li>Domestic abuse should be taken seriously.</li>
<li>Alienating behaviours should be taken seriously.</li>
<li>False allegations should be taken seriously.</li>
<li>Coercive control should be taken seriously.</li>
<li>And none should automatically be presumed simply because somebody knows the correct psychological language.</li>
</ul>
<p><strong>DARVO is powerful because it changes the story.</strong></p>
<p><strong>The antidote is to keep returning to the evidence.</strong></p>
<h2>Research and Official Sources</h2>
<ul>
<li><a href="https://www.jjfreyd.com/darvo" target="_blank" rel="noopener">Jennifer Freyd &ndash; DARVO: Deny, Attack, Reverse Victim and Offender</a></li>
<li><a href="https://pubmed.ncbi.nlm.nih.gov/37154429/" target="_blank" rel="noopener">Harsey &amp; Freyd &ndash; The Influence of DARVO on Perceptions of Victims and Perpetrators</a></li>
<li><a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC11616802/" target="_blank" rel="noopener">Harsey, Adams-Clark &amp; Freyd &ndash; Defensive Victim-Blaming Responses and DARVO</a></li>
<li><a href="https://www.cafcass.gov.uk/parent-carer-or-family-member/applications-child-arrangements-order/how-your-family-court-adviser-makes-their-assessment-your-childs-welfare-and-best-interests/alienating-behaviours" target="_blank" rel="noopener">Cafcass &ndash; Alienating Behaviours</a></li>
<li><a href="https://www.cafcass.gov.uk/professionals/our-resources-professionals/child-impact-assessment-framework-ciaf/indicators-domestic-abuse-such-coercive-control" target="_blank" rel="noopener">Cafcass &ndash; Indicators of Domestic Abuse and Coercive Control</a></li>
<li><a href="https://assets.publishing.service.gov.uk/media/5ef3dcade90e075c4e144bfd/assessing-risk-harm-children-parents-pl-childrens-cases-report_.pdf" target="_blank" rel="noopener">Ministry of Justice &ndash; Assessing Risk of Harm to Children and Parents in Private Law Children Cases</a></li>
<li><a href="https://www.legislation.gov.uk/asp/2018/5/contents" target="_blank" rel="noopener">Domestic Abuse (Scotland) Act 2018</a></li>
<li><a href="https://www.scotcourts.gov.uk/media/y42ppwpa/2025csoh72-jn-against-sn.pdf" target="_blank" rel="noopener">Scottish Courts and Tribunals Service &ndash; Published Family Judgment Considering Evidence and Allegations of Abuse</a></li>
</ul>
<p><em>This article provides psychological and general legal information, not a diagnosis or individual legal advice. DARVO is a behavioural concept and cannot establish whether a disputed allegation is true. Family-law cases are fact-specific. Where domestic abuse, child safeguarding, criminal allegations or court orders are involved, obtain advice from appropriately qualified professionals. If you or a child is in immediate danger, contact emergency services or the relevant safeguarding authority.</em></p>

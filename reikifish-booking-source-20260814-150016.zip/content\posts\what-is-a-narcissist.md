---
title: "What Is a Narcissist? The Evidence-Led Guide to Narcissism, Traits and NPD"
seoTitle: "What Is a Narcissist? Signs, Traits & NPD Explained"
metaDescription: "What is a narcissist? Discover evidence-led signs, traits, causes, NPD, covert and grandiose narcissism, empathy, relationships and treatment."
slug: "what-is-a-narcissist"
categories: "Psychology"
tags: "['Narcissism', 'Narcissist', 'Narcissistic Personality Disorder', 'NPD', 'Psychology', 'Narcissistic Traits', 'Covert Narcissism', 'Vulnerable Narcissism', 'Grandiose Narcissism', 'Empathy']"
author: "Reiki Fish"
featured: false
draft: false
date: "2026-08-08"
excerpt: ""
featuredImage: "assets/images/blog/What_Is_a_Narcissist.png"
featuredImageAlt: "Narcissism and NPD illustrated through contrasting grandiose and vulnerable self-image"
---

<p>The word <strong>narcissist</strong> is everywhere. It is used for selfish partners, difficult exes, arrogant bosses, attention-seeking influencers, controlling parents and almost anyone who behaves badly in a relationship. Psychology, however, is considerably more complicated, and using the term accurately matters if we want it to explain anything useful.</p>
<p>A person can be selfish without having Narcissistic Personality Disorder. Someone can lie, cheat, manipulate or abuse without having NPD. A person can show narcissistic traits without meeting the threshold for any personality disorder. Equally, clinically significant narcissism is not simply &ldquo;loving yourself too much&rdquo;. It can involve an unstable system of self-esteem, entitlement, antagonism, a strong need for recognition, impaired mutuality in relationships, and difficulties responding to other people's needs and perspectives.</p>
<p>That distinction matters. When every unpleasant person becomes a &ldquo;narcissist&rdquo;, the word stops helping us understand behaviour. It can also stigmatise people with a mental-health condition and give abusive people an accidental excuse: abuse is a behaviour for which a person remains responsible, not a diagnosis that somebody on the internet can make for them.</p>
<p>This guide therefore takes a different approach. It separates <strong>ordinary narcissistic traits</strong>, <strong>pathological narcissism</strong>, and <strong>Narcissistic Personality Disorder (NPD)</strong>; examines what researchers mean by grandiose and vulnerable narcissism; looks at empathy, shame, criticism, aggression, relationships, manipulation and abuse; and explains what the evidence does &mdash; and does not &mdash; allow us to conclude.</p>
<blockquote>
<p><strong>The short answer:</strong> In everyday speech, &ldquo;narcissist&rdquo; usually means someone who shows a persistent pattern of excessive self-focus, entitlement, need for admiration and reduced concern for other people's needs. Clinically, however, <strong>Narcissistic Personality Disorder is a specific diagnosis</strong> involving enduring and impairing patterns of personality functioning. Narcissistic traits exist on a continuum, and only an appropriately qualified clinician can diagnose a personality disorder.</p>
</blockquote>
<h2 id="narcissism-is-a-trait-before-it-is-a-diagnosis">Narcissism is a trait before it is a diagnosis</h2>
<p>One of the most important facts about narcissism is also one of the most frequently missed online: <strong>narcissism is not all-or-nothing</strong>. Personality traits vary across the population. Most of us sometimes want admiration, feel defensive when criticised, compare ourselves with others, enjoy recognition or temporarily put our own needs first. Those experiences alone do not constitute a disorder. The clinically important questions are about <strong>degree, rigidity, persistence, context and impairment</strong>.</p>
<p>Ask:</p>
<ul>
<li>Is this an occasional reaction or an enduring pattern?</li>
<li>Does it appear across different situations and relationships?</li>
<li>Can the person reflect, repair and change their behaviour?</li>
<li>Does the pattern repeatedly damage relationships, work or wellbeing?</li>
<li>Is there persistent entitlement, exploitation, grandiosity or impaired empathy rather than a single selfish act?</li>
<li>Could another explanation fit the behaviour better?</li>
</ul>
<p>This is why a checklist found on social media cannot diagnose NPD. Diagnosis requires much more than recognising several familiar behaviours.</p>
<h2 id="what-is-narcissistic-personality-disorder">What is Narcissistic Personality Disorder?</h2>
<p>The American Psychiatric Association describes NPD as a pervasive pattern involving grandiosity, a need for admiration and lack of empathy, beginning by early adulthood and appearing across contexts. In the DSM-5-TR framework, diagnosis is based on a defined set of clinical criteria and requires enough of those criteria to be present as part of an enduring personality pattern.</p>
<p>The familiar diagnostic features concern:</p>
<ol type="1">
<li>exaggerated self-importance;</li>
<li>preoccupation with fantasies of exceptional success, power, brilliance, beauty or ideal love;</li>
<li>a belief that one is unusually special or should associate with similarly high-status people or institutions;</li>
<li>a need for excessive admiration;</li>
<li>entitlement or unreasonable expectations of favourable treatment;</li>
<li>interpersonal exploitation;</li>
<li>impaired or reduced empathy for other people's feelings and needs;</li>
<li>envy, or a belief that others envy them; and</li>
<li>arrogant or haughty behaviour and attitudes.</li>
</ol>
<p>This list is useful, but it needs context. Clinical assessment does not consist of ticking boxes beside an ex-partner's behaviour. Clinicians consider the person's wider history, personality functioning, distress and impairment, alternative explanations, other mental-health conditions, substance use, culture, developmental factors and the reliability of the available information.</p>
<p>The diagnosis is also not synonymous with &ldquo;bad person&rdquo;. A psychiatric formulation describes a pattern of functioning; it does not deliver a moral verdict.</p>
<h2>What the nine narcissistic features can look like in real life</h2>
<p>A diagnostic list becomes misleading if it is read without context, so it helps to unpack the ideas behind it. None of the examples below is enough to identify NPD on its own. What matters clinically is a broad, persistent and impairing configuration of personality functioning rather than a collection of isolated moments that happen to resemble a checklist.</p>
<h3>1. Exaggerated self-importance</h3>
<p>Grandiosity can involve overstating ability, importance, knowledge, achievements or influence and expecting other people to accept that elevated self-image. It is different from simply being proud of something genuinely achieved. The more informative question is whether the person's sense of importance repeatedly exceeds the evidence and whether relationships become organised around maintaining that position.</p>
<h3>2. Fantasies of exceptional success, power or ideal status</h3>
<p>Many psychologically healthy people dream about success. In narcissistic pathology, fantasies of unlimited success, brilliance, attractiveness, influence or ideal love can become unusually central to identity and self-worth. The issue is not ambition itself but the degree to which exceptionalism becomes necessary, reality is discounted, or other people are valued primarily for the status and validation they provide.</p>
<h3>3. A belief in being uniquely special</h3>
<p>A person may believe that only unusually accomplished, prestigious or special people can properly understand them, or that ordinary rules and ordinary social expectations do not quite apply. This can show up through status-based relationships, name-dropping, contempt for people perceived as unimportant, or a repeated need to establish membership of an imagined superior group. Once again, enjoying accomplished company is not a disorder; the wider pattern of superiority and functioning is what matters.</p>
<h3>4. An excessive need for admiration</h3>
<p>Most people enjoy appreciation, but an excessive need for admiration can make external recognition unusually important for regulating self-esteem. Attention, praise, status or reassurance may be repeatedly sought, and their absence may produce resentment, insecurity or attempts to recover the lost validation. This helps explain why outward confidence and inward dependency on other people's reactions are not necessarily opposites.</p>
<h3>5. Entitlement</h3>
<p>Entitlement means more than wanting something. It involves an expectation of favourable treatment, special exceptions, priority or compliance that is not matched by a comparable recognition of other people's rights and needs. In everyday relationships this can become particularly visible when someone hears &ldquo;no&rdquo;: a reasonable limit may be experienced not merely as disappointing, but as an unjust personal offence.</p>
<h3>6. Interpersonal exploitation</h3>
<p>Exploitation occurs when other people are used primarily as instruments for one's own goals, status, comfort or self-esteem, with insufficient concern for their cost. Relationships are naturally interdependent and everybody sometimes needs help, so receiving support is not exploitation. The concern is a repeated lack of reciprocity in which another person's value becomes conditional on what they provide.</p>
<h3>7. Impaired empathy</h3>
<p>Empathic difficulty can involve failing to recognise, tolerate or respond appropriately to another person's feelings and needs, particularly when doing so competes with self-interest or threatens the person's preferred self-image. Research makes this more nuanced than the internet slogan that narcissists &ldquo;have no empathy&rdquo;. Perspective-taking, emotional resonance and motivation to engage with another person's experience can vary separately and by context.</p>
<h3>8. Envy and assumptions about other people's envy</h3>
<p>Status comparison can make another person's success feel threatening rather than simply admirable. Envy may then be managed by devaluing the successful person, dismissing the achievement or restoring a sense of superiority elsewhere. The reverse assumption &mdash; that other people criticise only because they are jealous &mdash; can also protect self-image by making criticism easier to reject without examining whether any part of it is accurate.</p>
<h3>9. Arrogant attitudes or behaviour</h3>
<p>Arrogance may appear as condescension, contempt, dismissiveness, boasting or treating others as intellectually, socially or morally inferior. A crucial distinction is persistence: anybody can be arrogant on a bad day. Personality pathology concerns a stable enough pattern to affect how the person repeatedly relates to other people and functions across important parts of life.</p>
<p>These nine areas should therefore be read as clinical features that require interpretation, not as nine tricks for catching a narcissist. A person may show several behaviours for completely different reasons, and a responsible assessment must also ask what is missing from the story, whether the pattern changes across contexts and whether another formulation explains the evidence better.</p>
<h2 id="narcissistic-traits-pathological-narcissism-and-npd-what-is-the-difference">Narcissistic traits, pathological narcissism and NPD: what is the difference?</h2>
<p>Narcissistic traits, pathological narcissism and Narcissistic Personality Disorder overlap, but they are not interchangeable. Keeping them separate prevents ordinary human flaws from being mistaken for a psychiatric disorder and prevents genuinely pathological patterns from being trivialised.</p>
<h3 id="narcissistic-traits">Narcissistic traits</h3>
<p>Traits are characteristics that can exist to different degrees in people with or without a disorder. Confidence, competitiveness and enjoying recognition are not automatically pathological. More problematic narcissistic traits include chronic entitlement, exploitation, superiority and persistent disregard for others.</p>
<h3 id="pathological-narcissism">Pathological narcissism</h3>
<p>Researchers often use <strong>pathological narcissism</strong> to describe maladaptive narcissistic functioning that may include both grandiose and vulnerable features. The concept can capture psychological difficulties that a simple stereotype of the boastful, attention-seeking narcissist misses.</p>
<h3 id="narcissistic-personality-disorder">Narcissistic Personality Disorder</h3>
<p>NPD is a clinical diagnosis. It requires a sufficiently pervasive and impairing pattern, assessed within a diagnostic framework. You cannot responsibly move from &ldquo;this person behaved narcissistically&rdquo; to &ldquo;this person has NPD&rdquo;.</p>
<p>That distinction is one of the central rules of evidence-led discussion about narcissism.</p>
<h2 id="the-core-of-narcissism-more-than-high-self-esteem">The core of narcissism: more than high self-esteem</h2>
<p>It is tempting to imagine narcissism as an enormous amount of self-confidence. Research suggests that is too simple.</p>
<p>Modern models increasingly distinguish components of narcissism rather than treating it as one uniform characteristic. One influential way of understanding it separates:</p>
<ul>
<li><strong>agentic grandiosity</strong> &mdash; assertiveness, self-promotion, status seeking and feelings of exceptional ability;</li>
<li><strong>antagonism</strong> &mdash; entitlement, exploitativeness, arrogance, low concern for others and interpersonal conflict; and</li>
<li><strong>narcissistic vulnerability or neuroticism</strong> &mdash; shame, hypersensitivity, insecurity, withdrawal and intense negative reactions to threats to self-esteem.</li>
</ul>
<p>The antagonistic component is particularly important because it helps explain why narcissism can become so damaging interpersonally. Confidence itself is not the problem. The problem is when self-enhancement is maintained through entitlement, devaluation, exploitation or disregard for other people.</p>
<h2 id="grandiose-narcissism">Grandiose narcissism</h2>
<p>Grandiose narcissistic presentation is closest to the popular stereotype. A highly grandiose person may appear:</p>
<ul>
<li>unusually self-assured;</li>
<li>dominant and competitive;</li>
<li>status-conscious;</li>
<li>boastful or self-promoting;</li>
<li>entitled to special treatment;</li>
<li>dismissive of criticism;</li>
<li>comfortable taking social space;</li>
<li>charming when admiration or status is available; and</li>
<li>exploitative or antagonistic when other people's needs conflict with their own.</li>
</ul>
<p>But even here, caution is needed. Charisma, ambition, confidence, leadership and extraversion are not evidence of NPD by themselves. A psychologically healthy confident person can tolerate other people's success, apologise, accept limits, care about mutuality and update their view when evidence proves them wrong.</p>
<h2 id="vulnerable-narcissism-what-people-often-call-a-covert-narcissist">Vulnerable narcissism: what people often call a &ldquo;covert narcissist&rdquo;</h2>
<p>The popular phrase <strong>covert narcissist</strong> is widely searched online, but it is not a separate formal DSM diagnosis. Research literature more often discusses <strong>vulnerable narcissism</strong>.</p>
<p>Vulnerable narcissistic features can include:</p>
<ul>
<li>hypersensitivity to criticism or rejection;</li>
<li>shame and insecurity;</li>
<li>social withdrawal;</li>
<li>resentment and envy;</li>
<li>defensive self-focus;</li>
<li>feelings of being misunderstood or insufficiently recognised;</li>
<li>oscillation between fantasies of specialness and feelings of inadequacy; and</li>
<li>hostility or anger when self-esteem is threatened.</li>
</ul>
<p>This matters because narcissism does not always look loud. Some narcissistic difficulties can be hidden behind inhibition, fragility or grievance.</p>
<p>However, <strong>being shy, insecure, traumatised, depressed, rejection-sensitive or socially anxious does not make somebody a vulnerable narcissist</strong>. Those experiences occur in many conditions and in people with no disorder at all.</p>
<h2 id="can-somebody-be-both-grandiose-and-vulnerable">Can somebody be both grandiose and vulnerable?</h2>
<p>Yes. Grandiosity and vulnerability should not always be imagined as two completely separate &ldquo;types of person&rdquo;. Research has found that narcissistic states can fluctuate within individuals.</p>
<p>A person might appear superior and self-certain while things are going well, then become intensely ashamed, angry, defensive or withdrawn after rejection or failure. The outward behaviour changes, but both states may relate to the regulation of self-esteem and status.</p>
<p>This is one reason simplistic online taxonomies &mdash; &ldquo;the seven narcissists&rdquo;, &ldquo;the ten narcissists&rdquo;, &ldquo;the somatic narcissist&rdquo;, &ldquo;the cerebral narcissist&rdquo; &mdash; should not automatically be treated as recognised clinical categories. Some labels are descriptive inventions, not validated diagnoses.</p>
<h2 id="is-there-such-a-thing-as-a-malignant-narcissist">Is there such a thing as a malignant narcissist?</h2>
<p><strong>Malignant narcissism</strong> is a historical and clinical concept, not a separate diagnosis in the DSM-5-TR. It has generally been used to describe a severe constellation involving narcissistic pathology alongside aggression, antisocial traits, paranoia or sadistic features.</p>
<p>The term should therefore not be used as if it were a precise diagnostic category that can be identified from a list of relationship behaviours. Where aggression, coercion or cruelty is occurring, the behaviour itself deserves attention regardless of which personality label might eventually apply.</p>
<h2 id="do-narcissists-have-empathy">Do narcissists have empathy?</h2>
<p>&ldquo;Narcissists have no empathy&rdquo; is one of the most repeated statements on the internet. It is also too absolute.</p>
<p>Empathy is not a single switch that is either on or off. Researchers commonly distinguish processes such as:</p>
<ul>
<li><strong>cognitive empathy or perspective-taking</strong> &mdash; recognising or understanding another person's mental state; and</li>
<li><strong>affective empathy</strong> &mdash; emotionally responding to another person's feelings.</li>
</ul>
<p>Clinical and research literature suggests that empathy in narcissistic pathology can be <strong>impaired, inconsistent, context-sensitive or motivationally influenced</strong>, rather than universally absent. A person may understand what somebody else is feeling but fail to respond with concern; empathic engagement may also vary according to self-esteem threat, emotional regulation and whether attending to the other person conflicts with self-focused goals.</p>
<p>That nuance has practical consequences. Apparent empathy in one situation does not prove that narcissistic pathology is absent, and an unempathic response does not prove that NPD is present.</p>
<p>It is better to observe a person's <strong>repeated capacity for mutuality</strong>: Can they take another perspective when there is nothing to gain? Can they stay concerned when the other person's needs frustrate them? Can they recognise harm without immediately recentring themselves? Can they repair after hurting someone?</p>
<h2 id="what-happens-when-a-narcissistic-person-is-criticised">What happens when a narcissistic person is criticised?</h2>
<p>Criticism, rejection, humiliation, status loss and failure can be particularly significant when a person's self-esteem depends heavily on being special, superior or admired.</p>
<p>Possible responses include:</p>
<ul>
<li>defensiveness;</li>
<li>dismissal of the critic;</li>
<li>blame shifting;</li>
<li>counterattack;</li>
<li>shame;</li>
<li>anger;</li>
<li>withdrawal;</li>
<li>attempts to restore status;</li>
<li>devaluing the person who delivered the criticism; or</li>
<li>seeking reassurance and admiration elsewhere.</li>
</ul>
<p>The popular expression <strong>&ldquo;narcissistic rage&rdquo;</strong> describes intense anger associated with narcissistic injury or threat. It is not itself a standalone diagnosis, nor does every angry response to criticism indicate narcissism.</p>
<p>There is, however, meaningful evidence linking narcissism with aggression. A 2021 meta-analytic review covering 437 independent studies and 123,043 participants found narcissism associated with aggression and violence, with the association stronger under provocation. Another preregistered meta-analysis found important differences between components: vulnerable narcissism was especially associated with reactive aggression, while antagonism was positively associated with multiple forms of aggression.</p>
<p>Those are <strong>group-level associations</strong>, not predictions that a particular individual will become violent. Risk assessment must never be reduced to a personality label.</p>
<h2 id="narcissism-shame-and-fragile-self-esteem">Narcissism, shame and fragile self-esteem</h2>
<p>The idea that every narcissistic person secretly hates themselves is another claim that is too sweeping. Grandiose narcissism can be associated with explicit self-confidence and positive self-views. Vulnerable narcissism, however, is more closely associated with negative affect, insecurity, shame and hypersensitivity.</p>
<p>A better formulation is that <strong>self-esteem regulation can be unusually dependent on status, recognition and interpersonal feedback</strong>, particularly in pathological narcissism. When that system is threatened, defensive strategies may become more visible.</p>
<p>For some people, superiority protects against shame. For others, shame and grievance sit much closer to the surface. Neither pattern can be inferred simply because somebody posts selfies or enjoys praise.</p>
<h2 id="what-does-a-narcissist-look-like-in-a-relationship">What does a narcissist look like in a relationship?</h2>
<p>There is no single narcissistic relationship script. Internet content often promises a universal sequence &mdash; love bombing, devaluation, discard, hoovering &mdash; as though every relationship involving narcissistic traits follows identical stages. Human relationships do not work so neatly.</p>
<p>Where narcissistic pathology is significant, recurring difficulties may instead centre on:</p>
<ul>
<li>expecting disproportionate attention or accommodation;</li>
<li>becoming resentful when a partner has independent needs;</li>
<li>difficulty sharing recognition or power;</li>
<li>using a partner to stabilise self-esteem or status;</li>
<li>limited reciprocity;</li>
<li>entitlement around time, sex, money, attention or loyalty;</li>
<li>devaluing a partner after disappointment;</li>
<li>intense defensiveness about responsibility;</li>
<li>envy or competitiveness within the relationship;</li>
<li>exploiting vulnerabilities for personal advantage; and</li>
<li>difficulty repairing ruptures because admitting fault threatens the person's self-image.</li>
</ul>
<p>These behaviours are not exclusive to NPD. The useful question is not &ldquo;Can I prove my partner is a narcissist?&rdquo; but <strong>&ldquo;What is repeatedly happening here, what effect is it having on me, and is the relationship safe and reciprocal?&rdquo;</strong></p>
<h2 id="love-bombing-idealisation-and-devaluation">Love bombing, idealisation and devaluation</h2>
<p><strong>Love bombing</strong> is a popular term for overwhelming attention, affection, communication, gifts or promises, particularly when this intensity functions to accelerate attachment or influence. The behaviour can occur in manipulative or abusive relationships, but early romantic intensity alone does not establish narcissism.</p>
<p><strong>Idealisation and devaluation</strong> are clinically more meaningful ideas. Someone may initially experience another person as exceptional, then sharply downgrade them when they disappoint expectations, assert independence or no longer provide the desired affirmation.</p>
<p>Again, the pattern matters more than the label. Look for loss of reciprocity, coercion, contempt, control, exploitation and repeated inability to tolerate the other person's separate identity.</p>
<h2 id="what-is-narcissistic-supply">What is &ldquo;narcissistic supply&rdquo;?</h2>
<p>The phrase <strong>narcissistic supply</strong> has a history in psychoanalytic thinking and is now common in popular psychology. Online, it often gets presented as if people with NPD literally &ldquo;feed&rdquo; on attention.</p>
<p>A less sensational description is more useful: some people with significant narcissistic pathology rely heavily on <strong>external affirmation, attention, status, admiration or reactions from others to regulate self-esteem</strong>.</p>
<p>People are not fuel tanks. Describing the psychological function precisely avoids turning a complex disorder into a monster story.</p>
<h2 id="do-narcissists-manipulate-people">Do narcissists manipulate people?</h2>
<p>Some narcissistic traits &mdash; particularly entitlement, exploitativeness and antagonism &mdash; can clearly contribute to manipulative interpersonal behaviour. But manipulation is not unique to narcissism and not everyone who manipulates has NPD.</p>
<p>Possible behaviours worth recognising on their own terms include:</p>
<ul>
<li>persistent blame shifting;</li>
<li>selective disclosure or deception;</li>
<li>guilt induction;</li>
<li>coercive pressure;</li>
<li>exploiting a known vulnerability;</li>
<li>social triangulation;</li>
<li>intimidation;</li>
<li>rewriting or denying events;</li>
<li>punishing boundaries;</li>
<li>threatening abandonment or reputational harm; and</li>
<li>recruiting other people into a conflict.</li>
</ul>
<p>If one of these is happening, you do not need a diagnosis before you are allowed to set a boundary.</p>
<h2 id="gaslighting-what-it-is-and-what-it-is-not">Gaslighting: what it is and what it is not</h2>
<p><strong>Gaslighting</strong> is another term weakened by overuse. It should not mean every disagreement, lie or mistaken recollection.</p>
<p>The concept is most useful for a pattern in which one person attempts to undermine another's trust in their own perception, memory or judgement. That can involve persistent denial of events, contradiction of clear evidence, reframing the other's reactions as proof of instability, or constructing an alternative version of reality that makes the target increasingly dependent on the manipulator's account.</p>
<p>Gaslighting can occur in abusive relationships without NPD. A person with NPD can also behave harmfully without gaslighting. Behaviour and diagnosis must remain separate questions.</p>
<h2 id="darvo-and-narcissism">DARVO and narcissism</h2>
<p><strong>DARVO</strong> stands for <strong>Deny, Attack, and Reverse Victim and Offender</strong>. Psychologist Jennifer Freyd and colleagues developed the concept to describe a defensive response in which a person accused of wrongdoing denies it, attacks the credibility of the accuser and reverses the roles so that the accused presents themselves as the victim.</p>
<p>DARVO is particularly relevant to conversations about high-conflict relationships because the behavioural sequence can leave the person raising a concern defending themselves instead of discussing the original conduct.</p>
<p>However, <strong>DARVO is not a diagnostic test for narcissism</strong>. People with different personalities can deny, attack or reverse blame. The value of the concept is behavioural: it helps identify what is happening in an interaction without pretending we know the person's diagnosis.</p>
<p>For a detailed explanation, see ReikiFish's guide: <a href="articles/what-is-darvo-denial-attack-reverse-victim-offender"><strong>What is DARVO? Denial, Attack, Reverse Victim and Offender</strong></a>. It explores the pattern in its own right rather than treating DARVO as proof of a particular personality disorder.</p>
<h2 id="are-all-narcissists-abusive">Are all narcissists abusive?</h2>
<p>No. This needs saying clearly: NPD is a mental-health diagnosis; <strong>abuse is behaviour</strong>. They overlap in some people, but they are not synonyms. Treating everybody with NPD as an abuser is inaccurate and stigmatising. Treating every abuser as somebody with NPD is equally unsupported.</p>
<p>At the same time, a diagnosis must never be used to minimise harmful behaviour. Coercive control, threats, stalking, physical violence, sexual violence, financial abuse and emotional abuse matter regardless of the perpetrator's diagnosis.</p>
<p>If behaviour is abusive, focus first on safety, evidence, boundaries and appropriate professional support &mdash; not on winning an argument about the correct personality label.</p>
<h2 id="are-narcissists-always-deliberately-calculating">Are narcissists always deliberately calculating?</h2>
<p>Not necessarily. Some harmful behaviour is strategic, while some is habitual, defensive, impulsive or partly outside reflective awareness. A person can also understand that a behaviour produces a desired result without having planned every step in advance. Psychology rarely supports the claim that we can infer a detailed hidden strategy simply from the fact that an interaction was harmful.</p>
<p>Intent and impact are separate. &ldquo;They did not consciously plan it&rdquo; does not make harmful behaviour harmless. Conversely, assuming a hidden master plan behind every unpleasant interaction can lead us beyond the evidence.</p>
<p>Where possible, describe what you can actually observe: <strong>what happened, how often, what changed when a boundary was set, and what the consequences were</strong>.</p>
<h2 id="can-a-narcissist-love">Can a narcissist love?</h2>
<p>The question is understandable but badly suited to a yes-or-no answer. &ldquo;Love&rdquo; is not a single clinical variable, and people with the same diagnosis differ enormously.</p>
<p>Narcissistic pathology can impair <strong>mutuality, empathy, intimacy and the capacity to tolerate a partner as a separate person with independent needs</strong>. That can make relationships painful and unstable. It does not scientifically follow that every person with narcissistic pathology is incapable of affection, attachment or love.</p>
<p>A more useful question is: <strong>Can this particular person participate in a relationship that is safe, reciprocal, respectful and capable of repair?</strong></p>
<p>That can be answered from behaviour far more reliably than from speculation about an internal feeling.</p>
<h2 id="can-a-narcissist-apologise">Can a narcissist apologise?</h2>
<p>Of course a person with narcissistic traits can say sorry. The more informative issue is the quality of the repair.</p>
<p>A meaningful apology usually involves:</p>
<ul>
<li>accurately acknowledging the behaviour;</li>
<li>recognising its effect on the other person;</li>
<li>taking responsibility without immediately transferring blame;</li>
<li>tolerating the other person's feelings;</li>
<li>making appropriate amends; and</li>
<li>changing the relevant behaviour over time.</li>
</ul>
<p>An apology followed by the same repeated conduct is information. So is an apology that exists only to end consequences or restore access to the other person. But neither automatically diagnoses NPD.</p>
<h2 id="can-a-narcissist-change">Can a narcissist change?</h2>
<p>&ldquo;Narcissists never change&rdquo; is too absolute. Personality disorders can be difficult to treat, and change may require sustained motivation, self-observation and a therapeutic relationship capable of surviving shame, defensiveness and interpersonal ruptures. But difficult is not the same as impossible, and prognosis cannot responsibly be decided from an internet label.</p>
<p>Psychotherapy is the principal approach used for NPD. Treatment may focus on improving emotional and interpersonal functioning, understanding self-esteem regulation, increasing reflective capacity and empathy, tolerating vulnerability, reducing destructive defences and developing more reciprocal relationships. Evidence specifically for NPD remains less extensive than the treatment literature for some other disorders, so sweeping claims about one guaranteed therapy should be treated cautiously.</p>
<p>Medication does not specifically &ldquo;cure narcissism&rdquo;, although clinicians may prescribe medication for co-occurring conditions such as depression or anxiety when appropriate.</p>
<p>Most importantly for relatives and partners: <strong>another person's theoretical capacity to change does not oblige you to remain in a harmful situation while waiting for that change</strong>.</p>
<h2 id="what-causes-narcissism">What causes narcissism?</h2>
<p>There is no single proven cause of narcissism or NPD. The most defensible view is developmental and multifactorial: personality emerges from interactions between temperament, inherited tendencies, relationships, learning, culture and life experience. Research has explored genetic influences, parenting, childhood maltreatment and neglect, parental overvaluation, attachment processes, social learning and neurobiological correlates.</p>
<p>None supports a simple formula such as:</p>
<blockquote>
<p>&ldquo;A narcissist was definitely abused as a child.&rdquo;</p>
</blockquote>
<p>or:</p>
<blockquote>
<p>&ldquo;Parents create narcissists by praising children too much.&rdquo;</p>
</blockquote>
<p>Adverse childhood experiences have been associated with later narcissistic features in research, with vulnerable narcissism often showing stronger links to adversity than grandiose narcissism. Association, however, is not destiny. Most people who experience childhood adversity do not develop NPD, and a person's childhood cannot be reconstructed from their adult behaviour alone.</p>
<h2 id="does-trauma-cause-narcissism">Does trauma cause narcissism?</h2>
<p>Trauma may be one developmental factor for some people, but <strong>trauma and narcissism are not interchangeable</strong>.</p>
<p>Trauma can contribute to hypervigilance, emotional numbing, avoidance, irritability, shame, distrust, dissociation and difficulties in relationships. From the outside, some of these can be misread as self-absorption or lack of empathy. Conversely, a trauma history does not exclude narcissistic pathology.</p>
<p>Proper assessment asks what psychological process best explains the pattern rather than forcing every difficult behaviour into a favourite label.</p>
<h2 id="is-narcissism-genetic">Is narcissism genetic?</h2>
<p>Personality traits generally show both genetic and environmental influences, and research suggests narcissistic traits are no exception. Heritability does <strong>not</strong> mean that a fixed percentage of one person's narcissism was &ldquo;caused by genes&rdquo;, and it does not mean the outcome is predetermined.</p>
<p>Heritability is a population statistic describing variation under particular environmental conditions. Genes and environments interact throughout development.</p>
<h2 id="is-narcissism-caused-by-the-brain">Is narcissism caused by the brain?</h2>
<p>Neuroscience studies have reported structural and functional differences associated with narcissistic traits and NPD, including research involving brain systems relevant to self-processing, reward and empathy. A systematic review of the neuroscience literature also highlights substantial limitations: small samples, different definitions and measures, and the difficulty of translating group-level associations into individual diagnosis.</p>
<p>There is currently no brain scan that can tell you whether your partner, parent or colleague is a narcissist.</p>
<h2 id="are-narcissists-born-or-made">Are narcissists born or made?</h2>
<p>The scientifically sensible answer is <strong>neither in isolation</strong>. Human personality develops through biology and environment interacting over time, which means a simple &ldquo;born versus made&rdquo; argument is an appealing debate question but a poor model of modern developmental psychology.</p>
<h2 id="are-men-more-narcissistic-than-women">Are men more narcissistic than women?</h2>
<p>Narcissism occurs in both men and women. A large meta-analysis involving hundreds of studies found men scored somewhat higher overall on narcissism measures, particularly on entitlement/exploitativeness and leadership/authority dimensions. The authors explicitly cautioned against turning average group differences into stereotypes. The same review found essentially no male-female difference in vulnerable narcissism.</p>
<p>This is important in real life. You cannot infer narcissism from sex or gender, and quieter vulnerable presentations may be missed if people expect every narcissistic person to match a loud male stereotype.</p>
<h2 id="is-everyone-becoming-more-narcissistic-because-of-social-media">Is everyone becoming more narcissistic because of social media?</h2>
<p>Social media provides obvious rewards for attention, self-presentation and status comparison, but the statement &ldquo;social media is making everyone narcissistic&rdquo; goes beyond what can responsibly be concluded.</p>
<p>People select platforms as well as being influenced by them; studies use different definitions of narcissism; and a behaviour that is normal within an online setting &mdash; such as posting a photograph &mdash; is not equivalent to pathological narcissism.</p>
<p>For that reason, frequency of selfies is not a diagnostic instrument. Online self-presentation can be one small piece of behaviour, but it cannot establish the pervasive personality functioning required for a clinical diagnosis.</p>
<h2 id="narcissism-versus-healthy-confidence">Narcissism versus healthy confidence</h2>
<p>Healthy self-confidence and narcissistic grandiosity can look similar at a distance. Up close, their interpersonal consequences are often different.</p>
<table>
<thead>
<tr class="header">
<th>Healthy confidence</th>
<th>Problematic narcissistic pattern</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>Can recognise strengths without needing to be superior</td>
<td>Self-worth may depend on exceptional status or superiority</td>
</tr>
<tr class="even">
<td>Can celebrate another person's success</td>
<td>May experience another's success as rivalry or threat</td>
</tr>
<tr class="odd">
<td>Can accept useful criticism</td>
<td>May react to criticism with intense defence, contempt or counterattack</td>
</tr>
<tr class="even">
<td>Respects reasonable limits</td>
<td>May experience limits as an insult or unfair deprivation</td>
</tr>
<tr class="odd">
<td>Can apologise and repair</td>
<td>Responsibility may repeatedly be externalised</td>
</tr>
<tr class="even">
<td>Values reciprocity</td>
<td>Relationships may become organised around the person's needs or status</td>
</tr>
<tr class="odd">
<td>Empathy survives disagreement</td>
<td>Concern for the other may collapse when self-interest is threatened</td>
</tr>
</tbody>
</table>
<p>This table is illustrative, not diagnostic. Everybody can fall into the right-hand column occasionally.</p>
<h2 id="narcissism-versus-selfishness">Narcissism versus selfishness</h2>
<p>Selfish behaviour is universal. Narcissistic pathology is broader: it concerns an enduring configuration of self, status, entitlement, empathy and relationships.</p>
<p>Someone taking the last biscuit is selfish. It tells you almost nothing about whether they have a personality disorder.</p>
<h2 id="narcissism-versus-psychopathy-and-antisocial-personality-disorder">Narcissism versus psychopathy and Antisocial Personality Disorder</h2>
<p>Narcissism, psychopathy and Antisocial Personality Disorder overlap in some features but are not synonymous.</p>
<p>Narcissistic pathology centrally concerns issues such as grandiosity, self-esteem regulation, admiration, entitlement and empathy. ASPD involves a pervasive pattern of disregard for and violation of the rights of others within its diagnostic framework. Psychopathy is a related research and forensic construct involving a constellation of interpersonal, affective and behavioural features; it is not simply &ldquo;very severe narcissism&rdquo;.</p>
<p>An individual may show overlapping traits, but one label cannot be substituted for another.</p>
<h2 id="narcissism-versus-borderline-personality-disorder">Narcissism versus Borderline Personality Disorder</h2>
<p>NPD and Borderline Personality Disorder can share features such as unstable relationships, sensitivity to rejection, anger, shame and fluctuating self-experience. Their characteristic patterns are nevertheless different, and comorbidity can occur.</p>
<p>This overlap is another reason why diagnosing a person from selected relationship anecdotes is unreliable. Clinicians assess the whole pattern, not the most memorable argument.</p>
<h2 id="narcissism-versus-autism">Narcissism versus autism</h2>
<p>Autistic social-communication differences must not be casually labelled as narcissism or lack of empathy. An autistic person may miss an implied social cue, become overwhelmed, communicate directly, need predictability or struggle to infer what somebody expects without possessing narcissistic entitlement or grandiosity.</p>
<p>Likewise, somebody with narcissistic pathology should not be casually labelled autistic to explain harmful behaviour. The developmental histories and clinical constructs are different.</p>
<h2 id="narcissism-versus-adhd">Narcissism versus ADHD</h2>
<p>ADHD can involve interrupting, forgetfulness, inconsistent attention, impulsivity and emotional dysregulation. To a hurt partner, those behaviours may sometimes feel inconsiderate. They do not by themselves indicate narcissistic entitlement or exploitation.</p>
<p>Intent is not the only thing that matters in relationships, but accurate explanation still matters clinically.</p>
<h2 id="narcissism-versus-confidence-mania-and-other-states">Narcissism versus confidence, mania and other states</h2>
<p>Grandiosity can also occur during manic or hypomanic episodes. Substance effects, neurological conditions and other psychiatric presentations can alter judgement, confidence, empathy or behaviour.</p>
<p>A defining reason clinicians take history is to distinguish an enduring personality pattern from a change associated with an episode, illness or substance.</p>
<h2 id="what-is-the-narcissistic-stare-smirk-or-eyes">What is the &ldquo;narcissistic stare&rdquo;, smirk or eyes?</h2>
<p>There is <strong>no validated facial expression, stare, eye shape or smirk that diagnoses narcissism</strong>.</p>
<p>Online claims that one can identify NPD from &ldquo;dead eyes&rdquo;, eyebrows, a particular smile, photographs or five minutes of body language should be treated with considerable scepticism. Clinical diagnosis is based on a broad and persistent pattern of functioning, not physiognomy.</p>
<h2 id="can-you-spot-a-narcissist-on-a-first-date">Can you spot a narcissist on a first date?</h2>
<p>Not reliably. Some people high in grandiose traits can make strong first impressions because confidence, social boldness and self-presentation may initially be attractive. But a first date provides very little evidence about an enduring personality pattern, and treating charm or confidence as proof of pathology creates far more false positives than useful insight.</p>
<p>Over time, pay greater attention to:</p>
<ul>
<li>how the person handles &ldquo;no&rdquo;;</li>
<li>whether curiosity about you is genuine and sustained;</li>
<li>how they speak about people who cannot benefit them;</li>
<li>whether rules apply equally to them;</li>
<li>what happens when you disagree;</li>
<li>whether apologies lead to change;</li>
<li>whether your independence is respected; and</li>
<li>whether the relationship remains reciprocal after the initial impression stage.</li>
</ul>
<p>Those observations help evaluate relationship health even when no diagnosis is known.</p>
<h2 id="the-nine-signs-of-npd-are-not-a-diy-test">The nine signs of NPD are not a DIY test</h2>
<p>Readers often arrive at pages like this because they want certainty about someone they know. It is understandable. Repeated manipulation or confusing behaviour creates a strong desire for an explanation.</p>
<p>But confirmation bias can easily enter the process. Once you decide &ldquo;this person is a narcissist&rdquo;, almost anything can be made to fit: confidence becomes grandiosity, insecurity becomes covert narcissism, anger becomes narcissistic rage, silence becomes manipulation, affection becomes love bombing, apology becomes hoovering and disagreement becomes gaslighting.</p>
<p>A theory that explains <strong>every possible behaviour</strong> risks explaining nothing.</p>
<p>Use psychological concepts to sharpen observation, not to eliminate uncertainty.</p>
<h2 id="how-is-narcissistic-personality-disorder-diagnosed">How is Narcissistic Personality Disorder diagnosed?</h2>
<p>Diagnosis is undertaken by an appropriately qualified mental-health professional using clinical assessment. Depending on the setting, this can involve interviews, structured or semi-structured diagnostic tools, collateral information where appropriate and evaluation of personality functioning over time.</p>
<p>The clinician considers:</p>
<ul>
<li>the pattern across the person's life and relationships;</li>
<li>its stability and duration;</li>
<li>functional impairment;</li>
<li>internal experiences as well as observable behaviour;</li>
<li>alternative diagnoses;</li>
<li>co-occurring conditions;</li>
<li>substance use and medical factors;</li>
<li>culture and context; and</li>
<li>whether information is reliable and sufficiently comprehensive.</li>
</ul>
<p>No responsible clinician diagnoses an absent third party solely from their former partner's account, and no website &mdash; including this one &mdash; can replace an individual clinical assessment.</p>
<h2 id="why-might-npd-be-missed">Why might NPD be missed?</h2>
<p>People do not necessarily seek therapy saying, &ldquo;I think I have NPD.&rdquo; They may present because of depression, relationship breakdown, work problems, anxiety, anger, shame, substance use, a crisis following failure or rejection, or another condition entirely.</p>
<p>Vulnerable features may also be less obvious than overt grandiosity. Conversely, clinicians must avoid overdiagnosis when a person is temporarily defensive or distressed.</p>
<h2 id="does-a-narcissist-know-they-are-a-narcissist">Does a narcissist know they are a narcissist?</h2>
<p>Self-awareness varies. Some people recognise that they are status-driven, entitled, exploitative or unusually dependent on admiration. Others recognise the consequences but explain them as everybody else's fault. Some have considerable psychological insight; some do not. Insight can also increase in treatment, so no single assumption about awareness applies to everyone with narcissistic pathology.</p>
<p>The diagnosis does not come with a universal lack-of-awareness switch.</p>
<h2 id="what-should-i-do-if-i-think-someone-is-a-narcissist">What should I do if I think someone is a narcissist?</h2>
<p>Start by dropping the requirement to prove the label. Instead, document and respond to <strong>behaviour</strong>. That produces clearer decisions, cleaner communication and more useful information if you later need help from a therapist, solicitor, safeguarding professional or domestic-abuse service.</p>
<h3 id="1-identify-the-pattern-precisely">1. Identify the pattern precisely</h3>
<p>Replace &ldquo;They are narcissistic&rdquo; with specific observations: &ldquo;They repeatedly insult me after I say no&rdquo;, &ldquo;They control access to money&rdquo;, &ldquo;They deny messages that are still visible&rdquo;, or &ldquo;They threaten to ruin my reputation when I set a boundary&rdquo;.</p>
<p>Specific observations are more useful for therapy, legal advice, safeguarding and your own decision-making.</p>
<h3 id="2-decide-your-boundary-in-advance">2. Decide your boundary in advance</h3>
<p>A boundary describes what <strong>you</strong> will do, not a magic sentence that forces another person to change.</p>
<p>For example: &ldquo;If the conversation becomes abusive, I will end the call and continue by email.&rdquo;</p>
<h3 id="3-reduce-circular-arguments">3. Reduce circular arguments</h3>
<p>If somebody persistently distorts the subject, moves the goalposts or attacks you whenever accountability arises, hours of additional explanation may not improve the conversation. Short, factual communication can sometimes be more effective.</p>
<h3 id="4-keep-appropriate-records-where-there-is-genuine-risk-or-a-formal-dispute">4. Keep appropriate records where there is genuine risk or a formal dispute</h3>
<p>Preserve relevant messages and contemporaneous factual notes lawfully. Do not secretly record people without first considering the law and how the material could be used in your jurisdiction.</p>
<h3 id="5-get-outside-perspective">5. Get outside perspective</h3>
<p>Manipulative or coercive relationships can narrow a person's frame of reference. A qualified therapist, domestic-abuse service, solicitor or trusted person can help distinguish an upsetting disagreement from a persistent harmful pattern.</p>
<h3 id="6-treat-safety-as-a-separate-question-from-diagnosis">6. Treat safety as a separate question from diagnosis</h3>
<p>Threats, violence, stalking and coercive control should be assessed on their own seriousness. You do not need proof of NPD before seeking help.</p>
<h2 id="what-if-the-person-is-my-ex-and-we-share-children">What if the person is my ex and we share children?</h2>
<p>High-conflict separation creates a particular temptation to diagnose the other parent. In family disputes, that can backfire and can obscure the behaviours that actually matter.</p>
<p>Where children are involved, focus on:</p>
<ul>
<li>the child's welfare and observable needs;</li>
<li>exact communications rather than personality labels;</li>
<li>compliance with court orders and professional advice;</li>
<li>clear, child-focused proposals;</li>
<li>patterns that can be evidenced rather than inferred motives; and</li>
<li>obtaining jurisdiction-specific legal advice where necessary.</li>
</ul>
<p>If you believe a child or adult is at immediate risk, use the appropriate safeguarding or emergency route rather than attempting to resolve the situation through psychological labelling.</p>
<h2 id="what-if-i-recognise-narcissistic-traits-in-myself">What if I recognise narcissistic traits in myself?</h2>
<p>Recognising traits in yourself is not proof that you have NPD &mdash; and it is not a reason to panic.</p>
<p>In fact, curiosity about your own patterns can be useful. Consider:</p>
<ul>
<li>What happens inside me when I am criticised?</li>
<li>Do I need to win, or can I remain curious?</li>
<li>Can I admit fault without collapsing into shame or counterattacking?</li>
<li>Do I expect exceptions that I would not grant other people?</li>
<li>Do I become less empathic when my status or self-image is threatened?</li>
<li>Do my relationships repeatedly fail for similar reasons?</li>
<li>Can I tolerate another person having needs that conflict with mine?</li>
</ul>
<p>If these patterns repeatedly harm you or other people, discussing them honestly with an appropriately qualified mental-health professional is far more useful than taking an online &ldquo;narcissist test&rdquo;.</p>
<h2 id="can-you-recover-after-a-relationship-with-someone-high-in-narcissistic-traits">Can you recover after a relationship with someone high in narcissistic traits?</h2>
<p>Yes. Recovery does not require solving the other person's diagnosis. After a controlling, invalidating or psychologically abusive relationship, people can experience anxiety, shame, hypervigilance, self-doubt, grief, sleep disturbance, isolation and difficulty trusting their own decisions. These experiences deserve support in their own right, regardless of whether the other person ever receives a clinical label.</p>
<p>Useful recovery work may include rebuilding safe social connection, restoring autonomy, processing trauma where appropriate, strengthening boundaries, challenging self-blame and learning to recognise early warning signs without becoming hypervigilant to every imperfection in future partners.</p>
<p>The objective is not to become better at diagnosing strangers. It is to become better at recognising <strong>respect, reciprocity and safety</strong>.</p>
<h2 id="common-myths-about-narcissists">Common myths about narcissists</h2>
<h3 id="myth-narcissists-love-themselves">Myth: &ldquo;Narcissists love themselves.&rdquo;</h3>
<p><strong>Reality:</strong> Narcissism is not simply excessive healthy self-love. Pathological forms involve complex self-esteem regulation, entitlement, interpersonal dysfunction and varying grandiose and vulnerable states.</p>
<h3 id="myth-narcissists-have-zero-empathy">Myth: &ldquo;Narcissists have zero empathy.&rdquo;</h3>
<p><strong>Reality:</strong> Empathy can be impaired and inconsistent, but research does not support reducing it to a universal on/off absence in every person and every situation.</p>
<h3 id="myth-every-narcissist-is-an-abuser">Myth: &ldquo;Every narcissist is an abuser.&rdquo;</h3>
<p><strong>Reality:</strong> NPD and abuse are not synonyms. Harmful behaviour still requires accountability whether or not a diagnosis exists.</p>
<h3 id="myth-every-abuser-is-a-narcissist">Myth: &ldquo;Every abuser is a narcissist.&rdquo;</h3>
<p><strong>Reality:</strong> Abuse has many pathways and cannot be retrospectively diagnosed as NPD.</p>
<h3 id="myth-covert-narcissist-is-a-separate-diagnosis">Myth: &ldquo;Covert narcissist is a separate diagnosis.&rdquo;</h3>
<p><strong>Reality:</strong> It is a popular term. Vulnerable narcissism is a research construct, while NPD remains the formal DSM diagnosis.</p>
<h3 id="myth-a-narcissist-can-never-change">Myth: &ldquo;A narcissist can never change.&rdquo;</h3>
<p><strong>Reality:</strong> Personality pathology is difficult to change but not scientifically synonymous with permanent impossibility. Treatment and individual motivation matter.</p>
<h3 id="myth-you-can-see-narcissism-in-someones-eyes">Myth: &ldquo;You can see narcissism in someone's eyes.&rdquo;</h3>
<p><strong>Reality:</strong> There is no diagnostic narcissistic stare, smirk or facial structure.</p>
<h3 id="myth-if-somebody-gets-angry-when-confronted-they-are-a-narcissist">Myth: &ldquo;If somebody gets angry when confronted, they are a narcissist.&rdquo;</h3>
<p><strong>Reality:</strong> Anger is nonspecific. Narcissism is associated with aggression at group level, particularly under provocation, but an individual's anger does not diagnose NPD.</p>
<h3 id="myth-narcissists-are-all-confident-extroverts">Myth: &ldquo;Narcissists are all confident extroverts.&rdquo;</h3>
<p><strong>Reality:</strong> Vulnerable narcissistic features can involve insecurity, withdrawal and hypersensitivity.</p>
<h2 id="a-practical-evidence-led-checklist-pattern-not-diagnosis">A practical evidence-led checklist: pattern, not diagnosis</h2>
<p>If you are trying to make sense of a difficult relationship, the following questions are more defensible than an online diagnosis:</p>
<ul>
<li>Is entitlement persistent?</li>
<li>Is admiration expected rather than merely enjoyed?</li>
<li>Does the person repeatedly exploit other people?</li>
<li>Does empathy disappear especially when another person's needs compete with theirs?</li>
<li>Is criticism met with disproportionate defence, rage, shame, contempt or retaliation?</li>
<li>Does the person require superiority, specialness or status to maintain their self-image?</li>
<li>Are relationships reciprocal, or organised mainly around the person's emotional and practical needs?</li>
<li>Can they take responsibility without reliably reversing blame?</li>
<li>Do they repair after harm?</li>
<li>Does the same pattern occur across time and contexts?</li>
</ul>
<p>Several &ldquo;yes&rdquo; answers may indicate a harmful interpersonal pattern. They still do <strong>not</strong> amount to a clinical diagnosis.</p>
<h2 id="frequently-asked-questions-about-narcissism">Frequently asked questions about narcissism</h2>
<h3 id="what-is-the-simplest-definition-of-a-narcissist">What is the simplest definition of a narcissist?</h3>
<p>In everyday language, a narcissist is a person who shows pronounced narcissistic characteristics such as excessive self-focus, entitlement, need for admiration and reduced concern for other people's needs. Clinically, it is better to distinguish narcissistic traits from Narcissistic Personality Disorder, which requires professional assessment.</p>
<h3 id="what-are-the-biggest-signs-of-a-narcissist">What are the biggest signs of a narcissist?</h3>
<p>Persistent grandiosity, entitlement, excessive need for admiration, exploitative behaviour, arrogance and impaired empathy are central narcissistic features. The key word is <strong>persistent</strong>: occasional selfishness or defensiveness is not enough.</p>
<h3 id="what-is-npd">What is NPD?</h3>
<p>NPD stands for <strong>Narcissistic Personality Disorder</strong>, a recognised mental-health diagnosis involving an enduring and impairing narcissistic personality pattern.</p>
<h3 id="is-a-covert-narcissist-real">Is a covert narcissist real?</h3>
<p>&ldquo;Covert narcissist&rdquo; is not a separate formal DSM diagnosis. It is commonly used to describe a quieter, more vulnerable narcissistic presentation involving shame, hypersensitivity, defensiveness and insecurity alongside narcissistic features.</p>
<h3 id="what-is-vulnerable-narcissism">What is vulnerable narcissism?</h3>
<p>Vulnerable narcissism refers to a pattern associated with insecurity, negative emotion, hypersensitivity and defensiveness, while still involving narcissistic self-focus and antagonistic features.</p>
<h3 id="what-is-grandiose-narcissism">What is grandiose narcissism?</h3>
<p>Grandiose narcissism involves pronounced self-confidence, self-enhancement, status seeking and dominance, often combined at higher pathological levels with entitlement and antagonism.</p>
<h3 id="are-narcissists-dangerous">Are narcissists dangerous?</h3>
<p>Narcissism is statistically associated with aggression, and provocation can strengthen that association. This does not mean every person high in narcissistic traits is violent. Individual risk must be assessed from actual risk factors and behaviour, not a label.</p>
<h3 id="do-narcissists-know-they-hurt-you">Do narcissists know they hurt you?</h3>
<p>There is no universal answer. Awareness, empathy, intent and insight differ among individuals. Focus on whether the person acknowledges harm and changes the behaviour rather than trying to read their mind.</p>
<h3 id="do-narcissists-feel-guilt">Do narcissists feel guilt?</h3>
<p>People with narcissistic pathology are not all emotionally identical. Guilt, shame, remorse and empathy vary. A diagnosis does not demonstrate the total absence of guilt.</p>
<h3 id="why-do-narcissists-lie">Why do narcissists lie?</h3>
<p>There is no single &ldquo;narcissistic lie&rdquo;. Deception can serve self-enhancement, avoidance of shame, protection of status, exploitation or escape from consequences, but lying occurs in people without NPD too.</p>
<h3 id="do-narcissists-come-back-after-a-breakup">Do narcissists come back after a breakup?</h3>
<p>Some former partners re-establish contact; others do not. The popular term &ldquo;hoovering&rdquo; describes attempts to draw someone back into contact, but a return after separation is not diagnostic of narcissism.</p>
<h3 id="is-hoovering-a-clinical-term">Is hoovering a clinical term?</h3>
<p>No. It is popular relationship vocabulary, not a formal psychiatric diagnosis or DSM symptom.</p>
<h3 id="should-i-tell-someone-i-think-they-are-a-narcissist">Should I tell someone I think they are a narcissist?</h3>
<p>Usually, arguing over a diagnosis is less useful than addressing the specific behaviour and your boundary. If diagnosis is genuinely needed, that belongs with an appropriately qualified professional.</p>
<h3 id="can-i-diagnose-my-ex-as-a-narcissist">Can I diagnose my ex as a narcissist?</h3>
<p>No. You can describe patterns you experienced and seek professional support, but a reliable personality-disorder diagnosis requires an appropriate clinical assessment.</p>
<h3 id="is-narcissism-a-mental-illness">Is narcissism a mental illness?</h3>
<p>Narcissistic traits themselves are personality characteristics. Narcissistic Personality Disorder is a recognised mental-health/personality disorder diagnosis when the relevant clinical threshold is met.</p>
<h3 id="is-narcissism-the-same-as-vanity">Is narcissism the same as vanity?</h3>
<p>No. Vanity concerns excessive pride in appearance or achievements. Narcissistic pathology is broader and includes self-esteem regulation, entitlement, admiration, empathy and interpersonal functioning.</p>
<h3 id="is-narcissism-the-same-as-psychopathy">Is narcissism the same as psychopathy?</h3>
<p>No. They are distinct constructs, though some antagonistic, exploitative or empathy-related features can overlap.</p>
<h3 id="can-therapy-help-npd">Can therapy help NPD?</h3>
<p>Psychotherapy is the main treatment approach. Evidence is still developing and treatment can be challenging, but improvement is possible. Co-occurring problems may also need treatment.</p>
<h2 id="the-most-important-thing-to-remember">The most important thing to remember</h2>
<p>The internet has turned &ldquo;narcissist&rdquo; into both an explanation for almost every painful relationship and, at times, an insult disguised as psychology. Neither use helps us think clearly.</p>
<p>Evidence asks us to hold several truths at once:</p>
<ul>
<li>narcissistic traits exist on a continuum;</li>
<li>pathological narcissism can cause profound interpersonal difficulty;</li>
<li>grandiosity and vulnerability can coexist;</li>
<li>empathy is more complex than &ldquo;present&rdquo; or &ldquo;absent&rdquo;;</li>
<li>narcissism is associated with aggression, but a diagnosis does not predict an individual's behaviour with certainty;</li>
<li>manipulation, DARVO, gaslighting and abuse can occur without NPD;</li>
<li>people with NPD should not automatically be demonised;</li>
<li>victims of harmful behaviour do not need a diagnosis before their experience matters; and</li>
<li>a pattern of behaviour is often more actionable than a personality label.</li>
</ul>
<p>If you remember only one sentence from this guide, make it this:</p>
<blockquote>
<p><strong>Do not ask only, &ldquo;Is this person a narcissist?&rdquo; Ask, &ldquo;What is the repeated pattern, what evidence supports my interpretation, what impact is it having, and what response protects wellbeing, dignity and safety?&rdquo;</strong></p>
</blockquote>
<p>That question is less sensational. It is also far more psychologically useful.</p>
<hr>
<h2 id="evidence-and-further-reading">Evidence and further reading</h2>
<p>This article is educational and is not a diagnostic assessment. It draws on clinical and peer-reviewed literature, including:</p>
<ol type="1">
<li>American Psychiatric Association. <strong>What Is Narcissistic Personality Disorder?</strong> (2024). <a href="https://www.psychiatry.org/news-room/apa-blogs/what-is-narcissistic-personality-disorder">https://www.psychiatry.org/news-room/apa-blogs/what-is-narcissistic-personality-disorder</a></li>
<li>Weinberg, I. &amp; Ronningstam, E. <strong>Narcissistic Personality Disorder: Progress in Understanding and Treatment.</strong> <em>Focus</em> (2022/2023 archive). <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC10187400/">https://pmc.ncbi.nlm.nih.gov/articles/PMC10187400/</a></li>
<li>Baskin-Sommers, A., Krusemark, E. &amp; Ronningstam, E. <strong>Empathy in Narcissistic Personality Disorder: From Clinical and Empirical Perspectives.</strong> <em>Personality Disorders</em> (2014). <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC4415495/">https://pmc.ncbi.nlm.nih.gov/articles/PMC4415495/</a></li>
<li>Jauk, E. &amp; Kanske, P. <strong>Can neuroscience help to understand narcissism? A systematic review of an emerging field.</strong> <em>Personality Neuroscience</em> (2021). <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC8170532/">https://pmc.ncbi.nlm.nih.gov/articles/PMC8170532/</a></li>
<li>Edershile, E. A. &amp; Wright, A. G. C. <strong>Fluctuations in grandiose and vulnerable narcissistic states.</strong> (2021). <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC8060359/">https://pmc.ncbi.nlm.nih.gov/articles/PMC8060359/</a></li>
<li>Kj&aelig;rvik, S. L. &amp; Bushman, B. J. <strong>The link between narcissism and aggression: A meta-analytic review.</strong> <em>Psychological Bulletin</em> (2021), 147(5), 477&ndash;503. <a href="https://pubmed.ncbi.nlm.nih.gov/34292012/">https://pubmed.ncbi.nlm.nih.gov/34292012/</a></li>
<li>Du, T. V., Miller, J. D. &amp; Lynam, D. R. <strong>The relation between narcissism and aggression: A meta-analysis.</strong> <em>Journal of Personality</em> (2022), 90(4), 574&ndash;594. <a href="https://pubmed.ncbi.nlm.nih.gov/34689345/">https://pubmed.ncbi.nlm.nih.gov/34689345/</a></li>
<li>Grijalva, E. et al. <strong>Gender differences in narcissism: a meta-analytic review.</strong> <em>Psychological Bulletin</em> (2015), 141(2), 261&ndash;310. <a href="https://pubmed.ncbi.nlm.nih.gov/25546498/">https://pubmed.ncbi.nlm.nih.gov/25546498/</a></li>
</ol>
<hr>

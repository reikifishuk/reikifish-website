---
title: "Not Everything Is Narcissism: Understanding the Overlap Between Cluster B Personality Disorders"
seoTitle: "Cluster B Personality Disorders: Why It Isn't All Narcissism"
metaDescription: "Explore how NPD, BPD, ASPD and HPD overlap, what makes them different, and why difficult or abusive behaviour does not automatically mean narcissism."
slug: "cluster-b-personality-disorders-overlap"
categories: "Psychology"
tags: "['Cluster B', 'Personality Disorders', 'Narcissism']"
author: "Reiki Fish"
featured: false
draft: false
date: "2026-08-06"
excerpt: "Not everything is narcissism. Explore the complex overlap between NPD, BPD, ASPD and HPD, why similar behaviours can have very different psychological origins, and how modern personality science is moving beyond simple diagnostic boxes."
featuredImage: "assets/images/blog/cluster_b_explained.png"
featuredImageAlt: "Four overlapping human profiles representing the shared and distinct traits found across Cluster B personality disorders."
---

<p>&ldquo;Narcissist&rdquo; has become one of the most overused psychological labels on the internet.</p>
<p>A partner lies? Narcissist.</p>
<p>A friend needs attention? Narcissist.</p>
<p>Someone becomes intensely jealous? Narcissist.</p>
<p>A person manipulates somebody? Narcissist.</p>
<p>Someone cheats, becomes angry, avoids accountability or behaves selfishly? Once again, the internet reaches for narcissism.</p>
<p>But human personality is considerably more complicated than that.</p>
<p>Many behaviours popularly attributed to narcissistic personality disorder can occur in other personality disorders, other mental health conditions, during periods of extreme emotional distress, through learned behaviour, substance misuse or simply in people who behave badly without having any psychiatric disorder whatsoever.</p>
<p>This becomes particularly important when discussing the group historically known as <strong>Cluster B personality disorders</strong>: narcissistic personality disorder, borderline personality disorder, antisocial personality disorder and histrionic personality disorder.</p>
<p>These diagnoses have meaningful differences. They also overlap.</p>
<p>Sometimes substantially.</p>
<p>Indeed, the problem of overlapping personality disorder categories is important enough that contemporary psychiatric classification has increasingly moved towards dimensional ways of understanding personality pathology rather than assuming every person fits neatly into one diagnostic box.</p>
<p>So if someone lies, manipulates, fears abandonment, demands attention, lacks empathy, becomes emotionally volatile or behaves exploitatively, the scientifically responsible question is not:</p>
<p><strong>&ldquo;Which Cluster B disorder have I just diagnosed?&rdquo;</strong></p>
<p>It is:</p>
<p><strong>&ldquo;What does this behaviour actually tell us, and what doesn't it tell us?&rdquo;</strong></p>
<h2>What Exactly Is Cluster B?</h2>
<p>In the traditional DSM classification used extensively in psychiatry and psychology, personality disorders have been grouped into three clusters.</p>
<p>Cluster B contains:</p>
<ul>
<li><strong>Antisocial personality disorder (ASPD).</strong></li>
<li><strong>Borderline personality disorder (BPD).</strong></li>
<li><strong>Histrionic personality disorder (HPD).</strong></li>
<li><strong>Narcissistic personality disorder (NPD).</strong></li>
</ul>
<p>They have historically been grouped together because of similarities involving emotional, interpersonal, impulsive or dramatic patterns.</p>
<p>But the word <strong>cluster</strong> is important.</p>
<p>It does not mean these are four versions of the same disorder.</p>
<p>It does not mean somebody with one automatically has features of all four.</p>
<p>And it certainly does not mean every person displaying a Cluster B-like behaviour has a personality disorder.</p>
<h2>The First Rule: A Trait Is Not a Disorder</h2>
<p>This is probably the most important sentence in this entire article:</p>
<p><strong>You can have a narcissistic trait without having narcissistic personality disorder.</strong></p>
<p>The same applies across personality pathology.</p>
<p>A person can:</p>
<ul>
<li>Seek attention without having HPD.</li>
<li>Fear abandonment without having BPD.</li>
<li>Lie without having ASPD.</li>
<li>Feel entitled without having NPD.</li>
<li>Act impulsively without having BPD or ASPD.</li>
<li>Become emotionally dysregulated without having any personality disorder.</li>
<li>Display low empathy in a particular situation without having NPD or ASPD.</li>
<li>Manipulate somebody without having any psychiatric diagnosis.</li>
</ul>
<p>Human personality traits exist throughout the population.</p>
<p>The fact that somebody occasionally behaves narcissistically is fundamentally different from establishing a pervasive personality disorder.</p>
<p>Diagnosis involves patterns of personality functioning, persistence, context, severity, impairment and clinical assessment. NICE specifically recommends structured clinical assessment when diagnosing borderline or antisocial personality disorder.</p>
<p>Social media observation is not a structured clinical assessment.</p>
<h2>Why the Internet Sees Narcissism Everywhere</h2>
<p>Narcissism has become a cultural shorthand for difficult behaviour.</p>
<p>There are several reasons for this.</p>
<p>First, the word already existed outside psychiatry. Long before TikTok psychology, people described excessive self-love or vanity as narcissistic.</p>
<p>Second, relationship content built around &ldquo;narcissistic abuse&rdquo; offers an emotionally simple explanation for confusing experiences.</p>
<p>The narrative can become:</p>
<p><strong>They hurt you because they are a narcissist.</strong></p>
<p>For somebody trying to make sense of betrayal or abuse, that certainty can initially feel comforting.</p>
<p>But psychologically comfortable explanations are not necessarily diagnostically correct ones.</p>
<p>Third, algorithms reward recognisable labels.</p>
<p>&ldquo;Seven signs you're dating a narcissist&rdquo; is easier to market than:</p>
<p><strong>&ldquo;Seven behaviours with numerous possible psychological and non-psychological explanations requiring contextual assessment.&rdquo;</strong></p>
<p>Unfortunately, the second statement is closer to responsible psychology.</p>
<h2>The Four Traditional Cluster B Disorders</h2>
<p>To understand overlap, we first need to understand what separates the diagnoses.</p>
<h3>Narcissistic Personality Disorder</h3>
<p>NPD involves a persistent pathological pattern relating to self-importance, admiration, entitlement, interpersonal functioning and empathy.</p>
<p>The popular stereotype is somebody who loves themselves.</p>
<p>That is much too simplistic.</p>
<p>Pathological narcissism can involve regulation of self-esteem, sensitivity to criticism, interpersonal entitlement, fantasies of success or status, dependence upon external validation and difficulty recognising other people's emotional needs.</p>
<p>Not everybody with narcissistic pathology presents as a loud, boastful, obviously grandiose individual.</p>
<p>Clinical literature has long discussed differences between more overtly grandiose presentations and more vulnerable narcissistic functioning.</p>
<p>That does not mean &ldquo;covert narcissist&rdquo; should be casually assigned to every insecure or passive-aggressive person.</p>
<p>The crucial problem is again one of pattern, severity and functioning.</p>
<h3>Borderline Personality Disorder</h3>
<p>BPD is associated with difficulties involving emotional regulation, instability in relationships and self-image, impulsivity and intense sensitivity surrounding relationships.</p>
<p>Features can include:</p>
<ul>
<li>Fear of abandonment.</li>
<li>Unstable or intense relationships.</li>
<li>Disturbance in identity or sense of self.</li>
<li>Impulsivity.</li>
<li>Recurrent suicidal or self-harming behaviour in some people.</li>
<li>Marked emotional instability.</li>
<li>Chronic feelings of emptiness.</li>
<li>Intense or poorly regulated anger.</li>
<li>Stress-related paranoid thinking or dissociative experiences.</li>
</ul>
<p>But BPD should not be translated into:</p>
<p><strong>&ldquo;Emotionally difficult person.&rdquo;</strong></p>
<p>Nor should somebody with BPD automatically be described as abusive or manipulative.</p>
<p>Many people with BPD experience enormous psychological suffering themselves, and effective psychological treatments exist.</p>
<h3>Antisocial Personality Disorder</h3>
<p>ASPD involves persistent patterns relating to disregard for other people's rights and social norms.</p>
<p>Relevant features can include deceitfulness, irresponsibility, impulsivity, aggression and lack of appropriate remorse.</p>
<p>Again, internet language often muddies the water by treating ASPD, sociopathy and psychopathy as interchangeable.</p>
<p>They are not simply three official names for the same diagnosis.</p>
<p><strong>Psychopathy is not itself a standalone DSM personality disorder diagnosis.</strong></p>
<p>Psychopathy is a related construct with an extensive research tradition, particularly in forensic psychology. It overlaps with ASPD, but the concepts are not identical.</p>
<p>NICE explicitly discusses psychopathy within its ASPD guidance while recognising it as relevant to only a proportion of those with ASPD.</p>
<h3>Histrionic Personality Disorder</h3>
<p>HPD receives considerably less attention online than narcissism or BPD.</p>
<p>It is traditionally associated with pervasive patterns of excessive emotionality and attention-seeking.</p>
<p>This might involve theatrical emotional expression, a strong drive to be noticed, impressionistic communication or interpersonal behaviour strongly organised around obtaining attention and response from other people.</p>
<p>But wanting attention does not equal HPD.</p>
<p>Almost every human being seeks social attention to some degree.</p>
<p>The issue is the broader and enduring personality pattern.</p>
<h2>So Where Does the Overlap Begin?</h2>
<p>Now we reach the interesting part.</p>
<p>Consider these behaviours:</p>
<ul>
<li>Manipulation.</li>
<li>Anger.</li>
<li>Impulsivity.</li>
<li>Attention seeking.</li>
<li>Unstable relationships.</li>
<li>Problems with empathy.</li>
<li>Self-centred behaviour.</li>
<li>Deception.</li>
<li>Sensitivity to rejection.</li>
<li>Interpersonal exploitation.</li>
<li>Dramatic emotional responses.</li>
<li>Difficulty accepting responsibility.</li>
</ul>
<p>None belongs exclusively to one disorder.</p>
<p>Even when a behaviour is strongly associated with a particular diagnosis, the behaviour alone rarely identifies that diagnosis.</p>
<p>This is one reason personality disorders have historically produced considerable diagnostic overlap and comorbidity.</p>
<h2>NPD and BPD: Similar Surface, Different Psychological Dynamics</h2>
<p>NPD and BPD provide one of the clearest examples of why surface behaviour can mislead.</p>
<p>Imagine somebody reacts extremely badly when their partner attempts to leave.</p>
<p>That could potentially relate to several mechanisms.</p>
<p>In a person with prominent borderline pathology, separation could activate overwhelming abandonment sensitivity, emotional dysregulation and an unstable sense of self.</p>
<p>In somebody with prominent narcissistic pathology, rejection might significantly threaten self-esteem, status, entitlement or their sense of importance.</p>
<p>From the outside, both people might:</p>
<ul>
<li>Become angry.</li>
<li>Repeatedly contact the partner.</li>
<li>Demand reassurance.</li>
<li>Devalue the person leaving.</li>
<li>Behave impulsively.</li>
<li>Attempt to regain control of the interaction.</li>
</ul>
<p>The behaviour can therefore look superficially similar while the internal psychological organisation differs.</p>
<p>And some individuals genuinely meet diagnostic requirements relating to more than one personality disorder.</p>
<p>A study examining clinical patients with BPD found that a subgroup also fulfilled criteria for NPD. Those with both diagnoses showed a somewhat different pattern of additional personality pathology than the BPD-only group.</p>
<p>That is real comorbidity, not internet speculation.</p>
<h2>Idealisation and Devaluation Are Not Exclusive to Narcissism</h2>
<p>Another internet myth involves idealisation and devaluation.</p>
<p>A relationship begins intensely.</p>
<p>The partner is described as perfect.</p>
<p>Later the same person becomes &ldquo;the worst person in the world&rdquo;.</p>
<p>Online, this is frequently described as proof of narcissism.</p>
<p>It isn't.</p>
<p>Black-and-white interpersonal evaluations can be particularly relevant to borderline personality functioning too.</p>
<p>Idealisation and devaluation can also occur outside personality disorders.</p>
<p>People sometimes radically reinterpret relationships following betrayal, trauma, anger or separation.</p>
<p>The presence of the behaviour tells you something happened.</p>
<p>It does not automatically identify the diagnosis behind it.</p>
<h2>Fear of Abandonment Is Not Automatically BPD Either</h2>
<p>The diagnostic confusion works in both directions.</p>
<p>Fear of rejection or abandonment may be strongly associated with BPD, but people without BPD can become intensely afraid of losing relationships.</p>
<p>Possible contributors can include:</p>
<ul>
<li>Insecure attachment.</li>
<li>Previous betrayal.</li>
<li>Traumatic relationships.</li>
<li>Low self-esteem.</li>
<li>Depression.</li>
<li>Anxiety.</li>
<li>Recent bereavement.</li>
<li>Dependency.</li>
<li>Situational insecurity.</li>
</ul>
<p>Attachment style is not a personality disorder diagnosis.</p>
<p>Trauma is not BPD.</p>
<p>And abandonment anxiety is not sufficient to diagnose BPD.</p>
<h2>NPD and ASPD: Where Exploitation Can Look Similar</h2>
<p>Narcissistic and antisocial pathology can also overlap.</p>
<p>Both can involve significant interpersonal problems.</p>
<p>Both can include exploitative behaviour.</p>
<p>Both may involve reduced consideration for another person's feelings.</p>
<p>Both can involve deception in some individuals.</p>
<p>But these constructs are not identical.</p>
<p>A person with ASPD may show a broader pattern of disregard for rules and other people's rights, chronic irresponsibility, deceit or aggression.</p>
<p>Narcissistic pathology is more centrally organised around disturbances involving self, status, admiration, entitlement and interpersonal functioning.</p>
<p>There can nevertheless be individuals with features of both.</p>
<p>This is precisely why saying:</p>
<p><strong>&ldquo;He lies, therefore he's a narcissist&rdquo;</strong></p>
<p>makes almost no diagnostic sense.</p>
<h2>Psychopathy Complicates the Picture Further</h2>
<p>Psychopathy is frequently confused with both ASPD and NPD.</p>
<p>Research models of psychopathy often include characteristics involving interpersonal style, affective functioning and behavioural disinhibition.</p>
<p>Traits can include:</p>
<ul>
<li>Callousness.</li>
<li>Low remorse.</li>
<li>Deceitfulness.</li>
<li>Superficial charm.</li>
<li>Manipulative interpersonal behaviour.</li>
<li>Disinhibition.</li>
<li>Antisocial behaviour.</li>
</ul>
<p>Some of these clearly resemble aspects seen within narcissistic or antisocial pathology.</p>
<p>Research examining psychopathy and Cluster B traits has found meaningful co-occurrence.</p>
<p>But this still does not permit the equation:</p>
<p><strong>Narcissist = psychopath.</strong></p>
<p>Nor:</p>
<p><strong>ASPD = psychopath.</strong></p>
<p>Clinical and forensic constructs have to be distinguished carefully.</p>
<h2>NPD and HPD: Attention Is the Obvious Overlap</h2>
<p>NPD and HPD can sometimes appear similar because both may involve a strong interpersonal need for attention.</p>
<p>But the type and psychological meaning of attention can differ.</p>
<p>Narcissistic functioning may particularly involve admiration, status, superiority or reinforcement of a valued self-image.</p>
<p>Histrionic functioning may more broadly involve being the focus of attention, interpersonal responsiveness and emotionally expressive engagement.</p>
<p>Someone loudly dominating a social gathering could superficially resemble either.</p>
<p>Someone constantly uploading photographs to social media could have either diagnosis.</p>
<p>They could also have neither.</p>
<p>Posting selfies is not a psychiatric assessment.</p>
<h2>BPD and HPD: Emotional Expression Can Be Confused</h2>
<p>BPD and HPD may both involve highly visible emotionality.</p>
<p>That can cause observers to confuse them.</p>
<p>But intense emotional dysregulation associated with BPD is not the same construct as the attention-related and expressive interpersonal pattern historically associated with HPD.</p>
<p>Again, however, the boundaries have never been perfectly clean.</p>
<p>Research into personality disorders has repeatedly demonstrated diagnostic overlap, and some people meet requirements for more than one disorder.</p>
<h2>BPD and ASPD: Impulsivity Does Not Tell You Which One</h2>
<p>Impulsivity is another excellent example of a transdiagnostic behaviour.</p>
<p>Both BPD and ASPD can involve impulsivity.</p>
<p>But impulsivity also appears in:</p>
<ul>
<li>ADHD.</li>
<li>Substance-related disorders.</li>
<li>Bipolar mania or hypomania.</li>
<li>Some neurological conditions.</li>
<li>Trauma-related states.</li>
<li>Ordinary human behaviour under intoxication or extreme stress.</li>
</ul>
<p>Therefore:</p>
<p><strong>Impulsive behaviour is evidence of impulsivity.</strong></p>
<p>It is not, by itself, evidence of a particular personality disorder.</p>
<h2>All Four Can Produce Interpersonal Chaos</h2>
<p>This may be where lay diagnosis becomes most tempting.</p>
<p>A person experiences repeated relationship breakdowns.</p>
<p>They become angry.</p>
<p>They cheat.</p>
<p>They lie.</p>
<p>They demand attention.</p>
<p>They struggle with empathy.</p>
<p>They alternate between closeness and hostility.</p>
<p>Someone watching this understandably thinks:</p>
<p><strong>&ldquo;This has to be Cluster B.&rdquo;</strong></p>
<p>Perhaps.</p>
<p>But perhaps not.</p>
<p>The same behavioural history may be influenced by addiction, trauma, mood disorder, attachment difficulties, learned relationship behaviour, neurodevelopmental differences, situational stress or combinations of these.</p>
<p>A diagnostic formulation has to examine much more than the worst things somebody has done.</p>
<h2>Behaviour Is Not Motivation</h2>
<ul>
<li>This is one of the biggest reasoning errors in online psychology.</li>
<li>Two people can perform identical behaviours for completely different reasons.</li>
<li>Imagine two people repeatedly telephone a partner after a break-up.</li>
<li>Person A may be experiencing overwhelming abandonment panic.</li>
<li>Person B may feel humiliated and believe they are entitled to regain control.</li>
<li>Person C may be intoxicated.</li>
<li>Person D may simply be grieving badly and behaving unwisely.</li>
<li>Person E may be attempting coercive control.</li>
<li>The telephone record alone cannot tell you which psychological mechanism is operating.</li>
<li>This distinction between <strong>behaviour</strong> and <strong>motivation</strong> is essential.</li>
</ul>
<h2>Manipulation Is Not a Diagnosis</h2>
<p>Another enormous myth needs dismantling:</p>
<p><strong>Manipulation does not belong exclusively to narcissism.</strong></p>
<p>Manipulation is behaviour.</p>
<p>People can manipulate others:</p>
<ul>
<li>To avoid abandonment.</li>
<li>To obtain money.</li>
<li>To obtain admiration.</li>
<li>To escape consequences.</li>
<li>To control a relationship.</li>
<li>To obtain attention.</li>
<li>Through panic.</li>
<li>Through learned interpersonal behaviour.</li>
<li>Through calculated exploitation.</li>
</ul>
<p>The moral acceptability of the behaviour and the psychiatric explanation for the behaviour are two separate questions.</p>
<p>Something can be harmful without being diagnostic.</p>
<h2>Gaslighting Is Not Proof of NPD</h2>
<ul>
<li>Gaslighting has suffered a similar fate.</li>
<li>The term originally refers to a pattern of psychological manipulation involving attempts to undermine another person's confidence in their perceptions or understanding of reality.</li>
<li>It is now often used for almost any disagreement.</li>
<li>A person lying about an affair may be deceptive.</li>
<li>A person genuinely remembering an argument differently is not necessarily gaslighting.</li>
<li>A person insisting that their opinion is correct is not automatically gaslighting either.</li>
<li>Most importantly:</li>
</ul>
<p><strong>Even genuine gaslighting does not diagnose NPD.</strong></p>
<p>It describes behaviour.</p>
<h2>Lying Is Not Narcissism</h2>
<p>People lie for an enormous number of reasons.</p>
<p>They may lie to:</p>
<ul>
<li>Avoid punishment.</li>
<li>Preserve reputation.</li>
<li>Gain advantage.</li>
<li>Avoid shame.</li>
<li>Protect somebody.</li>
<li>Manipulate somebody.</li>
<li>Conceal addiction.</li>
<li>Maintain an affair.</li>
<li>Escape responsibility.</li>
<li>Impress other people.</li>
</ul>
<p>Chronic deceit can be clinically important.</p>
<p>But &ldquo;caught lying&rdquo; should never be translated</p>
<h2>A Final Thought: Understand the Person, Not Just the Label</h2>
<p>Psychology becomes less useful when every painful relationship is reduced to narcissism. Human personality is far more complicated than a single label, and Cluster B demonstrates that particularly well.</p>
<p>Traits overlap. Disorders can coexist. Similar behaviours can arise from very different psychological processes, and sometimes harmful behaviour exists without any personality disorder at all.</p>
<p>The better question is not simply, <strong>&ldquo;What disorder does this person have?&rdquo;</strong></p>
<p>Ask instead: <strong>&ldquo;What behaviour am I actually seeing, what pattern does it form, what effect is it having, and what healthy boundary or response is needed?&rdquo;</strong></p>
<p>You do not need to diagnose someone to recognise manipulation. You do not need to call someone a narcissist to acknowledge abuse. And you do not need a psychiatric label to justify protecting your wellbeing.</p>
<p><strong>Labels can guide understanding. They should never replace it.</strong></p>
<p>Sometimes the most psychologically accurate conclusion is also the simplest: not everything is narcissism.</p>
